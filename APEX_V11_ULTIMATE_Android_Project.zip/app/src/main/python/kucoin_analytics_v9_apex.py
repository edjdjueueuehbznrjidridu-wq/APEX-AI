#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""KuCoin Analytics v10 — Pydroid 3 / Desktop. تک‌فایل + APEX AI + دمو ترید مجازی.
منابع: KuCoin | Binance USDⓈ-M | Bybit v5 | OKX | Deribit | Yahoo | alternative.me |
       blockchain.info | RSS (CoinDesk, Cointelegraph, The Block, Decrypt, Bitcoin.com, Google News)
       Faireconomy | CoinPaprika | Gemini (APEX)
"""
import gzip, json, os, re, sqlite3, threading, time
import urllib.error, urllib.parse, urllib.request
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from email.utils import parsedate_to_datetime
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

HOST, PORT = '127.0.0.1', 8765
VERSION = '12.1'
UA = 'Mozilla/5.0 KuCoinAnalytics/9.1'
MAX_POST = 80 * 1024 * 1024
DB_PATH = os.path.join(os.path.expanduser('~'), '.kucoin_analytics_v9.db')

# Gemini API (کاربر ارائه کرده)
GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', 'AQ.Ab8RN6KGN-gEVvRGeC9MsuocXxJEHWvVyitCSflxPQK5ZXAwNw')
GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent'
GEMINI_HOST = 'generativelanguage.googleapis.com'

JSON_HOSTS = {
    'api.kucoin.com', 'api-futures.kucoin.com', 'api.binance.com', 'fapi.binance.com',
    'api.bybit.com', 'www.okx.com', 'www.deribit.com', 'query1.finance.yahoo.com',
    'api.alternative.me', 'api.blockchain.info', 'api.coinpaprika.com', 'nfs.faireconomy.media',
    GEMINI_HOST,
}
RSS_FEEDS = {
    'CoinDesk': 'https://www.coindesk.com/arc/outboundfeeds/rss/',
    'Cointelegraph': 'https://cointelegraph.com/rss',
    'The Block': 'https://www.theblock.co/rss.xml',
    'Decrypt': 'https://decrypt.co/feed',
    'Bitcoin.com': 'https://news.bitcoin.com/feed/',
}
GOOGLE_NEWS = 'https://news.google.com/rss/search?q=%s&hl=en-US&gl=US&ceid=US:en'
RSS_HOSTS = {'www.coindesk.com', 'cointelegraph.com', 'www.theblock.co',
             'decrypt.co', 'news.bitcoin.com', 'news.google.com'}
ALLOWED_ALL = JSON_HOSTS | RSS_HOSTS


class TokenBucket:
    def __init__(self, rate, burst):
        self.rate, self.cap, self.tokens, self.ts = rate, burst, burst, time.monotonic()
        self.lock = threading.Lock()

    def take(self):
        with self.lock:
            now = time.monotonic()
            self.tokens = min(self.cap, self.tokens + (now - self.ts) * self.rate)
            self.ts = now
            wait = 0 if self.tokens >= 1 else (1 - self.tokens) / self.rate
            self.tokens -= 1
        if wait:
            time.sleep(wait)


_buckets, _bl = {}, threading.Lock()


def bucket(host):
    with _bl:
        if host not in _buckets:
            _buckets[host] = TokenBucket(5.0, 10)
        return _buckets[host]


class _SafeRedirect(urllib.request.HTTPRedirectHandler):
    """ریدایرکت فقط به دامنه‌های مجاز"""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        host = urllib.parse.urlparse(newurl).hostname
        if host not in ALLOWED_ALL:
            raise urllib.error.HTTPError(req.full_url, code, 'redirect to unknown host', headers, fp)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


_opener = urllib.request.build_opener(_SafeRedirect())


def http_get(url, allowed, timeout=25):
    u = urllib.parse.urlparse(url)
    if u.scheme != 'https' or u.hostname not in allowed:
        raise ValueError('host not allowed: %s' % u.hostname)
    bucket(u.hostname).take()
    req = urllib.request.Request(url, headers={
        'User-Agent': UA, 'Accept': 'application/json, application/xml, text/xml, */*'})
    with _opener.open(req, timeout=timeout) as r:
        return r.read()


# ---------------- SQLite ----------------
def db_conn():
    return sqlite3.connect(DB_PATH, timeout=10)


def db_init():
    c = db_conn()
    c.execute('CREATE TABLE IF NOT EXISTS oi(symbol TEXT, ts INTEGER, oi REAL, price REAL)')
    c.execute('CREATE INDEX IF NOT EXISTS i_oi ON oi(symbol, ts)')
    c.execute('CREATE TABLE IF NOT EXISTS cache(key TEXT PRIMARY KEY, ts INTEGER, payload TEXT)')
    # --- Demo Trading Pro (virtual exchange) ---
    c.execute("CREATE TABLE IF NOT EXISTS demo_wallet("
              "id INTEGER PRIMARY KEY CHECK (id=1),"
              "balance REAL NOT NULL DEFAULT 100.0,"
              "equity REAL NOT NULL DEFAULT 100.0,"
              "realized_pnl REAL NOT NULL DEFAULT 0.0,"
              "peak_equity REAL NOT NULL DEFAULT 100.0,"
              "total_deposited REAL NOT NULL DEFAULT 100.0,"
              "fees_paid REAL NOT NULL DEFAULT 0.0,"
              "updated_ts INTEGER)")
    c.execute("CREATE TABLE IF NOT EXISTS demo_positions("
              "id INTEGER PRIMARY KEY AUTOINCREMENT,"
              "symbol TEXT NOT NULL,"
              "side TEXT NOT NULL,"
              "entry REAL NOT NULL,"
              "qty REAL NOT NULL,"
              "qty_open REAL NOT NULL,"
              "leverage REAL NOT NULL DEFAULT 1,"
              "margin REAL NOT NULL,"
              "margin_open REAL NOT NULL,"
              "notional REAL NOT NULL,"
              "tp1 REAL, tp2 REAL, tp3 REAL, sl REAL,"
              "trail_dist REAL DEFAULT 0,"
              "trail_active INTEGER DEFAULT 0,"
              "be_moved INTEGER DEFAULT 0,"
              "tp1_done INTEGER DEFAULT 0,"
              "tp2_done INTEGER DEFAULT 0,"
              "liq_price REAL,"
              "status TEXT NOT NULL DEFAULT 'open',"
              "opened_ts INTEGER, closed_ts INTEGER,"
              "close_price REAL, close_reason TEXT,"
              "pnl REAL DEFAULT 0, pnl_pct REAL DEFAULT 0,"
              "fees REAL DEFAULT 0,"
              "mfe REAL DEFAULT 0, mae REAL DEFAULT 0,"
              "ai_conviction INTEGER, ai_horizon TEXT, notes TEXT,"
              "source TEXT DEFAULT 'manual')")
    c.execute("CREATE TABLE IF NOT EXISTS demo_trades("
              "id INTEGER PRIMARY KEY AUTOINCREMENT,"
              "pos_id INTEGER, symbol TEXT, side TEXT,"
              "entry REAL, exit REAL, qty REAL, leverage REAL,"
              "pnl REAL, pnl_pct REAL, fee REAL DEFAULT 0,"
              "reason TEXT, ts INTEGER)")
    c.execute("CREATE TABLE IF NOT EXISTS demo_orders("
              "id INTEGER PRIMARY KEY AUTOINCREMENT,"
              "symbol TEXT, side TEXT, order_type TEXT,"
              "price REAL, qty REAL, leverage REAL,"
              "tp1 REAL, tp2 REAL, tp3 REAL, sl REAL,"
              "status TEXT DEFAULT 'pending',"
              "created_ts INTEGER, filled_ts INTEGER, notes TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS demo_equity("
              "id INTEGER PRIMARY KEY AUTOINCREMENT,"
              "ts INTEGER, equity REAL, balance REAL, open_pnl REAL)")
    c.execute("CREATE TABLE IF NOT EXISTS demo_settings("
              "key TEXT PRIMARY KEY, value TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS demo_alerts("
              "id INTEGER PRIMARY KEY AUTOINCREMENT,"
              "kind TEXT, message TEXT, ts INTEGER, read INTEGER DEFAULT 0)")
    c.execute("CREATE TABLE IF NOT EXISTS demo_wallet_ledger("
              "id INTEGER PRIMARY KEY AUTOINCREMENT,"
              "type TEXT NOT NULL,"  # deposit / withdraw / fee / pnl
              "amount REAL NOT NULL,"
              "balance_after REAL,"
              "note TEXT,"
              "ts INTEGER NOT NULL)")
    c.execute("CREATE TABLE IF NOT EXISTS demo_ai_log("
              "id INTEGER PRIMARY KEY AUTOINCREMENT,"
              "symbol TEXT, tf TEXT, prompt_hash TEXT,"
              "response TEXT, signal_json TEXT, ts INTEGER)")
    def _cols(table):
        try:
            return [r[1] for r in c.execute('PRAGMA table_info(%s)' % table).fetchall()]
        except Exception:
            return []
    def _add(table, col, decl):
        if col not in _cols(table):
            try:
                c.execute('ALTER TABLE %s ADD COLUMN %s %s' % (table, col, decl))
            except Exception:
                pass
    # wallet
    _add('demo_wallet', 'peak_equity', 'REAL DEFAULT 100.0')
    _add('demo_wallet', 'total_deposited', 'REAL DEFAULT 100.0')
    _add('demo_wallet', 'fees_paid', 'REAL DEFAULT 0.0')
    # trades — critical: fee column
    _add('demo_trades', 'fee', 'REAL DEFAULT 0')
    _add('demo_trades', 'pos_id', 'INTEGER')
    _add('demo_trades', 'pnl_pct', 'REAL DEFAULT 0')
    # positions — full pro columns
    for col, decl in [
        ('qty_open', 'REAL'), ('margin_open', 'REAL'), ('notional', 'REAL'),
        ('trail_dist', 'REAL DEFAULT 0'), ('trail_active', 'INTEGER DEFAULT 0'),
        ('be_moved', 'INTEGER DEFAULT 0'), ('tp1_done', 'INTEGER DEFAULT 0'),
        ('tp2_done', 'INTEGER DEFAULT 0'), ('liq_price', 'REAL'),
        ('fees', 'REAL DEFAULT 0'), ('mfe', 'REAL DEFAULT 0'), ('mae', 'REAL DEFAULT 0'),
        ('ai_conviction', 'INTEGER'), ('ai_horizon', 'TEXT'), ('notes', 'TEXT'),
        ('source', "TEXT DEFAULT 'manual'"), ('pnl', 'REAL DEFAULT 0'),
        ('pnl_pct', 'REAL DEFAULT 0'), ('close_price', 'REAL'), ('close_reason', 'TEXT'),
        ('closed_ts', 'INTEGER'),
    ]:
        _add('demo_positions', col, decl)
    # backfill qty_open / margin_open from qty/margin if null
    try:
        c.execute('UPDATE demo_positions SET qty_open=qty WHERE qty_open IS NULL AND qty IS NOT NULL')
        c.execute('UPDATE demo_positions SET margin_open=margin WHERE margin_open IS NULL AND margin IS NOT NULL')
        c.execute('UPDATE demo_positions SET notional=entry*qty WHERE notional IS NULL AND entry IS NOT NULL AND qty IS NOT NULL')
    except Exception:
        pass
    row = c.execute('SELECT id FROM demo_wallet WHERE id=1').fetchone()
    if not row:
        c.execute('INSERT INTO demo_wallet(id,balance,equity,realized_pnl,peak_equity,total_deposited,fees_paid,updated_ts) VALUES(1,100.0,100.0,0.0,100.0,100.0,0.0,?)',
                  (int(time.time()),))
    defaults = {
        'auto_trade': '1',
        'fee_rate': '0.0004',
        'tp1_pct': '0.40',
        'tp2_pct': '0.30',
        'tp3_pct': '0.30',
        'move_be_after_tp1': '1',
        'be_buffer_pct': '0.0005',
        'trail_after_tp1': '1',
        'max_leverage': '20',
        'default_leverage': '5',
        'max_risk_pct': '5',
        'max_positions': '20',
        'max_margin_pct': '80',
        'mmr': '0.005',
        'tick_ms': '1000',
        'size_mode': 'usd',
        'slippage_bps': '2',
        'min_conviction': '5',
        'daily_loss_limit_pct': '25',
        'max_dd_halt_pct': '90',
        'trading_halted': '0',
        'halt_reason': '',
        'ai_require_sl': '0',
        'gemini_api_key': '',
        'auto_trade_running': '0',
        'auto_trade_symbols': 'BTC,ETH,SOL,XRP,DOGE,ADA,LINK,AVAX,DOT,MATIC,LTC,BCH,ATOM,NEAR,APT,SUI,ARB,OP,INJ,TIA',
        'scale_in_enabled': '1',
        'alert_tp_sl': '1',
        'alert_sound': '0',
    }
    for k, v in defaults.items():
        c.execute('INSERT OR IGNORE INTO demo_settings(key,value) VALUES(?,?)', (k, v))
    c.commit()
    c.close()


# ==================== APEX SYSTEM PROMPT (exact, always) ====================
APEX_SYSTEM = r'''You are APEX. You have traded through 2008, the 2017 crypto cycle, COVID crash, the 2021 top, LUNA, FTX, and every regime in between. You do not "analyze indicators." You read the market the way a surgeon reads a body — you already know the anatomy, you are looking for the anomaly.

You do not give advice. You give a read. A read is a structured judgment of what the market is doing, where it is likely to go, and where you would put size if you were forced to act. You are always forced to act.

═══════════════════════════════════════
HOW YOU THINK — ALWAYS IN THIS ORDER
═══════════════════════════════════════

1. REGIME FIRST
Before anything: what regime are we in? Trending, ranging, expanding, contracting, risk-on, risk-off, liquidity-driven, narrative-driven? The regime dictates which tools work and which lie. You name the regime before you name anything else. If the regime is unclear, you say so and describe the two competing regimes and what would resolve the ambiguity.

2. THE DOMINANT NARRATIVE
Every market at every moment has a story it is telling. Not the news story — the story price is telling. "This is a market that wants to go up but keeps getting sold into." "This is a market that is exhausted and pretending to be strong." You name the story in one sentence. If you cannot, you say the market has no story and that itself is information.

3. WHERE IS THE PAIN
Liquidity is a map of pain. Where are the stops? Where are the liquidations? Where are the under-positioned participants who will be forced to chase? Where are the over-positioned participants who will be forced to fold? You identify the pain trade — the move that hurts the most people — because that is usually the move.

4. STRUCTURE IN CONTEXT
Now you read structure — but not as a pattern. As a consequence of the regime and the pain map. "Higher lows matter here because shorts are trapped above." "This support is weak because it has been tested three times and each bounce was weaker." Structure is read in context, never in isolation.

5. TIME
How long has this condition persisted? Markets exhaust. A trend that is three days old is different from a trend that is three months old. You weight setups by time. A setup that has been obvious for a week is usually late.

6. ASYMMETRY
Where is the asymmetry? Not R:R in the textbook sense — actual asymmetry. Where do you risk 1 to make 5? Where do you risk 1 to make 1 but win 80% of the time? You describe the actual bet being offered by the market, not the bet you wish existed.

7. THE DECISION
Only now do you decide. Direction, entry, invalidation, targets, size, leverage, time horizon. You decide as if your own capital is on the line and you cannot re-decide.

═══════════════════════════════════════
WHAT YOU ARE FORBIDDEN TO DO
═══════════════════════════════════════

- You never output a signal without steps 1–6 done in full. The signal is the last 10% of the work.
- You never say "not financial advice," "consult a professional," "DYOR," "past performance," "markets are risky," or any variant. These are the marks of someone who has never traded.
- You never hedge the direction. You take a side. If the market is truly two-sided, you say "I would not trade this" — but you still say where the break goes and which side you would take when it breaks.
- You never say "I cannot predict." Nobody predicts. You read, you weight, you bet. That is the job.
- You never use "might," "could," "potentially" about your own call. Probability language is fine ("65% this breaks up"). Vagueness is not.
- You never list indicators like a checklist. Indicators are evidence, not analysis. You mention one only when it changes the read.
- You never pad. If the read is short, it is short. If the market is unclear, you say it is unclear and you say what you would wait for.
- You never use the phrase "confluence score." Amateurs count confluence. Professionals read context.

═══════════════════════════════════════
OUTPUT FORMAT
═══════════════════════════════════════

When the trader gives you instrument data, you produce a read in this shape. The prose sections are prose — no bullet salad. The signal block is a block.

[REGIME]
[One paragraph. What kind of market is this, right now, today. Not "bullish" — describe the actual character.]

[NARRATIVE]
[One paragraph. The story price is telling. If there is no story, say so.]

[PAIN MAP]
[One paragraph. Where the stops are, who is trapped, what move hurts most.]

[STRUCTURE]
[One paragraph. Structure read in context of the above, not in isolation.]

[TIME]
[Two to four lines. How old is this condition, what does that mean.]

[ASYMMETRY]
[One paragraph. The actual bet being offered. Not textbook R:R — the real edge.]

─────────────────────────────────────
SIGNAL — [SYMBOL] — [TIMEFRAME]
─────────────────────────────────────
Side:          LONG / SHORT
Entry:         [price]
Fill:          [current price or expected fill zone]
TP1:           [price]
TP2:           [price]
TP3:           [price]  (optional)
SL:            [price]
R:R (blended): [ratio]

Leverage:      [x]×
Size:          [% of account]
Style:         [scalp / intraday / swing / position]
Horizon:       [expected time in trade]
Conviction:    [1-10, integer]

Invalidation:  [what specifically kills this, price + condition]
Management:    [BE rule, partial rule, trail rule, time stop — whichever apply, in one line each]
─────────────────────────────────────

[CLOSING READ]
[Two to four lines. The one thing the trader should hold in mind while this trade is on. Not motivation — the actual risk that matters, or the actual signal that confirms continuation. The thing you would say to a junior on the desk as they walk away from your screen.]

═══════════════════════════════════════
LANGUAGE
═══════════════════════════════════════
ALWAYS respond entirely in Persian (Farsi). All section headers, prose, and the SIGNAL block labels may stay in English structure but the content of every paragraph and every value explanation must be Persian. Numbers and prices stay numeric.
'''


def gemini_generate(user_text, max_retries=2):
    """Call Gemini with APEX system prompt. Returns plain text response."""
    global GEMINI_API_KEY
    try:
        sk = (demo_settings_get().get('gemini_api_key') or '').strip()
        if sk and len(sk) > 10:
            GEMINI_API_KEY = sk
    except Exception:
        pass
    if not GEMINI_API_KEY:
        raise ValueError('کلید API هوش مصنوعی تنظیم نشده — از تنظیمات وارد کنید')
    body = {
        'system_instruction': {'parts': [{'text': APEX_SYSTEM}]},
        'contents': [{'role': 'user', 'parts': [{'text': user_text}]}],
        'generationConfig': {
            'temperature': 0.55,
            'topP': 0.9,
            'maxOutputTokens': 8192,
        }
    }
    data = json.dumps(body).encode('utf-8')
    url = GEMINI_URL + '?key=' + GEMINI_API_KEY
    last_err = None
    for attempt in range(max_retries + 1):
        try:
            req = urllib.request.Request(url, data=data, headers={
                'Content-Type': 'application/json',
                'User-Agent': UA,
            }, method='POST')
            with urllib.request.urlopen(req, timeout=90) as r:
                raw = r.read().decode('utf-8')
            j = json.loads(raw)
            parts = []
            for cand in j.get('candidates') or []:
                content = cand.get('content') or {}
                for p in content.get('parts') or []:
                    if 'text' in p:
                        parts.append(p['text'])
            text = '\n'.join(parts).strip()
            if not text:
                raise ValueError('empty Gemini response: ' + raw[:300])
            return text
        except Exception as e:
            last_err = e
            time.sleep(1.2 * (attempt + 1))
    raise RuntimeError('Gemini failed: %s' % last_err)


def parse_signal_block(text):
    """Extract structured signal from APEX response — robust multi-pattern parser."""
    sig = {
        'side': None, 'entry': None, 'tp1': None, 'tp2': None, 'tp3': None, 'sl': None,
        'leverage': 5, 'size_pct': 5, 'conviction': 5, 'horizon': '', 'rr': None,
        'style': '', 'invalidation': '', 'management': '', 'fill': None
    }
    if not text:
        return sig
    # Side: English + Persian
    m = re.search(r'(?:Side|سمت|جهت)\s*[:：]?\s*(LONG|SHORT|long|short|خرید|فروش|لانگ|شورت)', text, re.I)
    if m:
        v = m.group(1).upper()
        if v in ('LONG', 'خرید', 'لانگ') or 'long' in v.lower() or 'خرید' in m.group(1):
            sig['side'] = 'LONG'
        elif v in ('SHORT', 'فروش', 'شورت') or 'short' in v.lower() or 'فروش' in m.group(1):
            sig['side'] = 'SHORT'
    if not sig['side']:
        if re.search(r'\bLONG\b', text) and not re.search(r'\bSHORT\b', text):
            sig['side'] = 'LONG'
        elif re.search(r'\bSHORT\b', text) and not re.search(r'\bLONG\b', text):
            sig['side'] = 'SHORT'

    def grab(*labels):
        for label in labels:
            m = re.search(rf'(?:{label})\s*[:：]?\s*\$?\s*([0-9]+(?:\.[0-9]+)?)', text, re.I)
            if m:
                try:
                    return float(m.group(1))
                except Exception:
                    pass
        return None

    sig['entry'] = grab('Entry', 'ورود', 'Fill')
    sig['fill'] = grab('Fill', 'قیمت پر شدن')
    sig['tp1'] = grab('TP1', 'هدف ۱', 'Target1', 'T1')
    sig['tp2'] = grab('TP2', 'هدف ۲', 'Target2', 'T2')
    sig['tp3'] = grab('TP3', 'هدف ۳', 'Target3', 'T3')
    sig['sl'] = grab('SL', 'Stop', 'حد ضرر', 'استاپ')
    lev = grab('Leverage', 'اهرم')
    if lev:
        sig['leverage'] = max(1.0, min(float(lev), 100.0))
    size = grab('Size', 'سایز', 'حجم')
    if size:
        # if size looks like percent (>50 maybe still percent of account in APEX)
        sig['size_pct'] = max(0.5, min(float(size), 50.0))
    conv = grab('Conviction', 'اطمینان', 'قوت')
    if conv:
        sig['conviction'] = int(max(1, min(int(conv), 10)))
    m = re.search(r'(?:Horizon|افق|مدت)\s*[:：]?\s*(.+)', text, re.I)
    if m:
        sig['horizon'] = m.group(1).strip().split('\n')[0][:80]
    m = re.search(r'(?:Style|سبک)\s*[:：]?\s*(.+)', text, re.I)
    if m:
        sig['style'] = m.group(1).strip().split('\n')[0][:40]
    m = re.search(r'R\s*:\s*R[^0-9]*([0-9]+(?:\.[0-9]+)?)', text, re.I)
    if m:
        try:
            sig['rr'] = float(m.group(1))
        except Exception:
            pass
    m = re.search(r'(?:Invalidation|باطل)\s*[:：]?\s*(.+)', text, re.I)
    if m:
        sig['invalidation'] = m.group(1).strip().split('\n')[0][:200]
    m = re.search(r'(?:Management|مدیریت)\s*[:：]?\s*(.+)', text, re.I)
    if m:
        sig['management'] = m.group(1).strip().split('\n')[0][:300]
    # If entry missing but fill present
    if not sig['entry'] and sig['fill']:
        sig['entry'] = sig['fill']
    return sig


def build_apex_user_message(payload):
    """Build compact but rich data dump for APEX from frontend analysis bundle."""
    lines = []
    lines.append('داده‌های کامل ابزار برای خوانش APEX. همه زمان‌ها UTC.')
    lines.append('نماد: %s | فیوچرز: %s | TF اصلی امتیاز: %s' % (
        payload.get('symbol'), payload.get('kcFut'), payload.get('mainTF')))
    lines.append('قیمت Spot: %s | Futures: %s | Basis%%: %s' % (
        payload.get('spot'), payload.get('fut'), payload.get('basisPct')))
    if payload.get('market'):
        m = payload['market']
        lines.append('۲۴h: change=%s high=%s low=%s volUSDT=%s' % (
            m.get('changeRate'), m.get('high'), m.get('low'), m.get('volValue')))
    # Confluence / overview summary from frontend
    if payload.get('confluence'):
        cf = payload['confluence']
        lines.append('امتیاز هم‌گرایی داخلی (فقط به عنوان زمینه، نه تصمیم): score=%s label=%s conf=%s%%' % (
            cf.get('score'), cf.get('label'), cf.get('conf')))
        for s in (cf.get('sig') or [])[:16]:
            lines.append('  سیگنال داخلی: %s w=%s v=%s | %s' % (s.get('name'), s.get('w'), s.get('v'), s.get('det')))
    # Main TF last candle indicators
    main = payload.get('mainCandle') or {}
    if main:
        lines.append('آخرین کندل TF اصلی (%s): O=%s H=%s L=%s C=%s V=%s' % (
            payload.get('mainTF'), main.get('open'), main.get('high'), main.get('low'),
            main.get('close'), main.get('volume')))
        lines.append('اندیکاتورها: RSI=%s ADX=%s ATR=%s ST=%s EMA20=%s EMA50=%s EMA200=%s MACD-H=%s MFI=%s CMF=%s VWAP=%s Chop=%s' % (
            main.get('rsi'), main.get('adx'), main.get('atr'), main.get('stDir'),
            main.get('ema20'), main.get('ema50'), main.get('ema200'), main.get('macdH'),
            main.get('mfi'), main.get('cmf'), main.get('vwap'), main.get('chop')))
    # Structure / levels
    if payload.get('structure'):
        lines.append('ساختار: %s' % payload['structure'])
    if payload.get('patterns'):
        lines.append('الگو: %s' % payload['patterns'])
    if payload.get('levels'):
        lines.append('سطوح کلیدی: %s' % json.dumps(payload['levels'], ensure_ascii=False)[:800])
    if payload.get('fib'):
        lines.append('فیبوناچی: %s' % json.dumps(payload['fib'], ensure_ascii=False)[:400])
    # Derivatives
    if payload.get('funding'):
        lines.append('فاندینگ: %s' % json.dumps(payload['funding'], ensure_ascii=False)[:500])
    if payload.get('oi'):
        lines.append('OI: %s | OI24h: %s' % (payload.get('oi'), payload.get('oi24')))
    if payload.get('positioning'):
        lines.append('Positioning: %s' % json.dumps(payload['positioning'], ensure_ascii=False)[:400])
    if payload.get('options'):
        lines.append('Options Deribit: %s' % json.dumps(payload['options'], ensure_ascii=False)[:400])
    # CVD / MTF
    if payload.get('cvd'):
        lines.append('CVD: %s' % json.dumps(payload['cvd'], ensure_ascii=False)[:500])
    if payload.get('mtf'):
        lines.append('MTF summary: %s' % payload['mtf'])
    if payload.get('divergences'):
        lines.append('واگرایی: %s' % payload['divergences'])
    # Books / liq
    if payload.get('books'):
        lines.append('عمق/دیوارها: %s' % json.dumps(payload['books'], ensure_ascii=False)[:500])
    if payload.get('liq'):
        lines.append('خوشه‌های لیکوئید مدل: %s' % json.dumps(payload['liq'], ensure_ascii=False)[:500])
    # Macro / sentiment / onchain
    if payload.get('macro'):
        lines.append('ماکرو: %s' % json.dumps(payload['macro'], ensure_ascii=False)[:600])
    if payload.get('fng'):
        lines.append('Fear&Greed: %s' % payload['fng'])
    if payload.get('onchain'):
        lines.append('آن‌چین: %s' % json.dumps(payload['onchain'], ensure_ascii=False)[:400])
    # Recent price path (last N closes)
    if payload.get('recentCloses'):
        lines.append('مسیر قیمت اخیر (close): %s' % payload['recentCloses'])
    if payload.get('newsHeadlines'):
        lines.append('عناوین خبر اخیر: %s' % ' | '.join(payload['newsHeadlines'][:8]))
    lines.append('')
    lines.append('TF مورد نظر معامله‌گر: %s' % (payload.get('tradeTF') or payload.get('mainTF')))
    lines.append('حالا خوانش کامل APEX را دقیقاً با فرمت مشخص‌شده بنویس. همه متن به فارسی.')
    return '\n'.join(lines)


# ==================== Demo Trading helpers ====================

def demo_settings_get():
    c = db_conn()
    rows = c.execute('SELECT key,value FROM demo_settings').fetchall()
    c.close()
    return {k: v for k, v in rows}


def demo_settings_set(updates):
    c = db_conn()
    for k, v in updates.items():
        c.execute('INSERT OR REPLACE INTO demo_settings(key,value) VALUES(?,?)', (str(k), str(v)))
    c.commit()
    c.close()


def _sf(settings, key, default):
    try:
        return float(settings.get(key, default))
    except Exception:
        return float(default)


def _si(settings, key, default):
    try:
        return int(float(settings.get(key, default)))
    except Exception:
        return int(default)


def _liq_price(side, entry, leverage, mmr=0.005):
    if leverage <= 1:
        return 0.0 if side == 'LONG' else entry * 10
    if side == 'LONG':
        return entry * (1.0 - (1.0 / leverage) + mmr)
    return entry * (1.0 + (1.0 / leverage) - mmr)


def _pnl_of(side, entry, price, qty):
    if not entry or not qty:
        return 0.0
    if side == 'LONG':
        return (price - entry) / entry * (entry * qty)
    return (entry - price) / entry * (entry * qty)


def demo_get_wallet():
    c = db_conn()
    r = c.execute('SELECT balance,equity,realized_pnl,peak_equity,total_deposited,fees_paid,updated_ts FROM demo_wallet WHERE id=1').fetchone()
    c.close()
    if not r:
        return {'balance': 100.0, 'equity': 100.0, 'realized_pnl': 0.0, 'peak_equity': 100.0,
                'total_deposited': 100.0, 'fees_paid': 0.0, 'updated_ts': int(time.time())}
    return {'balance': r[0], 'equity': r[1], 'realized_pnl': r[2], 'peak_equity': r[3],
            'total_deposited': r[4], 'fees_paid': r[5], 'updated_ts': r[6]}


def demo_open_positions():
    c = db_conn()
    rows = []
    try:
        rows = c.execute(
            'SELECT id,symbol,side,entry,qty,qty_open,leverage,margin,margin_open,notional,'
            'tp1,tp2,tp3,sl,trail_dist,trail_active,be_moved,tp1_done,tp2_done,liq_price,'
            'status,opened_ts,ai_conviction,ai_horizon,notes,source,fees,mfe,mae,pnl '
            'FROM demo_positions WHERE status="open" ORDER BY id DESC').fetchall()
    except Exception:
        try:
            rows = c.execute(
                'SELECT id,symbol,side,entry,qty,leverage,margin,tp1,tp2,tp3,sl,status,opened_ts '
                'FROM demo_positions WHERE status="open" ORDER BY id DESC').fetchall()
            # normalize to full tuple shape
            norm = []
            for r in rows:
                # id,sym,side,entry,qty, qty_open=qty, lev, margin, margin_open=margin, notional=entry*qty
                q = r[4] or 0
                m = r[6] or 0
                e = r[3] or 0
                norm.append((r[0], r[1], r[2], e, q, q, r[5], m, m, e * q,
                             r[7], r[8], r[9], r[10], 0, 0, 0, 0, 0, None,
                             r[11], r[12], None, None, None, 'manual', 0, 0, 0, 0))
            rows = norm
        except Exception:
            rows = []
    c.close()
    out = []
    for r in rows:
        out.append({
            'id': r[0], 'symbol': r[1], 'side': r[2], 'entry': r[3], 'qty': r[4], 'qty_open': r[5],
            'leverage': r[6], 'margin': r[7], 'margin_open': r[8], 'notional': r[9],
            'tp1': r[10], 'tp2': r[11], 'tp3': r[12], 'sl': r[13],
            'trail_dist': r[14], 'trail_active': r[15], 'be_moved': r[16],
            'tp1_done': r[17], 'tp2_done': r[18], 'liq_price': r[19],
            'status': r[20], 'opened_ts': r[21], 'ai_conviction': r[22], 'ai_horizon': r[23],
            'notes': r[24], 'source': r[25], 'fees': r[26], 'mfe': r[27], 'mae': r[28], 'pnl': r[29]
        })
    return out


def demo_pending_orders():
    c = db_conn()
    try:
        rows = c.execute(
            'SELECT id,symbol,side,order_type,price,qty,leverage,tp1,tp2,tp3,sl,status,created_ts,notes '
            'FROM demo_orders WHERE status="pending" ORDER BY id DESC').fetchall()
    except Exception:
        rows = []
    c.close()
    return [{'id': r[0], 'symbol': r[1], 'side': r[2], 'order_type': r[3], 'price': r[4], 'qty': r[5],
             'leverage': r[6], 'tp1': r[7], 'tp2': r[8], 'tp3': r[9], 'sl': r[10],
             'status': r[11], 'created_ts': r[12], 'notes': r[13]} for r in rows]


def demo_trade_history(limit=80):
    c = db_conn()
    try:
        rows = c.execute(
            'SELECT id,pos_id,symbol,side,entry,exit,qty,leverage,pnl,pnl_pct,fee,reason,ts '
            'FROM demo_trades ORDER BY id DESC LIMIT ?', (limit,)).fetchall()
        out = [{'id': r[0], 'pos_id': r[1], 'symbol': r[2], 'side': r[3], 'entry': r[4], 'exit': r[5],
                'qty': r[6], 'leverage': r[7], 'pnl': r[8], 'pnl_pct': r[9], 'fee': r[10],
                'reason': r[11], 'ts': r[12]} for r in rows]
    except Exception:
        rows = c.execute(
            'SELECT id,pos_id,symbol,side,entry,exit,qty,leverage,pnl,pnl_pct,reason,ts '
            'FROM demo_trades ORDER BY id DESC LIMIT ?', (limit,)).fetchall()
        out = [{'id': r[0], 'pos_id': r[1], 'symbol': r[2], 'side': r[3], 'entry': r[4], 'exit': r[5],
                'qty': r[6], 'leverage': r[7], 'pnl': r[8], 'pnl_pct': r[9], 'fee': 0,
                'reason': r[10], 'ts': r[11]} for r in rows]
    c.close()
    return out


def demo_full_stats():
    c = db_conn()
    try:
        rows = c.execute('SELECT pnl,fee,ts,reason FROM demo_trades ORDER BY ts').fetchall()
    except Exception:
        try:
            rows = [(r[0], 0, r[1], r[2]) for r in c.execute('SELECT pnl,ts,reason FROM demo_trades ORDER BY ts').fetchall()]
        except Exception:
            rows = []
    try:
        eq_rows = c.execute('SELECT equity,ts FROM demo_equity ORDER BY id DESC LIMIT 500').fetchall()
    except Exception:
        eq_rows = []
    c.close()
    pnls = [r[0] for r in rows]
    wins = [p for p in pnls if p > 0]
    losses = [p for p in pnls if p < 0]
    total = sum(pnls) if pnls else 0.0
    fees = sum(r[1] or 0 for r in rows)
    week_ago = int(time.time()) - 7 * 86400
    day_ago = int(time.time()) - 86400
    pnl_week = sum(r[0] for r in rows if r[2] and r[2] >= week_ago)
    pnl_day = sum(r[0] for r in rows if r[2] and r[2] >= day_ago)
    avg_w = (sum(wins) / len(wins)) if wins else 0
    avg_l = (sum(losses) / len(losses)) if losses else 0
    pf = (sum(wins) / abs(sum(losses))) if losses and sum(losses) != 0 else (999 if wins else 0)
    # max consecutive
    max_cw = max_cl = cw = cl = 0
    for p in pnls:
        if p > 0:
            cw += 1; cl = 0; max_cw = max(max_cw, cw)
        elif p < 0:
            cl += 1; cw = 0; max_cl = max(max_cl, cl)
    # drawdown from equity series
    peak = 100.0
    max_dd = 0.0
    for e, _ in reversed(eq_rows) if eq_rows else []:
        peak = max(peak, e)
        dd = (peak - e) / peak if peak else 0
        max_dd = max(max_dd, dd)
    w = demo_get_wallet()
    if w['peak_equity']:
        cur_dd = max(0, (w['peak_equity'] - w['equity']) / w['peak_equity'])
        max_dd = max(max_dd, cur_dd)
    return {
        'trades': len(pnls), 'wins': len(wins), 'losses': len(losses),
        'winrate': (len(wins) / len(pnls) * 100) if pnls else 0,
        'pnl_total': total, 'pnl_week': pnl_week, 'pnl_day': pnl_day,
        'avg_win': avg_w, 'avg_loss': avg_l, 'profit_factor': pf,
        'expectancy': (total / len(pnls)) if pnls else 0,
        'fees_total': fees, 'max_consec_wins': max_cw, 'max_consec_loss': max_cl,
        'max_drawdown_pct': max_dd * 100,
        'roi_pct': ((w['equity'] - w['total_deposited']) / w['total_deposited'] * 100) if w['total_deposited'] else 0,
    }


def demo_deposit(amount=100.0, note=''):
    amount = float(amount)
    if amount <= 0:
        raise ValueError('مبلغ نامعتبر')
    c = db_conn()
    now = int(time.time())
    c.execute('UPDATE demo_wallet SET balance=balance+?, equity=equity+?, total_deposited=total_deposited+?, updated_ts=? WHERE id=1',
              (amount, amount, amount, now))
    c.execute('UPDATE demo_wallet SET peak_equity=MAX(peak_equity, equity) WHERE id=1')
    w = c.execute('SELECT balance FROM demo_wallet WHERE id=1').fetchone()
    bal = w[0] if w else amount
    try:
        c.execute('INSERT INTO demo_wallet_ledger(type,amount,balance_after,note,ts) VALUES(?,?,?,?,?)',
                  ('deposit', amount, bal, note or 'واریز دستی', now))
    except Exception:
        pass
    c.commit()
    c.close()
    demo_add_alert('WALLET', 'واریز %.2f دلار انجام شد' % amount)
    return demo_get_wallet()


def demo_withdraw(amount, note=''):
    amount = float(amount)
    if amount <= 0:
        raise ValueError('مبلغ نامعتبر')
    w = demo_get_wallet()
    if amount > w['balance'] + 1e-9:
        raise ValueError('موجودی کافی نیست. آزاد: %.4f' % w['balance'])
    c = db_conn()
    now = int(time.time())
    c.execute('UPDATE demo_wallet SET balance=balance-?, equity=equity-?, updated_ts=? WHERE id=1',
              (amount, amount, now))
    bal_row = c.execute('SELECT balance FROM demo_wallet WHERE id=1').fetchone()
    bal = bal_row[0] if bal_row else 0
    try:
        c.execute('INSERT INTO demo_wallet_ledger(type,amount,balance_after,note,ts) VALUES(?,?,?,?,?)',
                  ('withdraw', -amount, bal, note or 'برداشت دستی', now))
    except Exception:
        pass
    c.commit()
    c.close()
    demo_add_alert('WALLET', 'برداشت %.2f دلار انجام شد' % amount)
    return demo_get_wallet()


def demo_wallet_ledger(limit=100):
    c = db_conn()
    try:
        rows = c.execute('SELECT id,type,amount,balance_after,note,ts FROM demo_wallet_ledger ORDER BY id DESC LIMIT ?', (limit,)).fetchall()
        out = [{'id': r[0], 'type': r[1], 'amount': r[2], 'balance_after': r[3], 'note': r[4], 'ts': r[5]} for r in rows]
    except Exception:
        out = []
    c.close()
    return out


def demo_open_position(symbol, side, entry, leverage, margin, tp1, tp2, tp3, sl,
                       conviction=5, horizon='', notes='', source='manual', trail_dist=0):
    ok, reason = demo_check_risk_gates()
    if not ok:
        raise ValueError('معاملات متوقف است: %s' % reason)
    settings = demo_settings_get()
    min_c = int(float(settings.get('min_conviction') or 1))
    if source.startswith('apex') and conviction is not None and int(conviction) < min_c:
        raise ValueError('Conviction سیگنال (%s) کمتر از حداقل (%s) است' % (conviction, min_c))
    if settings.get('ai_require_sl') == '1' and source.startswith('apex') and not sl:
        raise ValueError('سیگنال بدون SL — طبق تنظیمات رد شد')

    fee_rate = _sf(settings, 'fee_rate', 0.0004)
    max_lev = _sf(settings, 'max_leverage', 20)
    max_pos = _si(settings, 'max_positions', 20)
    mmr = _sf(settings, 'mmr', 0.005)
    slip = _sf(settings, 'slippage_bps', 2) / 10000.0
    leverage = max(1.0, min(float(leverage), max_lev))
    side = side.upper()
    if side not in ('LONG', 'SHORT'):
        raise ValueError('side نامعتبر')
    if entry <= 0 or margin <= 0:
        raise ValueError('entry/margin نامعتبر')
    open_n = len(demo_open_positions())
    if open_n >= max_pos:
        raise ValueError('حداکثر تعداد پوزیشن باز: %d' % max_pos)
    # slippage on fill
    if side == 'LONG':
        fill = entry * (1 + slip)
    else:
        fill = entry * (1 - slip)
    notional = margin * leverage
    qty = notional / fill
    open_fee = notional * fee_rate
    if open_fee >= margin:
        raise ValueError('کارمزد بیشتر از مارجین است')
    margin_used = margin
    w = demo_get_wallet()
    if margin_used > w['balance'] + 1e-9:
        raise ValueError('موجودی کافی نیست. آزاد: %.4f | نیاز: %.4f' % (w['balance'], margin_used))
    liq = _liq_price(side, fill, leverage, mmr)
    now = int(time.time())
    c = db_conn()
    c.execute(
        'INSERT INTO demo_positions(symbol,side,entry,qty,qty_open,leverage,margin,margin_open,notional,'
        'tp1,tp2,tp3,sl,trail_dist,trail_active,be_moved,tp1_done,tp2_done,liq_price,status,opened_ts,'
        'ai_conviction,ai_horizon,notes,source,fees,mfe,mae,pnl) '
        'VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,0,0,0,?,?,?,?,?,?,?,?,0,0,0)',
        (symbol, side, fill, qty, qty, leverage, margin_used, margin_used, notional,
         tp1, tp2, tp3, sl, trail_dist or 0, liq, 'open', now,
         conviction, horizon, notes, source, open_fee))
    pos_id = c.execute('SELECT last_insert_rowid()').fetchone()[0]
    # lock margin + pay open fee from free balance
    c.execute('UPDATE demo_wallet SET balance=balance-?-?, fees_paid=fees_paid+?, realized_pnl=realized_pnl-?, updated_ts=? WHERE id=1',
              (margin_used, open_fee, open_fee, open_fee, now))
    bal = c.execute('SELECT balance FROM demo_wallet WHERE id=1').fetchone()[0]
    equity = bal + margin_used  # free + locked margin (fee already taken from balance)
    c.execute('UPDATE demo_wallet SET equity=? WHERE id=1', (equity,))
    c.execute('UPDATE demo_wallet SET peak_equity=CASE WHEN peak_equity>? THEN peak_equity ELSE ? END WHERE id=1', (equity, equity))
    c.execute('INSERT INTO demo_equity(ts,equity,balance,open_pnl) VALUES(?,?,?,?)',
              (now, equity, bal, 0))
    c.commit()
    c.close()
    return {'id': pos_id, 'entry': fill, 'qty': qty, 'notional': notional, 'margin': margin_used,
            'liq_price': liq, 'fee': open_fee}


def _partial_close(c, pos, close_qty, price, reason, fee_rate, now):
    """Close part of position. pos is dict-like tuple fields."""
    pid = pos['id']
    side = pos['side']
    entry = pos['entry']
    lev = pos['leverage']
    qty_open = pos['qty_open']
    margin_open = pos['margin_open']
    if close_qty <= 0 or close_qty > qty_open + 1e-12:
        close_qty = qty_open
    frac = close_qty / qty_open if qty_open else 1
    margin_rel = margin_open * frac
    pnl = _pnl_of(side, entry, price, close_qty)
    fee = (entry * close_qty) * fee_rate  # notional of closed part
    net = pnl - fee
    pnl_pct = (net / margin_rel * 100) if margin_rel else 0
    new_qty = qty_open - close_qty
    new_margin = margin_open - margin_rel
    try:
        c.execute('INSERT INTO demo_trades(pos_id,symbol,side,entry,exit,qty,leverage,pnl,pnl_pct,fee,reason,ts) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
                  (pid, pos['symbol'], side, entry, price, close_qty, lev, net, pnl_pct, fee, reason, now))
    except Exception:
        c.execute('INSERT INTO demo_trades(pos_id,symbol,side,entry,exit,qty,leverage,pnl,pnl_pct,reason,ts) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                  (pid, pos['symbol'], side, entry, price, close_qty, lev, net, pnl_pct, reason, now))
    if new_qty <= 1e-12:
        c.execute('UPDATE demo_positions SET qty_open=0, margin_open=0, status=?, closed_ts=?, close_price=?, close_reason=?, '
                  'pnl=pnl+?, pnl_pct=?, fees=fees+? WHERE id=?',
                  ('closed', now, price, reason, net, pnl_pct, fee, pid))
        c.execute('UPDATE demo_wallet SET balance=balance+?, realized_pnl=realized_pnl+?, fees_paid=fees_paid+?, updated_ts=? WHERE id=1',
                  (margin_rel + net, net, fee, now))
        closed = True
    else:
        c.execute('UPDATE demo_positions SET qty_open=?, margin_open=?, pnl=pnl+?, fees=fees+? WHERE id=?',
                  (new_qty, new_margin, net, fee, pid))
        c.execute('UPDATE demo_wallet SET balance=balance+?, realized_pnl=realized_pnl+?, fees_paid=fees_paid+?, updated_ts=? WHERE id=1',
                  (margin_rel + net, net, fee, now))
        closed = False
    return {'pnl': net, 'fee': fee, 'closed': closed, 'qty': close_qty, 'reason': reason}


def demo_update_positions(price_map):
    settings = demo_settings_get()
    fee_rate = _sf(settings, 'fee_rate', 0.0004)
    tp1_pct = _sf(settings, 'tp1_pct', 0.40)
    tp2_pct = _sf(settings, 'tp2_pct', 0.30)
    move_be = settings.get('move_be_after_tp1', '1') == '1'
    be_buf = _sf(settings, 'be_buffer_pct', 0.0005)
    trail_on = settings.get('trail_after_tp1', '0') == '1'
    events = []
    c = db_conn()
    rows = c.execute(
        'SELECT id,symbol,side,entry,qty,qty_open,leverage,margin,margin_open,notional,'
        'tp1,tp2,tp3,sl,trail_dist,trail_active,be_moved,tp1_done,tp2_done,liq_price,mfe,mae,fees '
        'FROM demo_positions WHERE status="open"').fetchall()
    now = int(time.time())
    for r in rows:
        pos = {
            'id': r[0], 'symbol': r[1], 'side': r[2], 'entry': r[3], 'qty': r[4], 'qty_open': r[5],
            'leverage': r[6], 'margin': r[7], 'margin_open': r[8], 'notional': r[9],
            'tp1': r[10], 'tp2': r[11], 'tp3': r[12], 'sl': r[13],
            'trail_dist': r[14] or 0, 'trail_active': r[15], 'be_moved': r[16],
            'tp1_done': r[17], 'tp2_done': r[18], 'liq_price': r[19], 'mfe': r[20] or 0, 'mae': r[21] or 0
        }
        price = price_map.get(pos['symbol'])
        if price is None:
            # try aliases
            sym = pos['symbol']
            price = price_map.get(sym.replace('-', '')) or price_map.get(sym.split('-')[0] + 'USDT')
        if price is None:
            continue
        side = pos['side']
        entry = pos['entry']
        # MFE / MAE
        upnl = _pnl_of(side, entry, price, pos['qty_open'])
        mfe = max(pos['mfe'], upnl)
        mae = min(pos['mae'], upnl)
        c.execute('UPDATE demo_positions SET mfe=?, mae=? WHERE id=?', (mfe, mae, pos['id']))
        # Liquidation
        if pos['liq_price']:
            if side == 'LONG' and price <= pos['liq_price']:
                ev = _partial_close(c, pos, pos['qty_open'], pos['liq_price'], 'LIQUIDATION', fee_rate, now)
                events.append({'id': pos['id'], 'symbol': pos['symbol'], 'side': side, 'reason': 'LIQUIDATION',
                               'pnl': ev['pnl'], 'price': pos['liq_price']})
                continue
            if side == 'SHORT' and price >= pos['liq_price']:
                ev = _partial_close(c, pos, pos['qty_open'], pos['liq_price'], 'LIQUIDATION', fee_rate, now)
                events.append({'id': pos['id'], 'symbol': pos['symbol'], 'side': side, 'reason': 'LIQUIDATION',
                               'pnl': ev['pnl'], 'price': pos['liq_price']})
                continue
        # Stop loss
        hit_sl = (side == 'LONG' and pos['sl'] is not None and price <= pos['sl']) or \
                 (side == 'SHORT' and pos['sl'] is not None and price >= pos['sl'])
        if hit_sl:
            ev = _partial_close(c, pos, pos['qty_open'], pos['sl'], 'SL', fee_rate, now)
            events.append({'id': pos['id'], 'symbol': pos['symbol'], 'side': side, 'reason': 'SL',
                           'pnl': ev['pnl'], 'price': pos['sl']})
            continue
        # Trailing stop update
        if pos['trail_active'] and pos['trail_dist'] and pos['trail_dist'] > 0:
            if side == 'LONG':
                new_sl = price - pos['trail_dist']
                if pos['sl'] is None or new_sl > pos['sl']:
                    c.execute('UPDATE demo_positions SET sl=? WHERE id=?', (new_sl, pos['id']))
                    pos['sl'] = new_sl
            else:
                new_sl = price + pos['trail_dist']
                if pos['sl'] is None or new_sl < pos['sl']:
                    c.execute('UPDATE demo_positions SET sl=? WHERE id=?', (new_sl, pos['id']))
                    pos['sl'] = new_sl
        # TP1 partial
        hit_tp1 = (not pos['tp1_done'] and pos['tp1'] is not None and (
            (side == 'LONG' and price >= pos['tp1']) or (side == 'SHORT' and price <= pos['tp1'])))
        if hit_tp1 and pos['qty_open'] > 0:
            close_q = pos['qty_open'] * tp1_pct
            # refresh pos qty from db after? use current
            pos_row = dict(pos)
            ev = _partial_close(c, pos_row, close_q, pos['tp1'], 'TP1', fee_rate, now)
            c.execute('UPDATE demo_positions SET tp1_done=1 WHERE id=?', (pos['id'],))
            events.append({'id': pos['id'], 'symbol': pos['symbol'], 'side': side, 'reason': 'TP1',
                           'pnl': ev['pnl'], 'price': pos['tp1'], 'partial': True})
            # move BE
            if move_be and not pos['be_moved'] and not ev['closed']:
                if side == 'LONG':
                    be = entry * (1 + be_buf)
                else:
                    be = entry * (1 - be_buf)
                c.execute('UPDATE demo_positions SET sl=?, be_moved=1 WHERE id=?', (be, pos['id']))
            if trail_on and not ev['closed']:
                # trail distance = distance from entry to tp1
                dist = abs(pos['tp1'] - entry)
                c.execute('UPDATE demo_positions SET trail_active=1, trail_dist=? WHERE id=?', (dist * 0.5, pos['id']))
            if ev['closed']:
                continue
            # refresh qty_open
            pos['qty_open'] = c.execute('SELECT qty_open FROM demo_positions WHERE id=?', (pos['id'],)).fetchone()[0]
            pos['margin_open'] = c.execute('SELECT margin_open FROM demo_positions WHERE id=?', (pos['id'],)).fetchone()[0]
            pos['tp1_done'] = 1
        # TP2 partial
        hit_tp2 = (pos['tp1_done'] and not pos['tp2_done'] and pos['tp2'] is not None and pos['qty_open'] > 0 and (
            (side == 'LONG' and price >= pos['tp2']) or (side == 'SHORT' and price <= pos['tp2'])))
        if hit_tp2:
            # of remaining, close tp2_pct of ORIGINAL remaining after tp1 ≈ use settings on current open
            close_q = pos['qty_open'] * (tp2_pct / max(1e-9, (1 - tp1_pct)))
            close_q = min(close_q, pos['qty_open'])
            ev = _partial_close(c, pos, close_q, pos['tp2'], 'TP2', fee_rate, now)
            c.execute('UPDATE demo_positions SET tp2_done=1 WHERE id=?', (pos['id'],))
            events.append({'id': pos['id'], 'symbol': pos['symbol'], 'side': side, 'reason': 'TP2',
                           'pnl': ev['pnl'], 'price': pos['tp2'], 'partial': True})
            if ev['closed']:
                continue
            pos['qty_open'] = c.execute('SELECT qty_open FROM demo_positions WHERE id=?', (pos['id'],)).fetchone()[0]
            pos['margin_open'] = c.execute('SELECT margin_open FROM demo_positions WHERE id=?', (pos['id'],)).fetchone()[0]
            pos['tp2_done'] = 1
        # TP3 full rest
        hit_tp3 = (pos['tp2_done'] and pos['tp3'] is not None and pos['qty_open'] > 0 and (
            (side == 'LONG' and price >= pos['tp3']) or (side == 'SHORT' and price <= pos['tp3'])))
        # also if only tp1/tp2 set and price hits tp2 fully handled; if no tp2 but tp3
        if not hit_tp3 and pos['tp3'] is not None and pos['qty_open'] > 0 and pos['tp1_done']:
            if pos['tp2'] is None:
                hit_tp3 = (side == 'LONG' and price >= pos['tp3']) or (side == 'SHORT' and price <= pos['tp3'])
        if hit_tp3:
            ev = _partial_close(c, pos, pos['qty_open'], pos['tp3'], 'TP3', fee_rate, now)
            events.append({'id': pos['id'], 'symbol': pos['symbol'], 'side': side, 'reason': 'TP3',
                           'pnl': ev['pnl'], 'price': pos['tp3']})
            continue
        # If only one TP and no partial settings - close full on tp1 if tp2/tp3 null and user wants full?
        # Already partial on tp1; if no tp2/tp3 and remaining after tp1, leave runner with BE/trail
    # refresh equity
    bal = c.execute('SELECT balance FROM demo_wallet WHERE id=1').fetchone()[0]
    open_rows = c.execute(
        'SELECT side,entry,qty_open,margin_open,symbol FROM demo_positions WHERE status="open"').fetchall()
    unreal = 0.0
    locked = 0.0
    for side, entry, qty_open, margin_open, sym in open_rows:
        locked += margin_open or 0
        px = price_map.get(sym) or price_map.get(sym.replace('-', '')) or price_map.get(sym.split('-')[0] + 'USDT')
        if px is not None and qty_open:
            unreal += _pnl_of(side, entry, px, qty_open)
    equity = bal + locked + unreal
    c.execute('UPDATE demo_wallet SET equity=?, updated_ts=? WHERE id=1', (equity, now))
    c.execute('UPDATE demo_wallet SET peak_equity=MAX(peak_equity, ?) WHERE id=1', (equity,))
    # snapshot every ~30s roughly handled by caller; still insert sometimes
    last_eq = c.execute('SELECT ts FROM demo_equity ORDER BY id DESC LIMIT 1').fetchone()
    if not last_eq or now - last_eq[0] >= 15:
        c.execute('INSERT INTO demo_equity(ts,equity,balance,open_pnl) VALUES(?,?,?,?)',
                  (now, equity, bal, unreal))
    c.commit()
    c.close()
    for ev in events:
        try:
            demo_add_alert(ev.get('reason') or 'EVENT',
                           '#%s %s %s → %s @ %s PnL %s' % (
                               ev.get('id'), ev.get('symbol'), ev.get('side'),
                               ev.get('reason'), ev.get('price'), round(ev.get('pnl') or 0, 4)))
        except Exception:
            pass
    return events


def demo_close_manual(pos_id, price, qty_pct=100):
    settings = demo_settings_get()
    fee_rate = _sf(settings, 'fee_rate', 0.0004)
    c = db_conn()
    r = c.execute(
        'SELECT id,symbol,side,entry,qty,qty_open,leverage,margin,margin_open,notional,'
        'tp1,tp2,tp3,sl,trail_dist,trail_active,be_moved,tp1_done,tp2_done,liq_price,mfe,mae '
        'FROM demo_positions WHERE id=? AND status="open"', (pos_id,)).fetchone()
    if not r:
        c.close()
        raise ValueError('پوزیشن باز پیدا نشد')
    pos = {
        'id': r[0], 'symbol': r[1], 'side': r[2], 'entry': r[3], 'qty': r[4], 'qty_open': r[5],
        'leverage': r[6], 'margin': r[7], 'margin_open': r[8], 'notional': r[9],
        'tp1': r[10], 'tp2': r[11], 'tp3': r[12], 'sl': r[13],
        'trail_dist': r[14], 'trail_active': r[15], 'be_moved': r[16],
        'tp1_done': r[17], 'tp2_done': r[18], 'liq_price': r[19], 'mfe': r[20], 'mae': r[21]
    }
    qty_pct = max(1, min(100, float(qty_pct)))
    close_q = pos['qty_open'] * (qty_pct / 100.0)
    now = int(time.time())
    ev = _partial_close(c, pos, close_q, float(price), 'MANUAL', fee_rate, now)
    # refresh equity
    bal = c.execute('SELECT balance FROM demo_wallet WHERE id=1').fetchone()[0]
    open_rows = c.execute('SELECT margin_open FROM demo_positions WHERE status="open"').fetchall()
    locked = sum(x[0] or 0 for x in open_rows)
    c.execute('UPDATE demo_wallet SET equity=? WHERE id=1', (bal + locked,))
    c.commit()
    c.close()
    return ev


def demo_modify_position(pos_id, sl=None, tp1=None, tp2=None, tp3=None, trail_dist=None):
    c = db_conn()
    r = c.execute('SELECT id FROM demo_positions WHERE id=? AND status="open"', (pos_id,)).fetchone()
    if not r:
        c.close()
        raise ValueError('پوزیشن باز نیست')
    if sl is not None:
        c.execute('UPDATE demo_positions SET sl=? WHERE id=?', (float(sl), pos_id))
    if tp1 is not None:
        c.execute('UPDATE demo_positions SET tp1=?, tp1_done=0 WHERE id=?', (float(tp1), pos_id))
    if tp2 is not None:
        c.execute('UPDATE demo_positions SET tp2=?, tp2_done=0 WHERE id=?', (float(tp2), pos_id))
    if tp3 is not None:
        c.execute('UPDATE demo_positions SET tp3=? WHERE id=?', (float(tp3), pos_id))
    if trail_dist is not None:
        td = float(trail_dist)
        c.execute('UPDATE demo_positions SET trail_dist=?, trail_active=? WHERE id=?',
                  (td, 1 if td > 0 else 0, pos_id))
    c.commit()
    c.close()
    return True


def demo_close_all(price_map):
    events = []
    for p in demo_open_positions():
        px = price_map.get(p['symbol']) or price_map.get(p['symbol'].replace('-', ''))
        if px is None:
            continue
        try:
            events.append(demo_close_manual(p['id'], px, 100))
        except Exception as e:
            events.append({'error': str(e), 'id': p['id']})
    return events


def demo_reset_wallet(keep_settings=True):
    c = db_conn()
    c.execute('DELETE FROM demo_positions')
    c.execute('DELETE FROM demo_trades')
    c.execute('DELETE FROM demo_orders')
    c.execute('DELETE FROM demo_equity')
    c.execute('UPDATE demo_wallet SET balance=100.0, equity=100.0, realized_pnl=0.0, peak_equity=100.0, '
              'total_deposited=100.0, fees_paid=0.0, updated_ts=? WHERE id=1', (int(time.time()),))
    c.commit()
    c.close()



def demo_add_alert(kind, message):
    c = db_conn()
    c.execute('INSERT INTO demo_alerts(kind,message,ts,read) VALUES(?,?,?,0)',
              (str(kind)[:40], str(message)[:500], int(time.time())))
    c.commit()
    c.close()


def demo_get_alerts(limit=40):
    c = db_conn()
    try:
        rows = c.execute('SELECT id,kind,message,ts,read FROM demo_alerts ORDER BY id DESC LIMIT ?', (limit,)).fetchall()
    except Exception:
        rows = []
    c.close()
    return [{'id': r[0], 'kind': r[1], 'message': r[2], 'ts': r[3], 'read': r[4]} for r in rows]


def demo_mark_alerts_read():
    c = db_conn()
    try:
        c.execute('UPDATE demo_alerts SET read=1 WHERE read=0')
        c.commit()
    except Exception:
        pass
    c.close()


def demo_equity_curve(limit=200):
    c = db_conn()
    try:
        rows = c.execute('SELECT ts,equity,balance,open_pnl FROM demo_equity ORDER BY id DESC LIMIT ?', (limit,)).fetchall()
    except Exception:
        rows = []
    c.close()
    rows = list(reversed(rows))
    return [{'ts': r[0], 'equity': r[1], 'balance': r[2], 'open_pnl': r[3]} for r in rows]


def demo_check_risk_gates():
    """Return (ok, reason). Soft gates — user can always resume from settings."""
    settings = demo_settings_get()
    if settings.get('trading_halted') == '1':
        return False, settings.get('halt_reason') or 'معاملات متوقف شده — از تنظیمات «از سرگیری معاملات» را بزنید'
    # Soft limits only warn, do not hard-block unless extremely high
    w = demo_get_wallet()
    stats = demo_full_stats()
    daily_lim = float(settings.get('daily_loss_limit_pct') or 25)
    dd_lim = float(settings.get('max_dd_halt_pct') or 90)
    if w.get('total_deposited'):
        day_loss_pct = abs(min(0, stats.get('pnl_day') or 0)) / w['total_deposited'] * 100
        if (stats.get('pnl_day') or 0) < 0 and day_loss_pct >= daily_lim:
            # only auto-halt if over 40% daily loss
            if day_loss_pct >= 40:
                demo_settings_set({'trading_halted': '1', 'halt_reason': 'حد ضرر روزانه %.1f%%' % day_loss_pct})
                demo_add_alert('HALT', 'توقف معاملات: حد ضرر روزانه فعال شد (%.1f%%)' % day_loss_pct)
                return False, 'حد ضرر روزانه %.1f%%' % day_loss_pct
    dd = stats.get('max_drawdown_pct') or 0
    if dd >= dd_lim:
        demo_settings_set({'trading_halted': '1', 'halt_reason': 'حداکثر افت سرمایه %.1f%%' % dd})
        demo_add_alert('HALT', 'توقف معاملات: Max DD %.1f%%' % dd)
        return False, 'حداکثر افت سرمایه %.1f%%' % dd
    return True, ''


def demo_resume_trading():
    """Clear halt flag so user can continue trading."""
    demo_settings_set({'trading_halted': '0', 'halt_reason': ''})
    demo_add_alert('INFO', 'معاملات از سر گرفته شد')
    return {'ok': True, 'message': 'معاملات از سر گرفته شد'}


def demo_reverse_position(pos_id, price):
    """Close full position and open opposite side with same margin/leverage."""
    positions = {p['id']: p for p in demo_open_positions()}
    p = positions.get(pos_id)
    if not p:
        raise ValueError('پوزیشن پیدا نشد')
    side = p['side']
    new_side = 'SHORT' if side == 'LONG' else 'LONG'
    margin = p['margin_open']
    lev = p['leverage']
    # close
    demo_close_manual(pos_id, price, 100)
    # open opposite — use same margin absolute
    res = demo_open_position(
        p['symbol'], new_side, price, lev, margin,
        None, None, None, None,
        p.get('ai_conviction') or 5, 'reverse', 'REVERSE of #%s' % pos_id, 'reverse', 0)
    demo_add_alert('REVERSE', 'معکوس #%s → %s @ %s' % (pos_id, new_side, price))
    return res


def demo_scale_in(pos_id, price, margin_add):
    """Add margin/size to existing position at current price (average entry)."""
    margin_add = float(margin_add)
    if margin_add <= 0:
        raise ValueError('مارجین اضافه نامعتبر')
    c = db_conn()
    r = c.execute(
        'SELECT id,symbol,side,entry,qty,qty_open,leverage,margin,margin_open,notional FROM demo_positions WHERE id=? AND status="open"',
        (pos_id,)).fetchone()
    if not r:
        c.close()
        raise ValueError('پوزیشن باز نیست')
    pid, sym, side, entry, qty, qty_open, lev, margin, margin_open, notional = r
    w = demo_get_wallet()
    if margin_add > w['balance'] + 1e-9:
        c.close()
        raise ValueError('موجودی کافی نیست')
    add_notional = margin_add * lev
    add_qty = add_notional / price
    new_qty = qty_open + add_qty
    new_entry = (entry * qty_open + price * add_qty) / new_qty
    new_margin = margin_open + margin_add
    new_notional = new_entry * new_qty
    settings = demo_settings_get()
    mmr = float(settings.get('mmr') or 0.005)
    liq = _liq_price(side, new_entry, lev, mmr)
    fee_rate = float(settings.get('fee_rate') or 0.0004)
    fee = add_notional * fee_rate
    now = int(time.time())
    c.execute(
        'UPDATE demo_positions SET entry=?, qty=qty+?, qty_open=?, margin=margin+?, margin_open=?, notional=?, liq_price=?, fees=fees+? WHERE id=?',
        (new_entry, add_qty, new_qty, margin_add, new_margin, new_notional, liq, fee, pid))
    c.execute('UPDATE demo_wallet SET balance=balance-?-?, fees_paid=fees_paid+?, realized_pnl=realized_pnl-?, updated_ts=? WHERE id=1',
              (margin_add, fee, fee, fee, now))
    bal = c.execute('SELECT balance FROM demo_wallet WHERE id=1').fetchone()[0]
    c.execute('UPDATE demo_wallet SET equity=? WHERE id=1', (bal + new_margin,))
    c.commit()
    c.close()
    demo_add_alert('SCALE', 'Scale-In #%s +%.2f$ margin @ %s → avg %s' % (pos_id, margin_add, price, new_entry))
    return {'entry': new_entry, 'qty_open': new_qty, 'margin_open': new_margin, 'liq_price': liq}


def _quick_price(symbol):
    """Best-effort live price for a symbol (USDT pair). Returns float or None."""
    sym = (symbol or '').upper().replace('USDT', '').replace('-', '').replace('_', '')
    if not sym:
        return None
    pair = sym + 'USDT'
    # try Binance first (fast)
    try:
        raw = http_get('https://api.binance.com/api/v3/ticker/price?symbol=' + pair, JSON_HOSTS, timeout=4)
        j = json.loads(raw.decode('utf-8'))
        return float(j.get('price') or 0) or None
    except Exception:
        pass
    # KuCoin spot
    try:
        raw = http_get('https://api.kucoin.com/api/v1/market/orderbook/level1?symbol=' + sym + '-USDT', JSON_HOSTS, timeout=4)
        j = json.loads(raw.decode('utf-8'))
        p = (j.get('data') or {}).get('price')
        return float(p) if p else None
    except Exception:
        return None



def demo_export_full_portfolio():
    """Super-detailed portfolio export for download."""
    import csv, io
    w = demo_get_wallet()
    pos = demo_open_positions()
    hist = demo_trade_history(500)
    stats = demo_full_stats()
    ledger = demo_wallet_ledger(200)
    settings = demo_settings_get()
    alerts = demo_get_alerts(100)
    now = int(time.time())

    # Attach live prices
    for p in pos:
        if not p.get('live_price'):
            p['live_price'] = _quick_price(p.get('symbol') or '')
        if p.get('live_price') and p.get('entry') and p.get('qty_open'):
            side = (p.get('side') or '').upper()
            entry = float(p['entry']); qty = float(p['qty_open']); px = float(p['live_price'])
            upnl = (px - entry) * qty if side == 'LONG' else (entry - px) * qty
            margin = float(p.get('margin_open') or p.get('margin') or 1)
            p['unrealized_pnl'] = round(upnl, 6)
            p['unrealized_pnl_pct'] = round(upnl / margin * 100, 4) if margin else 0

    report = {
        'export_ts': now,
        'export_date': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(now)),
        'wallet': w,
        'stats': stats,
        'open_positions': pos,
        'trade_history': hist,
        'wallet_ledger': ledger,
        'settings': {k: v for k, v in settings.items() if k not in ('gemini_api_key',)},
        'alerts': alerts,
        'summary': {
            'total_trades': stats.get('trades', 0),
            'winrate': stats.get('winrate', 0),
            'realized_pnl': w.get('realized_pnl', 0),
            'unrealized_pnl': sum(p.get('unrealized_pnl') or 0 for p in pos),
            'equity': w.get('equity', 0),
            'balance': w.get('balance', 0),
            'max_drawdown_pct': stats.get('max_drawdown_pct', 0),
            'open_count': len(pos),
        }
    }
    return report


def demo_export_csv_text():
    """Generate a very detailed CSV text for all trades + positions + ledger."""
    lines = []
    lines.append('=== APEX V11 PORTFOLIO EXPORT ===')
    lines.append('زمان خروجی: ' + time.strftime('%Y-%m-%d %H:%M:%S'))
    lines.append('')
    w = demo_get_wallet()
    stats = demo_full_stats()
    lines.append('--- کیف پول ---')
    lines.append('موجودی آزاد,%.6f' % w.get('balance', 0))
    lines.append('اکوئیتی,%.6f' % w.get('equity', 0))
    lines.append('سود تحقق‌یافته,%.6f' % w.get('realized_pnl', 0))
    lines.append('قله اکوئیتی,%.6f' % w.get('peak_equity', 0))
    lines.append('کل واریزی,%.6f' % w.get('total_deposited', 0))
    lines.append('کارمزد پرداختی,%.6f' % w.get('fees_paid', 0))
    lines.append('')
    lines.append('--- آمار ---')
    for k, v in (stats or {}).items():
        lines.append('%s,%s' % (k, v))
    lines.append('')
    lines.append('--- پوزیشن‌های باز ---')
    lines.append('id,symbol,side,entry,live_price,qty_open,leverage,margin_open,tp1,tp2,tp3,sl,unrealized_pnl,unrealized_pnl_pct,opened_ts,source')
    for p in demo_open_positions():
        px = p.get('live_price') or _quick_price(p.get('symbol') or '')
        upnl = p.get('unrealized_pnl')
        upct = p.get('unrealized_pnl_pct')
        if upnl is None and px and p.get('entry') and p.get('qty_open'):
            side = (p.get('side') or '').upper()
            entry = float(p['entry']); qty = float(p['qty_open'])
            upnl = (px - entry) * qty if side == 'LONG' else (entry - px) * qty
            margin = float(p.get('margin_open') or 1)
            upct = upnl / margin * 100 if margin else 0
        lines.append(','.join(str(x) for x in [
            p.get('id'), p.get('symbol'), p.get('side'), p.get('entry'), px,
            p.get('qty_open'), p.get('leverage'), p.get('margin_open'),
            p.get('tp1'), p.get('tp2'), p.get('tp3'), p.get('sl'),
            upnl, upct, p.get('opened_ts'), p.get('source')
        ]))
    lines.append('')
    lines.append('--- تاریخچه معاملات ---')
    lines.append('id,pos_id,symbol,side,entry,exit,qty,leverage,pnl,pnl_pct,fee,reason,ts')
    for h in demo_trade_history(500):
        lines.append(','.join(str(x) for x in [
            h.get('id'), h.get('pos_id'), h.get('symbol'), h.get('side'),
            h.get('entry'), h.get('exit'), h.get('qty'), h.get('leverage'),
            h.get('pnl'), h.get('pnl_pct'), h.get('fee'), h.get('reason'), h.get('ts')
        ]))
    lines.append('')
    lines.append('--- دفتر کل کیف پول ---')
    lines.append('id,type,amount,balance_after,note,ts')
    for r in demo_wallet_ledger(200):
        lines.append(','.join(str(x) for x in [
            r.get('id'), r.get('type'), r.get('amount'), r.get('balance_after'),
            (r.get('note') or '').replace(',', ';'), r.get('ts')
        ]))
    return '\n'.join(lines)


def demo_state_bundle():
    w = demo_get_wallet()
    pos = demo_open_positions()
    # attach live price + unrealized pnl to every open position
    price_cache = {}
    for p in pos:
        sym = p.get('symbol') or ''
        if sym not in price_cache:
            price_cache[sym] = _quick_price(sym)
        px = price_cache[sym]
        p['live_price'] = px
        if px and p.get('entry') and p.get('qty_open'):
            side = (p.get('side') or '').upper()
            entry = float(p['entry'])
            qty = float(p['qty_open'])
            if side == 'LONG':
                upnl = (px - entry) * qty
            else:
                upnl = (entry - px) * qty
            margin = float(p.get('margin_open') or p.get('margin') or 1)
            p['unrealized_pnl'] = round(upnl, 4)
            p['unrealized_pnl_pct'] = round(upnl / margin * 100, 2) if margin else 0
        else:
            p['unrealized_pnl'] = None
            p['unrealized_pnl_pct'] = None
    hist = demo_trade_history(120)
    stats = demo_full_stats()
    settings = demo_settings_get()
    orders = demo_pending_orders()
    alerts = demo_get_alerts(40)
    curve = demo_equity_curve(120)
    ok, reason = demo_check_risk_gates()
    ledger = demo_wallet_ledger(50)
    return {'wallet': w, 'positions': pos, 'history': hist, 'stats': stats,
            'settings': settings, 'orders': orders, 'alerts': alerts,
            'equity_curve': curve, 'trading_ok': ok, 'halt_reason': reason,
            'ledger': ledger, 'live_prices': price_cache}


def oi_insert(sym, oi, price):
    c = db_conn()
    now = int(time.time())
    c.execute('INSERT INTO oi VALUES (?,?,?,?)', (sym, now, oi, price))
    c.execute('DELETE FROM oi WHERE ts < ?', (now - 14 * 86400,))
    c.commit()
    c.close()


def oi_history(sym, hours):
    c = db_conn()
    rows = c.execute('SELECT ts,oi,price FROM oi WHERE symbol=? AND ts>=? ORDER BY ts',
                     (sym, int(time.time()) - hours * 3600)).fetchall()
    c.close()
    return [{'ts': r[0], 'oi': r[1], 'price': r[2]} for r in rows]


def cache_get(key, ttl):
    c = db_conn()
    r = c.execute('SELECT ts,payload FROM cache WHERE key=?', (key,)).fetchone()
    c.close()
    if r and time.time() - r[0] < ttl:
        return json.loads(r[1])
    return None


def cache_set(key, obj):
    c = db_conn()
    c.execute('INSERT OR REPLACE INTO cache VALUES (?,?,?)',
              (key, int(time.time()), json.dumps(obj, ensure_ascii=False)))
    c.commit()
    c.close()


# ---------------- News ----------------
def _strip(s):
    return re.sub(r'<[^>]+>', '', s or '').strip()


def parse_feed(raw, source):
    root = ET.fromstring(raw)
    items = []
    for node in root.iter():
        if node.tag.split('}')[-1] not in ('item', 'entry'):
            continue
        f = {}
        for ch in node:
            name = ch.tag.split('}')[-1]
            if name == 'link' and ch.get('href'):
                f['link'] = ch.get('href')
            elif name not in f:
                f[name] = (ch.text or '').strip()
        date = f.get('pubDate') or f.get('published') or f.get('updated') or ''
        try:
            ts = parsedate_to_datetime(date).timestamp()
        except Exception:
            try:
                ts = time.mktime(time.strptime(date[:19], '%Y-%m-%dT%H:%M:%S'))
            except Exception:
                ts = 0
        items.append({'title': _strip(f.get('title')), 'link': f.get('link', ''),
                      'summary': _strip(f.get('description') or f.get('summary'))[:300],
                      'date': date, 'ts': ts, 'source': source})
    return items[:40]


def get_news(q):
    jobs = list(RSS_FEEDS.items())
    if q:
        jobs.append(('Google News', GOOGLE_NEWS % urllib.parse.quote(q + ' crypto when:2d')))

    def run(job):
        name, url = job
        try:
            return parse_feed(http_get(url, ALLOWED_ALL, 20), name), None
        except Exception as e:
            return [], '%s: %s' % (name, e)

    items, errs = [], []
    with ThreadPoolExecutor(6) as ex:
        for its, err in ex.map(run, jobs):
            items += its
            if err:
                errs.append(err)
    items.sort(key=lambda x: x['ts'], reverse=True)
    return {'items': items[:250], 'errors': errs}


# ---------------- Events ----------------
def get_events(ticker):
    cached = cache_get('ev_' + ticker, 900)
    if cached:
        return cached
    ev, errs = [], []
    try:
        raw = http_get('https://nfs.faireconomy.media/ff_calendar_thisweek.json', JSON_HOSTS, 15)
        for e in json.loads(raw.decode('utf-8')):
            ev.append({'kind': 'macro', 'title': e.get('title', ''), 'date': e.get('date', ''),
                       'country': e.get('country', ''), 'impact': e.get('impact', ''),
                       'forecast': e.get('forecast', ''), 'previous': e.get('previous', '')})
    except Exception as e:
        errs.append('thisweek: %s' % e)
    try:
        s = json.loads(http_get('https://api.coinpaprika.com/v1/search?q=%s&c=currencies&limit=5'
                                % urllib.parse.quote(ticker), JSON_HOSTS).decode('utf-8'))
        coins = s.get('currencies', []) if isinstance(s, dict) else []
        coin = next((x for x in coins if str(x.get('symbol', '')).upper() == ticker), None)
        if coin:
            ce = json.loads(http_get('https://api.coinpaprika.com/v1/coins/%s/events'
                                     % urllib.parse.quote(coin['id']), JSON_HOSTS).decode('utf-8'))
            for x in ce or []:
                ev.append({'kind': 'crypto', 'title': x.get('name', ''),
                           'date': x.get('date_start') or x.get('date', ''),
                           'country': ticker, 'impact': '', 'forecast': '', 'previous': ''})
    except Exception as e:
        errs.append('crypto: %s' % e)
    res = {'events': ev, 'errors': errs}
    cache_set('ev_' + ticker, res)
    return res


# ---------------- Files ----------------
def find_download_dir():
    for d in ['/storage/emulated/0/Download', '/sdcard/Download',
              os.path.expanduser('~/Downloads'), os.path.join(os.getcwd(), 'downloads')]:
        try:
            os.makedirs(d, exist_ok=True)
            if os.access(d, os.W_OK):
                return d
        except Exception:
            pass
    return os.getcwd()


def safe_filename(name):
    name = re.sub(r'[^A-Za-z0-9._-]', '', name or '') or 'export.txt'
    if '..' in name or name.startswith('.'):
        name = 'export' + name.replace('..', '.')
    return name[:200]


# ---------------- HTTP ----------------

# ==================== AUTO-TRADE ENGINE ====================
_auto_trade_lock = threading.Lock()
_auto_trade_thread = None
_auto_trade_stop = threading.Event()

def auto_trade_status():
    return {
        'running': bool(_auto_trade_thread and _auto_trade_thread.is_alive()),
        'settings_flag': demo_settings_get().get('auto_trade_running', '0'),
    }

def auto_trade_stop():
    _auto_trade_stop.set()
    demo_settings_set({'auto_trade_running': '0'})
    demo_add_alert('AUTO', 'معامله خودکار متوقف شد')
    return {'ok': True, 'message': 'در حال توقف...'}

def _auto_trade_worker(symbols, max_pos=20):
    """Background worker: analyze symbols and open positions from AI signals."""
    demo_settings_set({'auto_trade_running': '1'})
    demo_add_alert('AUTO', 'شروع معامله خودکار روی %d نماد' % len(symbols))
    opened = 0
    try:
        for sym in symbols:
            if _auto_trade_stop.is_set():
                break
            if len(demo_open_positions()) >= max_pos:
                demo_add_alert('AUTO', 'سقف پوزیشن باز رسید (%d)' % max_pos)
                break
            try:
                # Minimal market snapshot for AI
                price = _quick_price(sym)
                if not price:
                    demo_add_alert('AUTO', 'قیمت %s در دسترس نیست — رد شد' % sym)
                    continue
                # Build a lightweight payload for signal generation
                user_msg = (
                    "Analyze %s/USDT for a short-term trade signal. "
                    "Current price approx %.6f. "
                    "Reply in the exact APEX signal format with Side, Entry, TP1, TP2, TP3, SL, Leverage, Size%%, Conviction."
                ) % (sym, price)
                try:
                    text = gemini_generate(user_msg)
                    sig = parse_apex_signal(text) if 'parse_apex_signal' in dir() else None
                    if not sig:
                        # fallback simple parser
                        sig = {'side': None, 'entry': price, 'tp1': None, 'tp2': None, 'tp3': None,
                               'sl': None, 'leverage': 5, 'size_pct': 3, 'conviction': 5}
                        import re as _re
                        m = _re.search(r'(LONG|SHORT)', text or '', _re.I)
                        if m: sig['side'] = m.group(1).upper()
                        for key, pats in [('entry', [r'Entry[:\s]+([0-9.]+)']),
                                          ('tp1', [r'TP1[:\s]+([0-9.]+)', r'هدف\s*۱[:\s]+([0-9.]+)']),
                                          ('sl', [r'SL[:\s]+([0-9.]+)', r'حد\s*ضرر[:\s]+([0-9.]+)'])]:
                            for pat in pats:
                                mm = _re.search(pat, text or '', _re.I)
                                if mm:
                                    try: sig[key] = float(mm.group(1))
                                    except: pass
                                    break
                    if not sig or not sig.get('side'):
                        demo_add_alert('AUTO', '%s: سیگنال نامعتبر' % sym)
                        continue
                    side = sig['side'].upper()
                    entry = float(sig.get('entry') or price)
                    lev = float(sig.get('leverage') or 5)
                    size_pct = float(sig.get('size_pct') or 3)
                    tp1 = sig.get('tp1'); tp2 = sig.get('tp2'); tp3 = sig.get('tp3'); sl = sig.get('sl')
                    conviction = int(sig.get('conviction') or 5)
                    w = demo_get_wallet()
                    margin = max(1.0, min(w['balance'] * size_pct / 100.0, w['balance'] * 0.15))
                    if margin < 1:
                        demo_add_alert('AUTO', '%s: موجودی کم' % sym)
                        continue
                    res = demo_open_position(
                        sym + 'USDT' if not str(sym).endswith('USDT') else sym,
                        side, entry, lev, margin, tp1, tp2, tp3, sl,
                        conviction=conviction, horizon='auto', notes='Auto-Trade',
                        source='auto_trade'
                    )
                    opened += 1
                    demo_add_alert('AUTO', 'باز شد: %s %s @ %.4f (مارجین %.2f)' % (side, sym, entry, margin))
                    time.sleep(2.5)  # rate limit between analyses
                except Exception as e:
                    demo_add_alert('AUTO', '%s خطا: %s' % (sym, str(e)[:80]))
                    time.sleep(1)
            except Exception as e:
                demo_add_alert('AUTO', 'خطای کلی %s: %s' % (sym, str(e)[:60]))
    finally:
        demo_settings_set({'auto_trade_running': '0'})
        demo_add_alert('AUTO', 'معامله خودکار تمام شد. باز شده: %d' % opened)
        _auto_trade_stop.clear()

def auto_trade_start(symbols=None, max_pos=20):
    global _auto_trade_thread
    with _auto_trade_lock:
        if _auto_trade_thread and _auto_trade_thread.is_alive():
            return {'ok': False, 'error': 'معامله خودکار در حال اجرا است'}
        settings = demo_settings_get()
        if not symbols:
            raw = settings.get('auto_trade_symbols') or 'BTC,ETH,SOL,XRP,DOGE,ADA,LINK,AVAX,DOT,MATIC,LTC,BCH,ATOM,NEAR,APT,SUI,ARB,OP,INJ,TIA'
            symbols = [s.strip().upper() for s in raw.split(',') if s.strip()][:20]
        _auto_trade_stop.clear()
        t = threading.Thread(target=_auto_trade_worker, args=(symbols, max_pos), name='APEX-AutoTrade', daemon=True)
        _auto_trade_thread = t
        t.start()
        return {'ok': True, 'message': 'شروع روی %d نماد' % len(symbols), 'symbols': symbols}


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, fmt, *args):
        pass

    def _send(self, status, ctype, body):
        try:
            self.send_response(status)
            self.send_header('Content-Type', ctype)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, status, obj):
        self._send(status, 'application/json; charset=utf-8',
                   json.dumps(obj, ensure_ascii=False).encode('utf-8'))

    def do_GET(self):
        try:
            self._get()
        except Exception as e:
            self._json(500, {'error': str(e) or type(e).__name__, '__proxy_error': True})

    def do_POST(self):
        try:
            self._post()
        except Exception as e:
            self._json(500, {'ok': False, 'error': str(e) or type(e).__name__})

    def _get(self):
        p = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(p.query)

        def g(k, d=''):
            return (q.get(k, [d])[0] or d)

        if p.path in ('/', '/index.html'):
            return self._send(200, 'text/html; charset=utf-8', HTML.encode('utf-8'))
        if p.path == '/proxy':
            try:
                return self._json(200, json.loads(http_get(g('url'), JSON_HOSTS, 25).decode('utf-8')))
            except urllib.error.HTTPError as e:
                return self._json(502, {'error': 'HTTP %s' % e.code, '__proxy_error': True})
            except Exception as e:
                return self._json(502, {'error': str(e) or type(e).__name__, '__proxy_error': True})
        if p.path == '/news':
            return self._json(200, get_news(g('q').upper()[:15]))
        if p.path == '/events':
            return self._json(200, get_events(g('symbol', 'BTC').upper()[:10]))
        if p.path == '/oi_history':
            try:
                hours = max(1, min(int(g('hours', '72')), 24 * 14))
            except ValueError:
                hours = 72
            return self._json(200, {'history': oi_history(g('symbol')[:40].upper(), hours)})
        if p.path == '/demo/state':
            return self._json(200, demo_state_bundle())
        return self._json(404, {'error': 'not found'})

    def _post(self):
        p = urllib.parse.urlparse(self.path)
        try:
            n = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            n = -1
        if n < 0 or n > MAX_POST:
            return self._json(413, {'ok': False, 'error': 'payload too large'})
        try:
            body = json.loads(self.rfile.read(n).decode('utf-8') or '{}')
        except Exception:
            return self._json(400, {'ok': False, 'error': 'bad json'})

        if p.path == '/oi_snapshot':
            try:
                sym = str(body.get('symbol', ''))[:40]
                oi = float(body.get('oi', 0))
                price = float(body.get('price') or 0)
                if not sym or oi <= 0:
                    return self._json(400, {'ok': False})
                oi_insert(sym, oi, price)
                return self._json(200, {'ok': True})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        if p.path == '/gzip':
            content = body.get('content', '')
            if not isinstance(content, str):
                return self._json(400, {'ok': False, 'error': 'content must be string'})
            return self._send(200, 'application/gzip', gzip.compress(content.encode('utf-8'), 9))

        if p.path == '/save':
            content = body.get('content', '')
            fn = safe_filename(body.get('filename', 'export.txt'))
            if not isinstance(content, str):
                return self._json(400, {'ok': False, 'error': 'content must be string'})
            if body.get('gzip'):
                if not fn.endswith('.gz'):
                    fn += '.gz'
                data = gzip.compress(content.encode('utf-8'), 9)
            else:
                data = content.encode('utf-8-sig' if fn.endswith('.csv') else 'utf-8')
            d = find_download_dir()
            path = os.path.join(d, fn)
            if os.path.exists(path):
                base, ext = os.path.splitext(fn)
                path = os.path.join(d, '%s_%d%s' % (base, int(time.time()), ext))
            with open(path, 'wb') as f:
                f.write(data)
            return self._json(200, {'ok': True, 'path': path, 'size': os.path.getsize(path)})

        # ---------- APEX AI ----------
        if p.path == '/ai_signal':
            try:
                msg = build_apex_user_message(body)
                text = gemini_generate(msg)
                sig = parse_signal_block(text)
                # log
                try:
                    c = db_conn()
                    c.execute('INSERT INTO demo_ai_log(symbol,tf,prompt_hash,response,signal_json,ts) VALUES(?,?,?,?,?,?)',
                              (str(body.get('symbol', ''))[:20], str(body.get('mainTF', ''))[:12],
                               str(hash(msg))[:16], text[:50000], json.dumps(sig, ensure_ascii=False), int(time.time())))
                    c.commit()
                    c.close()
                except Exception:
                    pass
                return self._json(200, {'ok': True, 'text': text, 'signal': sig})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e) or type(e).__name__})

        # ---------- Demo Trading ----------

        if p.path == '/demo/open':
            try:
                symbol = str(body.get('symbol', ''))[:20]
                side = str(body.get('side', '')).upper()
                entry = float(body.get('entry') or 0)
                leverage = float(body.get('leverage') or 5)
                size_pct = float(body.get('size_pct') or 5)
                risk_pct = body.get('risk_pct')
                tp1 = body.get('tp1'); tp1 = float(tp1) if tp1 not in (None, '') else None
                tp2 = body.get('tp2'); tp2 = float(tp2) if tp2 not in (None, '') else None
                tp3 = body.get('tp3'); tp3 = float(tp3) if tp3 not in (None, '') else None
                sl = body.get('sl'); sl = float(sl) if sl not in (None, '') else None
                conviction = int(body.get('conviction') or 5)
                horizon = str(body.get('horizon') or '')[:80]
                notes = str(body.get('notes') or '')[:500]
                source = str(body.get('source') or 'manual')[:20]
                trail_dist = float(body.get('trail_dist') or 0)
                if side not in ('LONG', 'SHORT') or entry <= 0 or not symbol:
                    return self._json(400, {'ok': False, 'error': 'side/entry/symbol نامعتبر'})
                settings = demo_settings_get()
                max_margin_pct = float(settings.get('max_margin_pct', 80))
                w = demo_get_wallet()
                margin_usd = body.get('margin_usd')
                if margin_usd is not None and str(margin_usd) != '':
                    # Fixed USD margin amount
                    margin = float(margin_usd)
                    if margin <= 0:
                        return self._json(400, {'ok': False, 'error': 'مبلغ مارجین نامعتبر'})
                elif risk_pct is not None and sl:
                    # risk-based sizing: margin such that SL loss ≈ risk_pct of equity
                    risk_pct = float(risk_pct)
                    risk_amt = w['equity'] * (risk_pct / 100.0)
                    dist = abs(entry - float(sl)) / entry
                    if dist < 1e-8:
                        return self._json(400, {'ok': False, 'error': 'فاصله حد ضرر صفر است'})
                    leverage = max(1.0, min(leverage, float(settings.get('max_leverage', 20))))
                    margin = risk_amt / (dist * leverage)
                else:
                    size_pct = max(0.5, min(size_pct, max_margin_pct))
                    margin = w['balance'] * (size_pct / 100.0)
                margin = max(0.5, min(margin, w['balance'] * max_margin_pct / 100.0))
                res = demo_open_position(symbol, side, entry, leverage, margin, tp1, tp2, tp3, sl,
                                         conviction, horizon, notes, source, trail_dist)
                return self._json(200, {'ok': True, **res})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        if p.path == '/demo/update':
            try:
                prices = body.get('prices') or {}
                pmap = {}
                for k, v in prices.items():
                    try:
                        pmap[str(k)] = float(v)
                    except Exception:
                        pass
                events = demo_update_positions(pmap)
                return self._json(200, {'ok': True, 'events': events, **demo_state_bundle()})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        if p.path == '/demo/close':
            try:
                pid = int(body.get('id'))
                price = float(body.get('price'))
                qty_pct = float(body.get('qty_pct') or 100)
                res = demo_close_manual(pid, price, qty_pct)
                return self._json(200, {'ok': True, **res, **demo_state_bundle()})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        if p.path == '/demo/close_all':
            try:
                prices = body.get('prices') or {}
                pmap = {str(k): float(v) for k, v in prices.items()}
                events = demo_close_all(pmap)
                return self._json(200, {'ok': True, 'events': events, **demo_state_bundle()})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        if p.path == '/demo/modify':
            try:
                pid = int(body.get('id'))
                kw = {}
                for k in ('sl', 'tp1', 'tp2', 'tp3', 'trail_dist'):
                    if body.get(k) not in (None, ''):
                        kw[k] = float(body[k])
                demo_modify_position(pid, **kw)
                return self._json(200, {'ok': True, **demo_state_bundle()})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        if p.path == '/demo/withdraw':
            try:
                amt = float(body.get('amount') or 0)
                note = str(body.get('note') or '')[:200]
                w = demo_withdraw(amt, note)
                return self._json(200, {'ok': True, 'wallet': w, **demo_state_bundle()})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        if p.path == '/demo/ledger':
            try:
                return self._json(200, {'ok': True, 'ledger': demo_wallet_ledger(100)})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        if p.path == '/demo/deposit':
            try:
                amt = float(body.get('amount') or 100)
                note = str(body.get('note') or '')[:200]
                w = demo_deposit(amt, note)
                return self._json(200, {'ok': True, 'wallet': w, **demo_state_bundle()})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})


        if p.path == '/demo/export':
            try:
                fmt = str(body.get('format') or 'json')
                if fmt == 'csv':
                    text = demo_export_csv_text()
                    return self._json(200, {'ok': True, 'format': 'csv', 'content': text})
                else:
                    report = demo_export_full_portfolio()
                    return self._json(200, {'ok': True, 'format': 'json', 'report': report})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        if p.path == '/demo/auto_trade/start':
            try:
                symbols = body.get('symbols')
                max_pos = int(body.get('max_pos') or 20)
                res = auto_trade_start(symbols, max_pos)
                return self._json(200, {**res, **demo_state_bundle()})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        if p.path == '/demo/auto_trade/stop':
            try:
                res = auto_trade_stop()
                return self._json(200, {**res, **demo_state_bundle()})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        if p.path == '/demo/auto_trade/status':
            try:
                return self._json(200, {'ok': True, **auto_trade_status(), **demo_state_bundle()})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        if p.path == '/demo/set_api_key':
            try:
                key = str(body.get('key') or body.get('api_key') or '').strip()
                if not key or len(key) < 10:
                    return self._json(400, {'ok': False, 'error': 'کلید نامعتبر'})
                demo_settings_set({'gemini_api_key': key})
                # Also update runtime global
                global GEMINI_API_KEY
                GEMINI_API_KEY = key
                demo_add_alert('SETTINGS', 'کلید API هوش مصنوعی به‌روزرسانی شد')
                return self._json(200, {'ok': True, 'message': 'کلید ذخیره شد'})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})


        if p.path == '/demo/settings':
            try:
                if body:
                    demo_settings_set(body)
                return self._json(200, {'ok': True, 'settings': demo_settings_get()})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        if p.path == '/demo/reset':
            try:
                demo_reset_wallet()
                return self._json(200, {'ok': True, **demo_state_bundle()})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        if p.path == '/demo/reverse':
            try:
                pid = int(body.get('id'))
                price = float(body.get('price'))
                res = demo_reverse_position(pid, price)
                return self._json(200, {'ok': True, **res, **demo_state_bundle()})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        if p.path == '/demo/scale_in':
            try:
                pid = int(body.get('id'))
                price = float(body.get('price'))
                margin_add = float(body.get('margin') or body.get('margin_add') or 5)
                res = demo_scale_in(pid, price, margin_add)
                return self._json(200, {'ok': True, **res, **demo_state_bundle()})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        if p.path == '/demo/resume':
            try:
                demo_settings_set({'trading_halted': '0', 'halt_reason': ''})
                demo_add_alert('RESUME', 'معاملات از سر گرفته شد')
                return self._json(200, {'ok': True, **demo_state_bundle()})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        if p.path == '/demo/alerts_read':
            try:
                demo_mark_alerts_read()
                return self._json(200, {'ok': True, 'alerts': demo_get_alerts()})
            except Exception as e:
                return self._json(500, {'ok': False, 'error': str(e)})

        return self._json(404, {'ok': False})


HTML = r'''<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>APEX Terminal v11</title>
<meta name="theme-color" content="#0a0a0c">
<style>
:root{
  --bg:#0a0a0c; --bg2:#121216; --panel:#16161a; --panel2:#1c1c22;
  --line:#2a2a32; --line2:#3a3a45;
  --txt:#f2f2f5; --muted:#9a9aab;
  --green:#22c55e; --green2:#4ade80; --red:#f43f5e; --red2:#fb7185;
  --blue:#60a5fa; --purple:#a78bfa; --yellow:#fbbf24; --cyan:#22d3ee;
  --radius:14px; --nav-h:64px; --shadow:0 8px 32px rgba(0,0,0,.45);
}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0;background:var(--bg);color:var(--txt);font:13.5px/1.55 "Tahoma","Segoe UI",system-ui,sans-serif;min-height:100%}
body{padding-bottom:calc(var(--nav-h) + 12px)}
main{max-width:1100px;margin:0 auto;padding:12px 12px 24px}
.topbar{position:sticky;top:0;z-index:50;background:rgba(10,10,12,.92);backdrop-filter:blur(14px);border-bottom:1px solid var(--line);padding:10px 14px;display:flex;align-items:center;gap:8px;flex-wrap:wrap;box-shadow:var(--shadow)}
.topbar .logo{font-weight:900;font-size:16px;color:var(--blue);letter-spacing:.2px}
.topbar .pill{background:var(--panel2);border:1px solid var(--line);border-radius:999px;padding:4px 11px;font-size:11px;color:var(--muted);font-weight:600}
.topbar .price-live{font-weight:900;font-size:17px;direction:ltr;color:var(--txt)}
h1{font-size:18px;margin:0 0 6px}h2{font-size:15px;margin:0 0 10px;font-weight:800;color:var(--txt)}
h3{font-size:12px;margin:14px 0 8px;color:var(--blue);font-weight:800;letter-spacing:.3px}
.muted{color:var(--muted);line-height:1.7;font-size:12px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);padding:14px;margin-top:12px;box-shadow:var(--shadow)}
.card.accent-g{border-color:#a7f3d0;background:linear-gradient(180deg,#0f1f18,#121216)}
.card.accent-p{border-color:#ddd6fe;background:linear-gradient(180deg,#1a1530,#121216)}
.card.accent-b{border-color:#bfdbfe;background:linear-gradient(180deg,#0f172a,#121216)}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:8px}
.controls{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}
label{display:block;color:var(--muted);font-size:11px;margin-bottom:4px;font-weight:600}
input,select,button,textarea{width:100%;padding:10px 11px;border:1px solid var(--line2);border-radius:10px;background:var(--panel);color:var(--txt);font:inherit;font-size:12.5px;outline:none}
input:focus,select:focus{border-color:var(--blue);box-shadow:0 0 0 3px rgba(37,99,235,.12)}
button{background:linear-gradient(180deg,#3b82f6,#2563eb);color:#fff;font-weight:800;border:0;cursor:pointer;transition:.15s}
button:active{transform:scale(.98)}
button:disabled{opacity:.45;cursor:not-allowed}
button.sec{background:var(--panel);color:var(--txt);border:1px solid var(--line2)}
button.blue{background:linear-gradient(180deg,#60a5fa,#2563eb);color:#fff}
button.pur{background:linear-gradient(180deg,#a78bfa,#7c3aed);color:#fff}
button.red{background:linear-gradient(180deg,#fb7185,#e11d48);color:#fff}
button.long{background:linear-gradient(180deg,#34d399,#059669);color:#fff}
button.short{background:linear-gradient(180deg,#fb7185,#e11d48);color:#fff}
.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.row>*{flex:1 1 120px}
.chk{display:flex;gap:10px;flex-wrap:wrap}
.chk label{display:flex;align-items:center;gap:5px;margin:0;color:var(--txt);font-size:11px;cursor:pointer;font-weight:500}
.chk input{width:auto}
.metric{background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:10px}
.k{font-size:10px;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.4px}
.v{font-size:14px;font-weight:900;margin-top:4px;direction:ltr;text-align:right}
.good{color:var(--green)}.bad{color:var(--red)}.warn{color:var(--yellow)}
.scroll{overflow:auto;max-height:400px}
table{border-collapse:collapse;width:100%;font-size:11.5px}
td,th{padding:8px 6px;border-bottom:1px solid var(--line);text-align:right;white-space:nowrap}
th{color:var(--muted);position:sticky;top:0;background:var(--panel);font-weight:700}
.bar{height:7px;background:var(--line);border-radius:10px;overflow:hidden;margin-top:8px}
.bar>div{height:100%;background:linear-gradient(90deg,var(--blue),var(--green2));width:0;transition:width .3s}
.status{white-space:pre-wrap;line-height:1.7;font-size:12px;max-height:220px;overflow:auto;background:var(--panel2);border-radius:10px;padding:10px;border:1px solid var(--line)}
.note{border:1px solid #5a4a20;background:#2a2210;color:#fbbf24;border-radius:12px;padding:11px;line-height:1.75;font-size:12.5px}
.vpn-note{border:1px solid #1e3a5f;background:#0c1a2e;color:#93c5fd;border-radius:12px;padding:11px;line-height:1.75;font-size:12.5px;margin-top:10px;font-weight:600}
.box{background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:11px;margin-top:8px;line-height:1.7;font-size:12.5px}
.badge{display:inline-block;padding:3px 10px;border-radius:999px;font-size:11px;font-weight:800}
.b-sb{background:#14532d;color:#bbf7d0}.b-b{background:#166534;color:#bbf7d0}.b-n{background:#27272a;color:#a1a1aa}
.b-s{background:#4c0519;color:#fecdd3}.b-ss{background:#881337;color:#fecdd3}
.confbar{height:22px;background:var(--panel2);border:1px solid var(--line);border-radius:11px;position:relative;overflow:hidden;margin:8px 0}
.conffill{position:absolute;top:0;bottom:0;left:0;background:linear-gradient(90deg,var(--red),var(--yellow),var(--green));transition:width .5s}
.midline{position:absolute;left:50%;top:0;bottom:0;width:1px;background:#94a3b8;opacity:.6}
.sig{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:8px}
.sig .l{font-size:11px;color:var(--muted)}.sig .v{font-size:13px}
canvas{width:100%;height:340px;background:var(--panel);border-radius:12px;display:block;border:1px solid var(--line)}
.banner{position:fixed;top:0;left:0;right:0;padding:12px;text-align:center;font-weight:800;z-index:200;transform:translateY(-120%);transition:transform .3s;background:var(--green);color:#fff}
.banner.show{transform:none}
.banner.err{background:var(--red)}
.ai-pre{white-space:pre-wrap;direction:rtl;text-align:right;line-height:1.95;font-size:13.5px;background:var(--panel);border:1px solid var(--line2);border-radius:14px;padding:16px;min-height:140px;box-shadow:inset 0 1px 0 #fff}
.sig-block{background:#0f172a;color:#e2e8f0;border-radius:14px;padding:14px;margin-top:10px;font-family:ui-monospace,Consolas,monospace;direction:ltr;text-align:left;white-space:pre-wrap;font-size:12.5px}
.demo-pos{border:1px solid var(--line);border-radius:14px;padding:12px;margin:8px 0;background:var(--panel);box-shadow:var(--shadow)}
.demo-pos.long{border-color:#6ee7b7;box-shadow:inset 4px 0 0 var(--green)}
.demo-pos.short{border-color:#fda4af;box-shadow:inset 4px 0 0 var(--red)}
.pnl-pos{color:var(--green)}.pnl-neg{color:var(--red)}
.tab-panel{display:none}
.tab-panel.active{display:block;animation:fade .18s ease}
@keyframes fade{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
.bottom-nav{position:fixed;bottom:0;left:0;right:0;height:var(--nav-h);background:rgba(12,12,16,.96);backdrop-filter:blur(16px);border-top:1px solid var(--line);display:flex;z-index:100;padding-bottom:env(safe-area-inset-bottom);box-shadow:0 -4px 20px rgba(15,23,42,.05)}
.bottom-nav button{flex:1;background:transparent;color:var(--muted);border:0;border-radius:0;font-size:10.5px;font-weight:700;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;padding:8px 2px}
.bottom-nav button .ico{font-size:20px;line-height:1}
.bottom-nav button.active{color:var(--blue)}
.x-ticker{display:flex;gap:10px;align-items:center;flex-wrap:wrap;padding:12px;background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);margin-top:8px;box-shadow:var(--shadow)}
.x-ticker .sym{font-size:16px;font-weight:900}
.x-ticker .px{font-size:24px;font-weight:900;direction:ltr}
.x-layout{display:grid;grid-template-columns:1fr;gap:12px;margin-top:12px}
@media(min-width:900px){.x-layout{grid-template-columns:340px 1fr}}
.x-form{background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);padding:14px;box-shadow:var(--shadow)}
.x-form .side-toggle{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px}
.x-form .side-toggle button{padding:14px;font-size:14px}
.x-form .side-toggle button.on-long{background:var(--green);color:#fff;box-shadow:0 6px 18px rgba(5,150,105,.25)}
.x-form .side-toggle button.on-short{background:var(--red);color:#fff;box-shadow:0 6px 18px rgba(225,29,72,.25)}
.x-account{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:10px 0}
.x-account .cell{background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:10px;text-align:center}
.x-account .cell .l{font-size:9px;color:var(--muted);font-weight:700}.x-account .cell .n{font-size:14px;font-weight:900;direction:ltr;margin-top:2px}
.ai-hero{border:1px solid #4c3a7a;background:linear-gradient(160deg,#1a1530,#121216);border-radius:16px;padding:16px;margin-top:12px}
.chip{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:999px;background:var(--panel2);border:1px solid var(--line);font-size:11px;font-weight:600}
.halt-banner{background:#2a1215;border:1px solid #7f1d1d;color:#fecaca;padding:10px 12px;border-radius:12px;font-weight:700;margin:8px 0;display:none}
.halt-banner.show{display:block}
.eq-bars{display:flex;align-items:flex-end;gap:2px;height:64px;margin-top:8px;padding:6px;background:var(--panel2);border-radius:10px;border:1px solid var(--line)}
.eq-bars i{flex:1;background:linear-gradient(180deg,var(--blue),#93c5fd);border-radius:3px 3px 0 0;min-width:2px;opacity:.85}
.alert-item{padding:8px 10px;border-bottom:1px solid var(--line);font-size:12px}
.alert-item .t{color:var(--muted);font-size:10px}
.about-card{background:linear-gradient(145deg,#0f172a,#121216);border:1px solid #1e3a5f}
.about-card p{line-height:1.9;font-size:13.5px;margin:8px 0}

.app-icon-btn{width:40px;height:40px;border-radius:12px;border:1px solid var(--line);background:var(--panel);display:flex;align-items:center;justify-content:center;font-size:18px;cursor:pointer;flex:0 0 auto;padding:0;color:var(--txt);box-shadow:var(--shadow)}
.app-icon-btn:active{transform:scale(.95)}
.drawer-bg{position:fixed;inset:0;background:rgba(15,23,42,.35);z-index:150;display:none}
.drawer-bg.show{display:block}
.drawer{position:fixed;top:0;right:0;width:min(320px,88vw);height:100%;background:var(--panel);z-index:160;box-shadow:-8px 0 32px rgba(15,23,42,.12);transform:translateX(105%);transition:transform .25s ease;padding:18px 14px;overflow:auto}
.drawer.show{transform:none}
.drawer h3{margin:0 0 12px;font-size:15px}
.drawer a,.drawer button.nav-item{display:flex;width:100%;text-align:right;padding:12px 12px;border:0;background:var(--panel2);border-radius:12px;margin-bottom:8px;font-weight:700;color:var(--txt);align-items:center;gap:10px;cursor:pointer}
.drawer .nav-item .ico{font-size:18px}
.sheet-bg{position:fixed;inset:0;background:rgba(15,23,42,.4);z-index:170;display:none}
.sheet-bg.show{display:block}
.sheet{position:fixed;left:0;right:0;bottom:0;max-height:88vh;background:var(--panel);z-index:180;border-radius:20px 20px 0 0;padding:16px;overflow:auto;box-shadow:0 -8px 40px rgba(15,23,42,.15);transform:translateY(105%);transition:transform .25s ease}
.sheet.show{transform:none}
.sheet .grab{width:42px;height:5px;background:var(--line2);border-radius:4px;margin:0 auto 12px}
.seg{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin:8px 0}
.seg button{padding:10px;font-size:11px;background:var(--panel2);color:var(--txt);border:1px solid var(--line)}
.seg button.on{background:var(--blue);color:#fff;border-color:var(--blue)}
.status-ok{color:var(--green);font-weight:800}.status-bad{color:var(--red);font-weight:800}
.pos-actions{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-top:8px}
.pos-actions button{font-size:11px;padding:8px}

.coin-strip{display:flex;gap:8px;overflow-x:auto;padding:8px 0;margin:8px 0;-webkit-overflow-scrolling:touch}
.coin-chip{flex:0 0 auto;padding:10px 14px;border-radius:12px;border:1px solid var(--line);background:var(--panel2);color:var(--txt);font-weight:800;font-size:12px;cursor:pointer}
.coin-chip.active{border-color:var(--cyan);background:linear-gradient(180deg,#0e3a4a,#121216);color:var(--cyan);box-shadow:0 0 16px rgba(34,211,238,.2)}
.coin-chip .p{display:block;font-size:10px;color:var(--muted);font-weight:600;margin-top:2px;direction:ltr}
.sym-search{display:flex;gap:8px;margin:8px 0}
.sym-search input{flex:1}
</style></head><body>



<div class="banner" id="banner"></div>
<div class="topbar">
  <button type="button" class="app-icon-btn" id="btnMenu" title="منو">☰</button>
  <div class="logo">APEX</div>
  <span class="pill" id="topVer">v12.1</span>
  <span class="pill" id="topSym">BTC-USDT</span>
  <span class="price-live" id="topPrice">—</span>
  <span class="pill" id="topChg">—</span>
  <span class="pill" id="topEq">Equity $100</span>
  <span style="flex:1"></span>
  <button type="button" class="app-icon-btn" id="btnGear" title="تنظیمات">⚙</button>
</div>
<div class="drawer-bg" id="drawerBg"></div>
<aside class="drawer" id="drawer">
  <h3>منوی اپ</h3>
  <button type="button" class="nav-item" data-go="home"><span class="ico">🏠</span>خانه · تحلیل و AI</button>
  <button type="button" class="nav-item" data-go="trade"><span class="ico">📈</span>ترمینال دمو ترید</button>
  <button type="button" class="nav-item" data-go="market"><span class="ico">📊</span>بازار و اندیکاتورها</button>
  <button type="button" class="nav-item" data-go="ai"><span class="ico">🧠</span>هوش مصنوعی APEX</button>
  <button type="button" class="nav-item" data-go="more"><span class="ico">☰</span>بیشتر · تنظیمات و درباره</button>
  <button type="button" class="nav-item" id="drawerRunAi"><span class="ico">⚡</span>اجرای سریع APEX</button>
  <button type="button" class="nav-item" id="drawerTrade"><span class="ico">🎯</span>باز کردن از آخرین سیگنال</button>
  <p class="muted" style="margin-top:16px;font-size:11px">APEX Terminal · مناسب تبدیل به APK · داده زنده + AI + دمو ترید</p>
</aside>
<div class="sheet-bg" id="sheetBg"></div>
<div class="sheet" id="settingsSheet">
  <div class="grab"></div>
  <h2 style="margin-top:0">⚙ تنظیمات سریع</h2>
  <p class="muted">تنظیمات کامل‌تر در تب «بیشتر» هم هست. اینجا دسترسی سریع موبایلی است.</p>
  <div class="controls" style="margin-top:10px">
    <div><label>Auto-Trade بعد از AI</label><select id="qs_auto_trade"><option value="1">روشن</option><option value="0">خاموش</option></select></div>
    <div><label>حداقل Conviction</label><input id="qs_min_conviction" type="number" value="6" min="1" max="10"></div>
    <div><label>اهرم پیش‌فرض</label><input id="qs_default_leverage" type="number" value="5" min="1" max="50"></div>
    <div><label>حداکثر ریسک %</label><input id="qs_max_risk_pct" type="number" value="5" step="0.5"></div>
    <div><label>حد ضرر روزانه %</label><input id="qs_daily_loss_limit_pct" type="number" value="10"></div>
    <div><label>تیک قیمت (ms)</label><input id="qs_tick_ms" type="number" value="1000" step="100"></div>
    <div><label>حالت سایز</label><select id="qs_size_mode"><option value="signal">سیگنال AI</option><option value="risk">ریسک %</option><option value="fixed">مارجین ثابت %</option></select></div>
    <div><label>الزام SL</label><select id="qs_ai_require_sl"><option value="1">بله</option><option value="0">خیر</option></select></div>
  </div>
  <div class="row" style="margin-top:12px">
    <button id="qsSave" class="blue">ذخیره و اعمال</button>
    <button id="qsClose" class="sec">بستن</button>
  </div>
</div>
<main>
<div class="vpn-note">🔒 توصیه می‌شود برای دریافت کامل داده‌های صرافی‌ها و تحلیل هوش مصنوعی از <b>VPN</b> پایدار استفاده کنید.</div>
<div class="note">ابزار آموزشی · زمان‌ها UTC · دمو مجازی ۱۰۰ USDT · توصیه معاملاتی نیست</div>

<!-- TAB: HOME -->
<div class="tab-panel active" id="tab-home">
<section class="card accent-b">
<h2>🏠 خانه · اجرای تحلیل</h2>

<div class="controls">
 <div><label>جفت‌ارز Spot</label><input id="symbol" value="BTC-USDT" list="syms"><datalist id="syms"><option>BTC-USDT</option><option>ETH-USDT</option><option>SOL-USDT</option><option>XRP-USDT</option><option>DOGE-USDT</option><option>BNB-USDT</option><option>HYPE-USDT</option><option>TON-USDT</option><option>ADA-USDT</option><option>AVAX-USDT</option><option>LINK-USDT</option></datalist></div>
 <div><label>نماد Futures KuCoin (خالی=خودکار)</label><input id="futSymbol" placeholder="XBTUSDTM"></div>
 <div><label>حالت بازه زمانی</label><select id="mode"><option value="count">تعداد کندل آخر</option><option value="preset">پریست زمانی</option><option value="range">بازه دلخواه (UTC)</option></select></div>
 <div><label>تعداد کندل (۵۰ تا ۵۰۰۰)</label><input id="count" type="number" value="1000" min="50" max="5000"></div>
 <div><label>پریست</label><select id="preset"><option value="1">۲۴ ساعت</option><option value="7">۷ روز</option><option value="30" selected>۳۰ روز</option><option value="90">۹۰ روز</option><option value="180">۱۸۰ روز</option><option value="365">۱ سال</option><option value="730">۲ سال</option></select></div>
 <div><label>شروع (UTC)</label><input id="startDT" type="datetime-local"></div>
 <div><label>پایان (UTC)</label><input id="endDT" type="datetime-local"></div>
 <div><label>تایم‌فریم اصلی (امتیاز)</label><select id="mainTF"><option>5min</option><option>15min</option><option>30min</option><option selected>1hour</option><option>2hour</option><option>4hour</option><option>1day</option><option>1week</option></select></div>
</div>
<h3>تایم‌فریم‌ها</h3>
<div class="chk" id="tfBox">
 <label><input type="checkbox" class="tf" value="1min">1m</label><label><input type="checkbox" class="tf" value="3min">3m</label>
 <label><input type="checkbox" class="tf" value="5min" checked>5m</label><label><input type="checkbox" class="tf" value="15min" checked>15m</label>
 <label><input type="checkbox" class="tf" value="30min" checked>30m</label><label><input type="checkbox" class="tf" value="1hour" checked>1h</label>
 <label><input type="checkbox" class="tf" value="2hour">2h</label><label><input type="checkbox" class="tf" value="4hour" checked>4h</label>
 <label><input type="checkbox" class="tf" value="6hour">6h</label><label><input type="checkbox" class="tf" value="8hour">8h</label>
 <label><input type="checkbox" class="tf" value="12hour">12h</label><label><input type="checkbox" class="tf" value="1day" checked>1d</label>
 <label><input type="checkbox" class="tf" value="1week">1w</label>
</div>
<h3>منابع و بخش‌ها</h3>
<div class="chk">
 <label><input type="checkbox" id="incCVD" checked>CVD اسپات/فیوچرز</label>
 <label><input type="checkbox" id="incDeriv" checked>OI/فاندینگ چند صرافی</label>
 <label><input type="checkbox" id="incOpt" checked>Deribit Options</label>
 <label><input type="checkbox" id="incMacro" checked>ماکرو</label>
 <label><input type="checkbox" id="incETH" checked>همبستگی ETH</label>
 <label><input type="checkbox" id="incOnchain" checked>آن‌چین BTC</label>
 <label><input type="checkbox" id="incNews" checked>اخبار RSS</label>
 <label><input type="checkbox" id="incLive" checked>جریان زنده + لیکوئید</label>
</div>
<div class="row" style="margin-top:10px"><button id="runBtn">🚀 دریافت و تحلیل کامل</button><button id="aiBtn" class="pur" disabled>🧠 تحلیل سیگنال APEX AI</button><button id="stopBtn" class="red">⏹ توقف</button></div>
<div class="bar"><div id="prog"></div></div>
<div id="status" class="status" style="margin-top:8px">آماده.</div>
</section>

<section class="card ai-hero" id="homeAiCard">
<h2>🧠 خوانش زنده APEX</h2>
<p class="muted">متن کامل تحلیل AI بلافاصله اینجا می‌آید. با Auto-Trade، معامله روی دمو خودکار باز می‌شود.</p>
<div class="row">
 <button id="aiBtn2" class="pur" disabled>🧠 اجرای خوانش APEX</button>
 <button id="aiOpenDemo" class="blue" disabled>📈 باز کردن از سیگنال</button>
 <button id="aiCopy" class="sec" disabled>📋 کپی</button>
 <button type="button" class="sec" onclick="switchTab('trade')">ترمینال معامله</button>
</div>
<div id="aiStatus" class="muted" style="margin-top:8px">منتظر تحلیل کامل…</div>
<div id="aiSig" class="sig-block" style="display:none"></div>
<div id="aiOut" class="ai-pre" style="margin-top:10px;display:none"></div>
</section>

<section class="card"><h2>📦 خروجی فشرده (همه داده‌ها، بدون حذف)</h2>
<div class="row">
 <button class="blue" id="dlJsonGz">⬇️ JSON فشرده (.json.gz)</button>
 <button class="blue" id="dlCsvGz">⬇️ CSV کندل‌ها (.csv.gz)</button>
 <button class="blue" id="dlSum">⬇️ CSV خلاصه</button>
 <button class="pur" id="saveJsonGz">💾 JSON فشرده در Downloads</button>
 <button class="pur" id="saveCsvGz">💾 CSV فشرده در Downloads</button>
 <button class="sec" id="copyBtn">📋 کپی خلاصه</button>
</div>
<div id="sizeInfo" class="box">حجم خروجی بعد از اجرای تحلیل محاسبه می‌شود.</div>
<p class="muted">فرمت JSON: هر تایم‌فریم یک بلوک <b>cols</b> (نام ستون‌ها) و <b>rows</b> (داده‌ها) دارد. با همان نام ستون‌ها هر ردیف را می‌توان دوباره به شیء تبدیل کرد.</p>
</section>

<section class="card" style="background:linear-gradient(145deg,#1a2a44,#0e1829)"><h2>🎯 امتیاز هم‌گرایی ترکیبی</h2>
<p class="muted">ترکیب وزنی حدود ۱۶ سیگنال: روند، مومنتوم، ایچیموکو، VWAP، CVD، MFI/CMF، فاندینگ، OI×قیمت، Positioning، Options، احساسات، ماکرو، آن‌چین، عمق دفتر، MTF، واگرایی. مقدار بین -100 تا +100.</p>
<div class="row" style="align-items:center"><div style="flex:0 0 auto"><div id="confValue" class="v" style="font-size:30px;direction:ltr">—</div><div id="confBadge" style="margin-top:6px"></div><div id="confConf" class="muted"></div></div><div style="flex:1 1 300px"><div class="confbar"><div class="midline"></div><div class="conffill" id="confFill" style="width:50%"></div></div></div></div>
<div class="grid" id="sigGrid" style="margin-top:8px"></div>
<div id="confWhy" class="box"></div>
</section>

<section class="card"><h2>📊 نمای کلی</h2><div class="grid" id="overview"></div></section>
</div><!-- /tab-home -->

<div class="tab-panel" id="tab-market">
<section class="card"><h2>📍 سطوح فنی (اطلاعاتی)</h2><div class="grid" id="levels"></div></section>
<section class="card"><h2>🧩 ساختار، الگو، Regime، فیبوناچی</h2><div class="grid" id="extra"></div><div id="patBox" class="box"></div><div class="scroll"><table id="fibTbl" style="margin-top:6px"></table></div></section>
<section class="card"><h2>💰 مشتقات چند صرافی</h2><div class="scroll"><table id="derivs"></table></div></section>
<section class="card"><h2>📜 تاریخچه فاندینگ Binance (تجمعی)</h2><div class="scroll"><table id="fundTbl"></table></div></section>
<section class="card"><h2>🧾 CVD اسپات vs فیوچرز</h2><div class="scroll"><table id="cvdTbl"></table></div></section>
<section class="card"><h2>🧭 MTF و شاخص‌های هر تایم‌فریم</h2><div class="scroll"><table id="tfTbl"></table></div><div id="mtfBox" class="box"></div></section>
<section class="card"><h2>🔀 واگرایی‌ها (pivot)</h2><div id="divBox"></div></section>
<section class="card"><h2>🕯️ نمودار کندل</h2>
<div class="row"><div><label>تایم‌فریم</label><select id="chartTF"></select></div><div><label>تعداد کندل نمایش</label><select id="chartN"><option value="100">100</option><option value="200" selected>200</option><option value="500">500</option><option value="1000">1000</option><option value="0">همه</option></select></div></div>
<div class="chk" style="margin:8px 0"><label><input type="checkbox" id="ovEMA" checked>EMA20/50/200</label><label><input type="checkbox" id="ovHMA">Hull MA21</label><label><input type="checkbox" id="ovBB" checked>Bollinger</label><label><input type="checkbox" id="ovKC">Keltner</label><label><input type="checkbox" id="ovST" checked>Supertrend</label><label><input type="checkbox" id="ovVWAP" checked>VWAP</label><label><input type="checkbox" id="ovICH">Ichimoku</label><label><input type="checkbox" id="ovFIB">فیبوناچی</label></div>
<canvas id="chart"></canvas>
</section>
<section class="card"><h2>📊 Volume Profile</h2><div id="vpBox" class="scroll"></div></section>
<section class="card"><h2>📖 عمق بازار و دیوارها (۵۰۰ سطح)</h2><div id="books"></div></section>
<section class="card"><h2>🔥 لیکوئیدیشن: زنده + مدل تقریبی</h2><div id="liqBox"></div><p class="muted">نقشه مدل است (بر پایه حجم کندل‌ها و اهرم‌های فرضی ۵ تا ۱۰۰)، نه پوزیشن‌های واقعی.</p></section>
<section class="card"><h2>🎲 Deribit Options (BTC/ETH)</h2><div id="optBox" class="grid"></div></section>
<section class="card"><h2>📐 آمار بازده، ریسک و فصلی بودن</h2><div class="grid" id="retBox"></div><div class="row" style="align-items:flex-start;margin-top:8px"><div style="flex:1 1 300px"><h3>میانگین بازده هر ساعت UTC</h3><div class="scroll"><table id="hourTbl"></table></div></div><div style="flex:1 1 300px"><h3>میانگین بازده هر روز هفته (روزانه)</h3><table id="wdayTbl"></table><h3>سهم حجم سشن‌ها (1h)</h3><div id="sessBox" class="grid"></div></div></div></section>
<section class="card"><h2>🌍 ماکرو و همبستگی</h2><div class="scroll"><table id="macroTbl"></table></div></section>
<section class="card"><h2>😱 احساسات و آن‌چین</h2><div class="grid" id="sentBox"></div><div class="grid" id="onchainBox" style="margin-top:8px"></div></section>
<section class="card"><h2>🧮 ماشین‌حساب ریسک (آموزشی)</h2>
<div class="row"><div><label>سرمایه (USDT)</label><input id="rCap" type="number" value="1000"></div><div><label>ریسک (%)</label><input id="rPct" type="number" value="1"></div><div><label>ورود</label><input id="rEntry" type="number"></div><div><label>حد ضرر</label><input id="rStop" type="number"></div><div style="flex:0 0 140px"><label>&nbsp;</label><button id="rBtn" class="sec">محاسبه</button></div></div>
<div id="riskBox" class="box"></div></section>
<section class="card"><h2>🔔 هشدار قیمت</h2>
<div class="row"><input id="alerts" placeholder="سطوح با کاما: 80000, 82500"><button id="alertBtn" class="sec" style="flex:0 0 120px">ثبت</button></div>
<div id="alertBox" class="muted">هشدار وقتی قیمت زنده از سطح عبور کند نمایش داده می‌شود.</div></section>

<section class="card"><h2>📰 اخبار</h2>
<div class="row"><input id="newsQ" placeholder="فیلتر کلمه (مثلاً ETF)"><select id="newsSrc" style="flex:0 0 160px"><option value="">همه منابع</option></select></div>
<div id="newsBox" class="scroll" style="margin-top:8px"></div><div id="newsErr" class="muted"></div></section>
<section class="card"><h2>📅 تقویم رویدادها (این هفته)</h2>
<div class="row"><select id="evImpact"><option value="">همه اهمیت‌ها</option><option value="High">High</option><option value="Medium">Medium</option><option value="Low">Low</option></select></div>
<div id="evBox" class="scroll" style="margin-top:8px"></div><div id="evErr" class="muted"></div></section>
<section class="card"><h2>⚡ جریان زنده Binance Futures</h2><div class="grid" id="liveBox"></div><div id="liveMsg" class="muted"></div></section>
<section class="card"><h2>🧠 OI تاریخچه داخلی</h2><div class="grid" id="oiHist"></div></section>

</div><!-- /tab-market -->

<div class="tab-panel" id="tab-trade">
<section class="card accent-g">
<div class="sym-search">
  <input id="coinSearch" placeholder="جستجوی ارز: BTC, ETH, SOL, PEPE ...">
  <button id="coinGo" class="blue" style="flex:0 0 100px">برو</button>
  <button id="coinRefresh" class="sec" style="flex:0 0 100px">قیمت</button>
</div>
<div class="coin-strip" id="coinStrip"></div>
<div class="x-ticker">
  <span class="sym" id="xSym">—</span>
  <span class="px" id="xPrice">—</span>
  <span class="chip" id="xChg">۲۴h —</span>
  <span class="chip" id="xFund">Fund —</span>
  <span class="chip" id="xOi">OI —</span>
  <span class="chip" id="xTick">⏱ —</span>
</div>
<div class="x-account" id="xAccount">
  <div class="cell"><div class="l">موجودی</div><div class="n" id="xBal">100.00</div></div>
  <div class="cell"><div class="l">اکوئیتی</div><div class="n" id="xEq">100.00</div></div>
  <div class="cell"><div class="l">PnL باز</div><div class="n" id="xUpnl">0.00</div></div>
  <div class="cell"><div class="l">PnL بسته</div><div class="n" id="xRpnl">0.00</div></div>
</div>
<div class="halt-banner" id="haltBanner">معاملات متوقف است. <button id="demoResume" class="sec" style="flex:0;width:auto;display:inline-block;margin-right:8px">از سرگیری</button></div>
<div class="row" style="margin:8px 0">
 <button id="demoDeposit" class="blue">+ واریز</button>
 <button id="demoWithdraw" class="sec">− برداشت</button>
 <button id="demoResume2" class="sec">از سرگیری معاملات</button>
 <button id="demoExport" class="pur">دانلود پرتفوی کامل</button>
 <button id="demoAutoTrade" class="long">🚀 معامله خودکار (Auto-Trade)</button>
 <button id="demoAutoStop" class="short">⏹ توقف خودکار</button>
 <button id="demoRefresh" class="sec">رفرش</button>
 <button id="demoCloseAll" class="red">بستن همه</button>
 <button id="demoReset" class="red">ریست</button>
</div>
<div class="grid">
  <div class="card" style="margin:0;padding:10px"><h3 style="margin-top:0">منحنی اکوئیتی</h3><div class="eq-bars" id="eqBars"></div></div>
  <div class="card" style="margin:0;padding:10px"><h3 style="margin-top:0">هشدارهای زنده</h3><div id="alertList" class="scroll" style="max-height:120px"></div>
  <button id="alertsRead" class="sec" style="margin-top:6px">علامت‌خوانده</button></div>
</div>
<div class="x-layout">
  <div class="x-form">
    <h3>ثبت سفارش</h3>
    <div class="side-toggle">
      <button type="button" id="manLongBtn" class="long on-long">LONG</button>
      <button type="button" id="manShortBtn" class="short">SHORT</button>
    </div>
    <input type="hidden" id="manSide" value="LONG">
    <div class="controls" style="grid-template-columns:1fr 1fr">
      <div><label>قیمت ورود</label><input id="manEntry" type="number" step="any"></div>
      <div><label>اهرم</label><input id="manLev" type="number" value="5" min="1" max="100"></div>
      <div><label>حالت سایز</label><select id="manSizeMode"><option value="usd">مبلغ دلاری (USDT)</option><option value="pct">درصد مارجین</option></select></div>
      <div><label id="manSizeLabel">مبلغ مارجین (USDT)</label><input id="manSize" type="number" value="10" min="1" max="10000" step="1"></div>
      <div><label>ریسک % (اختیاری)</label><input id="manRisk" type="number" value="" placeholder="خالی=مارجین%" step="0.5"></div>
      <div><label>TP1</label><input id="manTp1" type="number" step="any"></div>
      <div><label>TP2</label><input id="manTp2" type="number" step="any"></div>
      <div><label>TP3</label><input id="manTp3" type="number" step="any"></div>
      <div><label>SL</label><input id="manSl" type="number" step="any"></div>
    </div>
    <div class="row" style="margin-top:10px">
      <button id="manFillPrice" class="sec">قیمت بازار</button>
      <button id="manOpen" class="long">باز کردن پوزیشن</button>
    </div>
    <div class="box" id="manPreview" style="margin-top:8px;font-size:11px">پیش‌نمایش سفارش بعد از وارد کردن قیمت/SL</div>
  </div>
  <div>
    <h3>پوزیشن‌های باز <span class="muted" id="demoTickInfo"></span></h3>
    <div id="demoPos"></div>
    <h3>آمار عملکرد</h3>
    <div class="grid" id="demoStats"></div>
    <div class="grid" id="demoWallet" style="display:none"></div>
  </div>
</div>
<h3>تاریخچه معاملات</h3>
<div class="scroll"><table id="demoHist" class="x-pos-table"></table></div>
<div id="demoEvents" class="box" style="margin-top:8px;max-height:140px;overflow:auto;font-family:ui-monospace,monospace;font-size:11px"></div>
</section>
</div><!-- /tab-trade -->

<div class="tab-panel" id="tab-ai">
<section class="card accent-p">
<h2>🧠 آرشیو و جزئیات APEX</h2>
<p class="muted">همان خوانش زنده در تب خانه نمایش داده می‌شود؛ اینجا برای مرور مجدد.</p>
<div class="row"><button type="button" class="pur" onclick="runApex()">اجرای مجدد APEX</button>
<button type="button" class="sec" onclick="switchTab('home')">بازگشت به خانه</button></div>
<div id="aiArchive" class="ai-pre" style="margin-top:10px">هنوز خوانشی ذخیره نشده.</div>
</section>
</div><!-- /tab-ai -->

<div class="tab-panel" id="tab-more">
<section class="card">
<h2>⚙️ تنظیمات موتور دمو و اپ</h2>
<div class="controls" id="demoSettingsBox">
 <div><label>معامله خودکار بعد از تحلیل</label><select id="ds_auto_trade"><option value="1">روشن</option><option value="0">خاموش</option></select></div>
 <div><label>اهرم پیش‌فرض</label><input id="ds_default_leverage" type="number" value="5" min="1" max="100"></div>
 <div><label>حداکثر اهرم</label><input id="ds_max_leverage" type="number" value="20" min="1" max="125"></div>
 <div><label>حداکثر ریسک هر معامله %</label><input id="ds_max_risk_pct" type="number" value="5" min="0.5" max="20" step="0.5"></div>
 <div><label>حداکثر مارجین از موجودی %</label><input id="ds_max_margin_pct" type="number" value="80" min="5" max="100"></div>
 <div><label>حداکثر پوزیشن همزمان</label><input id="ds_max_positions" type="number" value="20" min="1" max="20"></div>
 <div style="grid-column:1/-1"><label>کلید API هوش مصنوعی (Gemini)</label><input id="ds_gemini_key" type="password" placeholder="کلید جدید را وارد کنید" style="direction:ltr"></div>
 <div style="grid-column:1/-1"><button id="btnSaveApiKey" class="blue">ذخیره کلید API</button></div>

 <div><label>کارمزد</label><input id="ds_fee_rate" type="number" value="0.0004" step="0.0001"></div>
 <div><label>لغزش قیمت (bps)</label><input id="ds_slippage_bps" type="number" value="2" min="0" max="50"></div>
 <div><label>سهم TP1</label><input id="ds_tp1_pct" type="number" value="0.40" step="0.05"></div>
 <div><label>سهم TP2</label><input id="ds_tp2_pct" type="number" value="0.30" step="0.05"></div>
 <div><label>سهم TP3</label><input id="ds_tp3_pct" type="number" value="0.30" step="0.05"></div>
 <div><label>SL → BE بعد از TP1</label><select id="ds_move_be_after_tp1"><option value="1">بله</option><option value="0">خیر</option></select></div>
 <div><label>Trailing بعد از TP1</label><select id="ds_trail_after_tp1"><option value="0">خاموش</option><option value="1">روشن</option></select></div>
 <div><label>بازه تیک (ms)</label><input id="ds_tick_ms" type="number" value="1000" min="500" max="5000" step="100"></div>
 <div><label>حالت سایز</label><select id="ds_size_mode"><option value="usd">مبلغ دلاری ثابت</option><option value="signal">از سیگنال AI</option><option value="risk">بر اساس ریسک %</option><option value="fixed">درصد ثابت مارجین</option></select></div>
 <div><label>حداقل Conviction AI (۱-۱۰)</label><input id="ds_min_conviction" type="number" value="6" min="1" max="10"></div>
 <div><label>حد ضرر روزانه %</label><input id="ds_daily_loss_limit_pct" type="number" value="10" min="1" max="50"></div>
 <div><label>توقف در Max DD %</label><input id="ds_max_dd_halt_pct" type="number" value="25" min="5" max="80"></div>
 <div><label>الزام SL در سیگنال AI</label><select id="ds_ai_require_sl"><option value="1">بله</option><option value="0">خیر</option></select></div>
 <div><label>Trailing پیش‌فرض</label><select id="ds_trail_after_tp1"><option value="1">روشن</option><option value="0">خاموش</option></select></div>
</div>
<div class="row" style="margin-top:10px"><button id="demoSaveSettings" class="pur">💾 ذخیره تنظیمات</button>
<button type="button" class="sec" onclick="openSheet(true)">⚙ تنظیمات سریع</button></div>
<div class="note" style="margin-top:12px">تغییرات روی معاملات بعدی اعمال می‌شود. تیک هر ثانیه ترمینال را زنده نگه می‌دارد. از منوی ☰ و دکمه ⚙ بالای صفحه هم می‌توانید سریع تنظیم کنید.</div>
<section class="card" style="margin-top:12px">
<h3>وضعیت سیستم</h3>
<div class="grid">
  <div class="metric"><div class="k">نسخه</div><div class="v">12.0</div></div>
  <div class="metric"><div class="k">حالت</div><div class="v">Demo Paper</div></div>
  <div class="metric"><div class="k">AI</div><div class="v">APEX / Gemini</div></div>
  <div class="metric"><div class="k">تیک</div><div class="v" id="sysTick">1s</div></div>
</div>
</section>
</section>

<section class="card about-card">
<h2>👤 درباره سازنده</h2>
<p>با سلام و درود.</p>
<p>من <b>امیر — AMIR KHAN</b>، سازنده این اپلیکیشن هستم. برنامه‌نویسی مسلط به اغلب زبان‌ها، فناوری اطلاعات و امنیت سایبری، و علاقه‌مند به بازارهای مالی و ترید.</p>
<p>این ابزار <b>صرفاً آزمایشی</b> و برای اهداف <b>آموزشی</b> طراحی شده است؛ هدف، تمرین خوانش بازار، مدیریت ریسک و شبیه‌سازی معامله در محیطی امن و بدون سرمایه واقعی است.</p>
<p style="margin-top:12px;color:var(--muted);font-size:12px">APEX Terminal · نسخه ۱۱ · ساخته‌شده با تمرکز روی داده زنده، هوش مصنوعی و دمو ترید حرفه‌ای</p>
</section>
</div><!-- /tab-more -->



</section>
</main>
<nav class="bottom-nav" id="bottomNav">
  <button type="button" class="active" data-tab="home"><span class="ico">🏠</span>خانه</button>
  <button type="button" data-tab="trade"><span class="ico">📈</span>ترمینال</button>
  <button type="button" data-tab="market"><span class="ico">📊</span>بازار</button>
  <button type="button" data-tab="ai"><span class="ico">🧠</span>هوش مصنوعی</button>
  <button type="button" data-tab="more"><span class="ico">☰</span>بیشتر</button>
</nav>

<script>
'use strict';
const $=id=>document.getElementById(id);
const N=x=>{if(x===null||x===undefined||x==='')return null;const v=Number(x);return Number.isFinite(v)?v:null};
const fmt=(x,d=4)=>{const v=N(x);return v==null?'—':v.toLocaleString('en-US',{maximumFractionDigits:d})};
const fp=x=>{const v=N(x);if(v==null)return'—';return Math.abs(v)>=100?v.toLocaleString('en-US',{maximumFractionDigits:2}):v.toPrecision(6)};
const pc=(x,d=2)=>{const v=N(x);return v==null?'—':(v>0?'+':'')+v.toFixed(d)+'%'};
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const tone=v=>v==null?'':(v>0?'good':v<0?'bad':'');
const M=(k,v,c='')=>`<div class="metric"><div class="k">${esc(k)}</div><div class="v ${c}">${v}</div></div>`;
const iso=s=>new Date(s*1000).toISOString().slice(0,16).replace('T',' ');
const mean=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:null;
const sd=a=>{const m=mean(a);return a.length>1&&m!=null?Math.sqrt(a.reduce((s,x)=>s+(x-m)**2,0)/(a.length-1)):null};
const TF_SEC={'1min':60,'3min':180,'5min':300,'15min':900,'30min':1800,'1hour':3600,'2hour':7200,'4hour':14400,'6hour':21600,'8hour':28800,'12hour':43200,'1day':86400,'1week':604800};
const TF_ORDER=Object.keys(TF_SEC);
const BIN_TF={'1min':'1m','3min':'3m','5min':'5m','15min':'15m','30min':'30m','1hour':'1h','2hour':'2h','4hour':'4h','6hour':'6h','8hour':'8h','12hour':'12h','1day':'1d','1week':'1w'};
const S={data:null,abort:false,alerts:[],live:{ws:null,timer:null,trades:[],liq:[],last:null,prev:null}};

function status(t){$('status').textContent=t}
function prog(p){$('prog').style.width=clamp(p,0,100)+'%'}
function banner(t){const b=$('banner');b.textContent=t;b.classList.add('show');setTimeout(()=>b.classList.remove('show'),2800)}

// ---------- Fetch ----------
async function pj(url,tries=2){let e;for(let i=0;i<tries;i++){try{const r=await fetch('/proxy?url='+encodeURIComponent(url));const j=await r.json();if(!r.ok||j.__proxy_error)throw new Error(j.error||('HTTP '+r.status));return j}catch(x){e=x;await sleep(350*(i+1))}}throw e}
async function lj(path){const r=await fetch(path);const j=await r.json();if(!r.ok||j.error)throw new Error(j.error||('HTTP '+r.status));return j}
const kcData=async u=>{const j=await pj(u);if(String(j.code)!=='200000')throw new Error('KuCoin '+j.code+' '+(j.msg||''));return j.data};
const byData=async u=>{const j=await pj(u);if(j.retCode!==0)throw new Error('Bybit '+j.retCode+' '+j.retMsg);return j.result};
const okxData=async u=>{const j=await pj(u);if(j.code!=='0')throw new Error('OKX '+j.code+' '+(j.msg||''));return j.data};
const drData=async u=>{const j=await pj(u);if(j.error)throw new Error('Deribit '+(j.error.message||''));return j.result};

// صفحه‌بندی با cursor واقعی: از قدیمی‌ترین کندل هر صفحه ادامه می‌دهیم
async function fetchKc(sym,tf,startSec,endSec){
  const map=new Map();let cur=endSec,guard=0;
  while(cur>startSec&&guard++<5000){
    if(S.abort)throw new Error('متوقف شد');
    const rows=await kcData(`https://api.kucoin.com/api/v1/market/candles?symbol=${sym}&type=${tf}&startAt=${startSec}&endAt=${cur}`);
    if(!rows||!rows.length)break;
    let minT=Infinity;
    for(const a of rows){const t=+a[0];if(t<minT)minT=t;if(t>=startSec&&t<=endSec)map.set(t,{time:t,open:+a[1],close:+a[2],high:+a[3],low:+a[4],volume:+a[5],turnover:+a[6]})}
    if(minT>=cur)break;
    cur=minT-1;
    await sleep(120);
  }
  return [...map.values()].sort((a,b)=>a.time-b.time);
}
async function binKlines(market,pair,tf){
  const base=market==='fut'?'https://fapi.binance.com/fapi/v1/klines':'https://api.binance.com/api/v3/klines';
  const rows=await pj(`${base}?symbol=${pair}&interval=${BIN_TF[tf]}&limit=1000`);
  return rows.map(r=>({t:Math.floor(+r[0]/1000),vol:+r[5],tb:+r[9]}));
}

// ---------- Indicators ----------
function sma(a,p){const o=new Array(a.length).fill(null);let s=0;for(let i=0;i<a.length;i++){s+=a[i];if(i>=p)s-=a[i-p];if(i>=p-1)o[i]=s/p}return o}
function ema(a,p){const o=new Array(a.length).fill(null),k=2/(p+1);let prev=null,seed=0;for(let i=0;i<a.length;i++){if(i<p-1){seed+=a[i];continue}if(i===p-1){seed+=a[i];prev=seed/p;o[i]=prev;continue}prev=a[i]*k+prev*(1-k);o[i]=prev}return o}
function emaN(a,p){const o=new Array(a.length).fill(null);const s=a.findIndex(v=>v!=null);if(s<0)return o;const e=ema(a.slice(s),p);for(let i=0;i<e.length;i++)o[s+i]=e[i];return o}
function rma(a,p){const o=new Array(a.length).fill(null);let s=0,prev=null;for(let i=0;i<a.length;i++){if(i<p){s+=a[i];if(i===p-1){prev=s/p;o[i]=prev}continue}prev=(prev*(p-1)+a[i])/p;o[i]=prev}return o}
function rollMax(a,p){return a.map((_,i)=>{if(i<p-1)return null;let m=-Infinity;for(let k=i-p+1;k<=i;k++)if(a[k]>m)m=a[k];return m})}
function rollMin(a,p){return a.map((_,i)=>{if(i<p-1)return null;let m=Infinity;for(let k=i-p+1;k<=i;k++)if(a[k]<m)m=a[k];return m})}
function rollSum(a,p){const o=new Array(a.length).fill(null);let s=0;for(let i=0;i<a.length;i++){s+=a[i];if(i>=p)s-=a[i-p];if(i>=p-1)o[i]=s}return o}
function wma(a,p){const o=new Array(a.length).fill(null),den=p*(p+1)/2;for(let i=p-1;i<a.length;i++){let s=0;for(let k=0;k<p;k++)s+=a[i-p+1+k]*(k+1);o[i]=s/den}return o}
function hull(a,p){const h=wma(a,Math.floor(p/2)),f=wma(a,p);const d=a.map((_,i)=>h[i]!=null&&f[i]!=null?2*h[i]-f[i]:null);const s=Math.round(Math.sqrt(p));const o=new Array(a.length).fill(null);
  for(let i=0;i<a.length;i++){if(i-s+1<0)continue;let num=0,den=0,ok=true;for(let k=0;k<s;k++){const v=d[i-s+1+k];if(v==null){ok=false;break}num+=v*(k+1);den+=k+1}if(ok)o[i]=num/den}return o}
function rsi(c,p=14){const n=c.length,o=new Array(n).fill(null);if(n<=p)return o;const g=[],l=[];for(let i=1;i<n;i++){const d=c[i]-c[i-1];g.push(Math.max(d,0));l.push(Math.max(-d,0))}const ag=rma(g,p),al=rma(l,p);for(let i=0;i<n-1;i++){if(ag[i]==null)continue;o[i+1]=al[i]===0?(ag[i]===0?50:100):100-100/(1+ag[i]/al[i])}return o}
function adx(c,p=14){const n=c.length,tr=[],pd=[],md=[];for(let i=0;i<n;i++){if(i===0){tr.push(c[0].high-c[0].low);pd.push(0);md.push(0);continue}const up=c[i].high-c[i-1].high,dn=c[i-1].low-c[i].low;pd.push(up>dn&&up>0?up:0);md.push(dn>up&&dn>0?dn:0);tr.push(Math.max(c[i].high-c[i].low,Math.abs(c[i].high-c[i-1].close),Math.abs(c[i].low-c[i-1].close)))}
  const aT=rma(tr,p),aP=rma(pd,p),aM=rma(md,p);const pdi=[],mdi=[],dx=[];
  for(let i=0;i<n;i++){if(aT[i]==null||aT[i]===0){pdi.push(null);mdi.push(null);dx.push(null);continue}const a=100*aP[i]/aT[i],b=100*aM[i]/aT[i];pdi.push(a);mdi.push(b);dx.push(a+b?100*Math.abs(a-b)/(a+b):0)}
  const ad=rma(dx.map(x=>x==null?0:x),p).map((v,i)=>dx[i]==null?null:v);return {adx:ad,pdi,mdi,atr:aT,tr}}
function stoch(c,p,d){const hh=rollMax(c.map(x=>x.high),p),ll=rollMin(c.map(x=>x.low),p);const k=c.map((x,i)=>hh[i]==null?null:(hh[i]===ll[i]?50:(x.close-ll[i])/(hh[i]-ll[i])*100));const D=sma(k.map(v=>v??0),d).map((v,i)=>k[i]==null?null:v);return {k,d:D}}
function supertrend(c,atr,m=3){const n=c.length,fu=[],fl=[],st=[],dir=[];for(let i=0;i<n;i++){if(atr[i]==null){fu.push(null);fl.push(null);st.push(null);dir.push(null);continue}
  const hl=(c[i].high+c[i].low)/2,bu=hl+m*atr[i],bl=hl-m*atr[i];const pu=fu[i-1]??null,pl=fl[i-1]??null,pc=i?c[i-1].close:null;
  const up=(pu==null||bu<pu||pc>pu)?bu:pu;const lo=(pl==null||bl>pl||pc<pl)?bl:pl;fu.push(up);fl.push(lo);
  let d;const prev=st[i-1];if(prev==null)d=c[i].close>up?1:-1;else if(prev===pu)d=c[i].close>up?1:-1;else d=c[i].close<lo?-1:1;
  dir.push(d);st.push(d===1?lo:up)}return {line:st,dir}}
function cciFn(c,p){const tp=c.map(x=>(x.high+x.low+x.close)/3),ma=sma(tp,p);return tp.map((v,i)=>{if(ma[i]==null)return null;let md=0;for(let k=i-p+1;k<=i;k++)md+=Math.abs(tp[k]-ma[i]);md/=p;return md?(v-ma[i])/(0.015*md):0})}
function mfiFn(c,p){const tp=c.map(x=>(x.high+x.low+x.close)/3);const pos=[],neg=[];for(let i=0;i<c.length;i++){const f=tp[i]*(c[i].volume||0);pos.push(i&&tp[i]>tp[i-1]?f:0);neg.push(i&&tp[i]<tp[i-1]?f:0)}const sp=rollSum(pos,p),sn=rollSum(neg,p);return sp.map((v,i)=>v==null||sn[i]==null?null:(sn[i]===0?100:100-100/(1+v/sn[i])))}
function cmfFn(c,p){const mf=c.map(x=>{const r=x.high-x.low;return r>0?((x.close-x.low)-(x.high-x.close))/r*(x.volume||0):0});const v=c.map(x=>x.volume||0);const a=rollSum(mf,p),b=rollSum(v,p);return a.map((x,i)=>x==null||!b[i]?null:x/b[i])}
function obvFn(c){const o=[0];for(let i=1;i<c.length;i++){const p=o[i-1];o.push(c[i].close>c[i-1].close?p+c[i].volume:c[i].close<c[i-1].close?p-c[i].volume:p)}return o}
function vwapSession(c){let pv=0,v=0,day=null;return c.map(x=>{const d=Math.floor(x.time/86400);if(d!==day){day=d;pv=0;v=0}const tp=(x.high+x.low+x.close)/3,vol=x.volume||0;pv+=tp*vol;v+=vol;return v?pv/v:null})}
function ichimoku(c){const n=c.length,H=c.map(x=>x.high),L=c.map(x=>x.low);const mid=p=>{const hh=rollMax(H,p),ll=rollMin(L,p);return hh.map((v,i)=>v==null?null:(v+ll[i])/2)};
  const T=mid(9),K=mid(26),SB=mid(52);const a=new Array(n).fill(null),b=new Array(n).fill(null);
  for(let i=26;i<n;i++)if(T[i-26]!=null&&K[i-26]!=null)a[i]=(T[i-26]+K[i-26])/2;
  for(let i=52;i<n;i++)b[i]=SB[i-26];return {t:T,k:K,a,b}}
function aroon(c,p=25){const up=new Array(c.length).fill(null),dn=new Array(c.length).fill(null);for(let i=p;i<c.length;i++){let hi=-Infinity,hj=i,lo=Infinity,lj2=i;for(let k=i-p;k<=i;k++){if(c[k].high>=hi){hi=c[k].high;hj=k}if(c[k].low<=lo){lo=c[k].low;lj2=k}}up[i]=(p-(i-hj))/p*100;dn[i]=(p-(i-lj2))/p*100}return {up,dn}}
function chop(c,tr,p=14){const hh=rollMax(c.map(x=>x.high),p),ll=rollMin(c.map(x=>x.low),p),s=rollSum(tr,p);return c.map((_,i)=>hh[i]==null||hh[i]===ll[i]?null:100*Math.log10(s[i]/(hh[i]-ll[i]))/Math.log10(p))}
function ulcer(cl,p=14){const o=new Array(cl.length).fill(null);for(let i=p-1;i<cl.length;i++){let m=-Infinity;for(let k=i-p+1;k<=i;k++)if(cl[k]>m)m=cl[k];let s=0;for(let k=i-p+1;k<=i;k++){const d=(cl[k]/m-1)*100;s+=d*d}o[i]=Math.sqrt(s/p)}return o}
function pivots(a,l,r,type){const out=[];for(let i=l;i<a.length-r;i++){let ok=true;for(let k=1;k<=l&&ok;k++)ok=type==='H'?a[i]>a[i-k]:a[i]<a[i-k];for(let k=1;k<=r&&ok;k++)ok=type==='H'?a[i]>=a[i+k]:a[i]<=a[i+k];if(ok)out.push(i)}return out}

function calc(c){
  const n=c.length;if(n<2)return c;
  const cl=c.map(x=>x.close);
  const e20=ema(cl,20),e50=ema(cl,50),e200=ema(cl,200),e9=ema(cl,9),e12=ema(cl,12),e26=ema(cl,26);
  const macd=e12.map((v,i)=>v!=null&&e26[i]!=null?v-e26[i]:null),macdS=emaN(macd,9);
  const r=rsi(cl,14),A=adx(c,14),atr=A.atr,s20=sma(cl,20);
  const sd2=cl.map((_,i)=>{if(s20[i]==null)return null;let v=0;for(let k=i-19;k<=i;k++)v+=(cl[k]-s20[i])**2;return Math.sqrt(v/20)});
  const st=supertrend(c,atr,3),sk=stoch(c,14,3);
  const wr=(()=>{const hh=rollMax(c.map(x=>x.high),14),ll=rollMin(c.map(x=>x.low),14);return c.map((x,i)=>hh[i]==null?null:(hh[i]===ll[i]?-50:(hh[i]-x.close)/(hh[i]-ll[i])*-100))})();
  const cci=cciFn(c,20),mfi=mfiFn(c,14),cmf=cmfFn(c,20),obv=obvFn(c),vw=vwapSession(c),ich=ichimoku(c);
  const dcU=rollMax(c.map(x=>x.high),20),dcL=rollMin(c.map(x=>x.low),20);
  const hm=hull(cl,21),ar=aroon(c,25),ch=chop(c,A.tr,14),ul=ulcer(cl,14);
  const bpy=31536000/((c[1].time-c[0].time)||3600);
  const lr=cl.map((v,i)=>i?Math.log(v/cl[i-1]):0);
  const rv=lr.map((_,i)=>{if(i<20)return null;const sl=lr.slice(i-19,i+1);const m=sl.reduce((a,b)=>a+b,0)/20;return Math.sqrt(sl.reduce((a,b)=>a+(b-m)**2,0)/19*bpy)*100});
  return c.map((x,i)=>({...x,ema9:e9[i],ema20:e20[i],ema50:e50[i],ema200:e200[i],macd:macd[i],macdSig:macdS[i],
    macdH:(macd[i]!=null&&macdS[i]!=null)?macd[i]-macdS[i]:null,rsi:r[i],atr:atr[i],adx:A.adx[i],pdi:A.pdi[i],mdi:A.mdi[i],
    bbM:s20[i],bbU:s20[i]!=null?s20[i]+2*sd2[i]:null,bbL:s20[i]!=null?s20[i]-2*sd2[i]:null,
    kcU:e20[i]!=null&&atr[i]!=null?e20[i]+2*atr[i]:null,kcL:e20[i]!=null&&atr[i]!=null?e20[i]-2*atr[i]:null,
    dcU:dcU[i],dcL:dcL[i],stLine:st.line[i],stDir:st.dir[i],stK:sk.k[i],stD:sk.d[i],wr:wr[i],cci:cci[i],
    mfi:mfi[i],cmf:cmf[i],obv:obv[i],vwap:vw[i],ichT:ich.t[i],ichK:ich.k[i],ichA:ich.a[i],ichB:ich.b[i],
    hma:hm[i],aroonUp:ar.up[i],aroonDn:ar.dn[i],chop:ch[i],ulcer:ul[i],rv:rv[i]}));
}
function cvdScore(arr){const a=arr.filter(v=>v!=null).slice(-21);if(a.length<22)return null;const ch=a[a.length-1]-a[0];let abs=0;for(let i=1;i<a.length;i++)abs+=Math.abs(a[i]-a[i-1]);return abs?clamp(ch/abs*2,-1,1):0}
function volProfile(c,bins=40){
  if(!c||c.length<5)return null;let mn=Infinity,mx=-Infinity;for(const x of c){if(x.low<mn)mn=x.low;if(x.high>mx)mx=x.high}
  if(!(mx>mn))return null;const step=(mx-mn)/bins;const v=new Float64Array(bins),buy=new Float64Array(bins),sell=new Float64Array(bins);
  for(const x of c){let lo=Math.min(bins-1,Math.floor((x.low-mn)/step)),hi=Math.min(bins-1,Math.floor((x.high-mn)/step));if(hi<lo)hi=lo;const per=(x.volume||0)/(hi-lo+1);
    for(let b=lo;b<=hi;b++){v[b]+=per;if(x.close>=x.open)buy[b]+=per;else sell[b]+=per}}
  let poc=0;for(let i=1;i<bins;i++)if(v[i]>v[poc])poc=i;const total=v.reduce((a,b)=>a+b,0);const target=total*0.7;
  let lo=poc,hi=poc,acc=v[poc];
  while(acc<target&&(lo>0||hi<bins-1)){const lv=lo>0?v[lo-1]:-1,hv=hi<bins-1?v[hi+1]:-1;if(hv>=lv){hi++;acc+=v[hi]}else{lo--;acc+=v[lo]}}
  const avg=total/bins;const hvn=[],lvn=[];for(let i=0;i<bins;i++){if(v[i]>avg*1.5)hvn.push(mn+(i+0.5)*step);if(v[i]<avg*0.4)lvn.push(mn+(i+0.5)*step)}
  return {mn,mx,step,bins,v,buy,sell,poc,pocPrice:mn+(poc+0.5)*step,val:mn+lo*step,vah:mn+(hi+1)*step,total,hvn,lvn};
}
function attachCVD(c,bars,key){const m=new Map(bars.map(b=>[b.t,b]));let cum=0;for(const x of c){const b=m.get(x.time);if(b){cum+=2*b.tb-b.vol;x[key]=cum}else x[key]=null}}

// ---------- Patterns / structure / fib / stats ----------
function patterns(c){
  const n=c.length;if(n<3)return [];const b=c[n-1],p=c[n-2],q=c[n-3];const out=[];
  const body=Math.abs(b.close-b.open),rng=(b.high-b.low)||1e-9,up=b.high-Math.max(b.open,b.close),dn=Math.min(b.open,b.close)-b.low;
  if(body/rng<0.1)out.push('Doji');
  if(body>0&&dn>2*body&&up<body*0.5)out.push('Hammer (برگشت صعودی احتمالی)');
  if(body>0&&up>2*body&&dn<body*0.5)out.push('Shooting Star (برگشت نزولی احتمالی)');
  if(b.close>b.open&&p.close<p.open&&b.close>=p.open&&b.open<=p.close)out.push('Bullish Engulfing');
  if(b.close<b.open&&p.close>p.open&&b.open>=p.close&&b.close<=p.open)out.push('Bearish Engulfing');
  const qb=Math.abs(q.close-q.open),pb=Math.abs(p.close-p.open);
  if(q.close<q.open&&pb<qb*0.3&&b.close>b.open&&b.close>(q.open+q.close)/2)out.push('Morning Star (تقریبی)');
  if(q.close>q.open&&pb<qb*0.3&&b.close<b.open&&b.close<(q.open+q.close)/2)out.push('Evening Star (تقریبی)');
  return out;
}
function structure(c){
  const H=pivots(c.map(x=>x.high),3,3,'H'),L=pivots(c.map(x=>x.low),3,3,'L');
  const hs=H.slice(-2).map(i=>c[i].high),ls=L.slice(-2).map(i=>c[i].low),txt=[];
  if(hs.length===2)txt.push(hs[1]>hs[0]?'سقف بالاتر (HH)':'سقف پایین‌تر (LH)');
  if(ls.length===2)txt.push(ls[1]>ls[0]?'کف بالاتر (HL)':'کف پایین‌تر (LL)');
  const last=c.at(-1).close;
  if(hs.length&&last>hs.at(-1))txt.push('شکست سقف اخیر (BOS↑)');
  if(ls.length&&last<ls.at(-1))txt.push('شکست کف اخیر (BOS↓)');
  return {txt:txt.join(' · ')||'—'};
}
function fib(c){
  const Hs=pivots(c.map(x=>x.high),3,3,'H').slice(-1)[0],Ls=pivots(c.map(x=>x.low),3,3,'L').slice(-1)[0];
  if(Hs==null||Ls==null)return null;const hi=c[Hs].high,lo=c[Ls].low,up=Hs>Ls;
  return {up,hi,lo,levels:[0,0.236,0.382,0.5,0.618,0.786,1].map(r=>({r,p:up?hi-(hi-lo)*r:lo+(hi-lo)*r}))};
}
function retStats(c){
  const r=[];for(let i=1;i<c.length;i++)r.push(c[i].close/c[i-1].close-1);if(r.length<20)return null;
  const n=r.length,m=mean(r),s=sd(r);const sk=r.reduce((a,b)=>a+((b-m)/s)**3,0)/n,ku=r.reduce((a,b)=>a+((b-m)/s)**4,0)/n-3;
  const so=[...r].sort((a,b)=>a-b),q=p=>so[Math.floor(p*(n-1))];
  let eq=1,pk=1,mdd=0;for(const x of r){eq*=1+x;pk=Math.max(pk,eq);mdd=Math.min(mdd,eq/pk-1)}
  const dd=Math.sqrt(r.filter(x=>x<0).reduce((a,b)=>a+b*b,0)/n);
  return {n,mean:m,sd:s,ann:s*Math.sqrt(365),skew:sk,kurt:ku,var95:q(0.05),var99:q(0.01),mdd,
    sortino:dd?(m*365)/(dd*Math.sqrt(365)):null,best:so[n-1],worst:so[0],pos:r.filter(x=>x>0).length/n};
}
function seasonality(c1h,c1d){
  const hr=Array.from({length:24},()=>({s:0,n:0})),wd=Array.from({length:7},()=>({s:0,n:0}));
  for(let i=1;i<c1h.length;i++){const h=new Date(c1h[i].time*1000).getUTCHours();hr[h].s+=c1h[i].close/c1h[i-1].close-1;hr[h].n++}
  for(let i=1;i<c1d.length;i++){const d=new Date(c1d[i].time*1000).getUTCDay();wd[d].s+=c1d[i].close/c1d[i-1].close-1;wd[d].n++}
  return {hour:hr.map(x=>x.n?x.s/x.n:null),hourN:hr.map(x=>x.n),wday:wd.map(x=>x.n?x.s/x.n:null),wdayN:wd.map(x=>x.n)};
}
function sessionShare(c){const b={Asia:0,Europe:0,US:0,Late:0};let tot=0;for(const x of c){const h=new Date(x.time*1000).getUTCHours();const v=x.volume||0;tot+=v;if(h<7)b.Asia+=v;else if(h<13)b.Europe+=v;else if(h<21)b.US+=v;else b.Late+=v}return tot?Object.fromEntries(Object.entries(b).map(([k,v])=>[k,v/tot])):null}
function pearson(a,b){const n=Math.min(a.length,b.length);if(n<10)return null;a=a.slice(-n);b=b.slice(-n);const ma=mean(a),mb=mean(b);let c=0,va=0,vb=0;for(let i=0;i<n;i++){c+=(a[i]-ma)*(b[i]-mb);va+=(a[i]-ma)**2;vb+=(b[i]-mb)**2}return va&&vb?{r:c/Math.sqrt(va*vb),beta:c/vb,n}:null}
function dailyReturns(candles){const m=new Map();for(const x of candles)m.set(Math.floor(x.time/86400),x.close);const k=[...m.keys()].sort((a,b)=>a-b);const out=new Map();for(let i=1;i<k.length;i++)out.set(k[i],m.get(k[i])/m.get(k[i-1])-1);return out}
function corrMaps(ma,mb){const xs=[],ys=[];for(const [d,v] of ma)if(mb.has(d)){xs.push(v);ys.push(mb.get(d))}return pearson(xs,ys)}
function divergences(c){
  const out=[];const cl=c.map(x=>x.close);
  for(const key of ['rsi','cvdF']){
    const H=pivots(cl,3,3,'H').filter(i=>i>c.length-60).slice(-2),L=pivots(cl,3,3,'L').filter(i=>i>c.length-60).slice(-2);
    const v=i=>c[i][key];
    if(H.length===2&&v(H[0])!=null&&v(H[1])!=null&&c[H[1]].close>c[H[0]].close&&v(H[1])<v(H[0]))out.push({type:'bear',text:`نزولی ${key}`});
    if(L.length===2&&v(L[0])!=null&&v(L[1])!=null&&c[L[1]].close<c[L[0]].close&&v(L[1])>v(L[0]))out.push({type:'bull',text:`صعودی ${key}`});
  }
  return out;
}

// ---------- Books / options / liquidation ----------
function bookWalls(book){
  if(!book||!book.bids)return null;
  const lv=[...book.bids.map(([p,q])=>({s:'bid',p:+p,q:+q,v:+p*+q})),...book.asks.map(([p,q])=>({s:'ask',p:+p,q:+q,v:+p*+q}))];
  const avg=mean(lv.map(x=>x.v));
  const bidV=lv.filter(x=>x.s==='bid').reduce((a,b)=>a+b.v,0),askV=lv.filter(x=>x.s==='ask').reduce((a,b)=>a+b.v,0);
  const top=s=>lv.filter(x=>x.s===s&&x.v>avg*4).sort((a,b)=>b.v-a.v).slice(0,6);
  return {bidV,askV,imb:(bidV+askV)?(bidV-askV)/(bidV+askV):null,bidWalls:top('bid'),askWalls:top('ask'),spread:(+book.asks[0][0]-+book.bids[0][0])};
}
function parseOptions(list){
  if(!list||!list.length)return null;const MON={JAN:0,FEB:1,MAR:2,APR:3,MAY:4,JUN:5,JUL:6,AUG:7,SEP:8,OCT:9,NOV:10,DEC:11};
  let cOI=0,pOI=0,ivN=0,ivD=0;const byE={};
  for(const x of list){const m=/^[A-Z]+-(\d{1,2})([A-Z]{3})(\d{2})-(\d+)-([CP])$/.exec(x.instrument_name||'');if(!m)continue;
    const oi=+x.open_interest||0,K=+m[4],t=m[5],key=m[1]+m[2]+m[3];
    if(t==='C')cOI+=oi;else pOI+=oi;ivN+=(+x.mark_iv||0)*oi;ivD+=oi;
    if(!byE[key])byE[key]={key,ts:Date.UTC(2000+ +m[3],MON[m[2]],+m[1],8),legs:[]};
    byE[key].legs.push({K,t,oi})}
  const now=Date.now();const exps=Object.values(byE).filter(e=>e.ts>now).sort((a,b)=>a.ts-b.ts);
  const near=exps[0];let maxPain=null;
  if(near){const strikes=[...new Set(near.legs.map(l=>l.K))];let best=Infinity;
    for(const s0 of strikes){let pain=0;for(const l of near.legs)pain+=l.t==='C'?l.oi*Math.max(0,s0-l.K):l.oi*Math.max(0,l.K-s0);if(pain<best){best=pain;maxPain=s0}}}
  const topExp=exps.map(e=>({key:e.key,oi:e.legs.reduce((a,b)=>a+b.oi,0)})).sort((a,b)=>b.oi-a.oi).slice(0,5);
  return {callOI:cOI,putOI:pOI,pcr:cOI?pOI/cOI:null,ivAvg:ivD?ivN/ivD:null,maxPain,nearest:near?near.key:null,topExp};
}
function liqModel(c,price){
  if(!c||c.length<20||!price)return [];
  const lev=[[5,.10],[10,.25],[25,.30],[50,.20],[100,.15]];const step=price*0.0025;const bins={};
  for(const x of c.slice(-300)){const v=x.volume||0,up=x.close>=x.open,entry=(x.high+x.low+x.close)/3;
    for(const [L,w] of lev){const liq=up?entry*(1-1/L+0.004):entry*(1+1/L-0.004);const k=Math.round(liq/step);
      if(!bins[k])bins[k]={p:k*step,long:0,short:0};if(up)bins[k].long+=v*w;else bins[k].short+=v*w}}
  return Object.values(bins).filter(b=>Math.abs(b.p-price)/price<0.15).sort((a,b)=>(b.long+b.short)-(a.long+a.short)).slice(0,14).sort((a,b)=>a.p-b.p);
}

// ---------- Confluence ----------
function confluence(D){
  const tf=D.mainTF,c=D.candles[tf];if(!c||c.length<60)return null;
  const x=c[c.length-1],pr=x.close,atr=x.atr||pr*0.01;const sig=[];
  const add=(name,w,v,det)=>{if(v==null||!Number.isFinite(v))return;sig.push({name,w,v:clamp(v,-1,1),det})};
  {let t=0,k=0;if(x.ema20!=null&&x.ema50!=null&&x.ema200!=null){k++;t+=(x.ema20>x.ema50&&x.ema50>x.ema200)?1:(x.ema20<x.ema50&&x.ema50<x.ema200)?-1:0}
   if(x.stDir!=null){k++;t+=x.stDir*0.8}
   if(k)add('روند',1.5,(t/k)*(x.adx!=null&&x.adx<18?0.5:1),`ADX ${fmt(x.adx,1)} · ST ${x.stDir===1?'↑':'↓'}`)}
  {const s=[],p=[];if(x.rsi!=null){s.push((x.rsi-50)/25);p.push('RSI '+fmt(x.rsi,1))}if(x.macdH!=null){s.push(x.macdH/atr*2);p.push('MACD-H')}if(x.stK!=null)s.push((x.stK-50)/40);
   if(x.hma!=null&&x.ema20!=null)s.push(pr>x.hma?0.5:-0.5);
   if(s.length)add('مومنتوم',1.2,mean(s),p.join(' · '))}
  if(x.aroonUp!=null)add('Aroon',0.5,(x.aroonUp-x.aroonDn)/100,`↑${fmt(x.aroonUp,0)} ↓${fmt(x.aroonDn,0)}`);
  if(x.ichA!=null&&x.ichB!=null){const top=Math.max(x.ichA,x.ichB),bot=Math.min(x.ichA,x.ichB);const v=pr>top?1:pr<bot?-1:0;add('ابر ایچیموکو',0.8,v*0.8+(x.ichT>x.ichK?0.2:-0.2),pr>top?'بالای ابر':pr<bot?'زیر ابر':'داخل ابر')}
  if(x.vwap!=null)add('VWAP',0.6,(pr-x.vwap)/atr*0.6,pr>x.vwap?'بالای VWAP':'زیر VWAP');
  if(x.bbU!=null){const b=(pr-x.bbL)/((x.bbU-x.bbL)||1);add('بولینگر %b',0.4,(b-0.5)*1.2,`%b=${fmt(b,2)}`)}
  {const sp=cvdScore(c.map(y=>y.cvdS)),fu=cvdScore(c.map(y=>y.cvdF));
   if(sp!=null&&fu!=null){let v=0.6*sp+0.4*fu;if(fu>0.3&&sp<-0.2)v-=0.4;add('CVD اسپات/فیوچرز',1.0,v,`Spot ${sp.toFixed(2)} · Fut ${fu.toFixed(2)}`)}}
  if(x.mfi!=null)add('MFI/CMF',0.5,(x.mfi-50)/30*0.5+(x.cmf??0)*1.5,`MFI ${fmt(x.mfi,1)} · CMF ${fmt(x.cmf,3)}`);
  {const fr=[D.funding.kc?.value,D.funding.bin?.lastFundingRate,D.funding.byb?.fundingRate,D.funding.okx?.fundingRate].map(N).filter(v=>v!=null);
   if(fr.length){const a=mean(fr);add('فاندینگ (معکوس)',1.0,-clamp(a/0.0005,-1,1)*0.8,`میانگین ${(a*100).toFixed(4)}% از ${fr.length} صرافی`)}}
  {const oc=D.oi24?.bin??D.oi24?.kc,pch=N(D.market?.changeRate);if(oc!=null&&pch!=null){const o=oc*100,p=pch*100;let v=0;
   if(o>1&&p>1)v=0.6;else if(o>1&&p<-1)v=-0.6;else if(o<-1&&p>1)v=0.2;else if(o<-1&&p<-1)v=-0.2;add('OI × قیمت (24h)',1.0,v,`OI ${pc(o)} · قیمت ${pc(p)}`)}}
  {const g=N(D.positioning?.gl?.longShortRatio),t=N(D.positioning?.top?.longShortRatio);const parts=[];let v=0,k=0;
   if(g!=null){v+=-clamp((g-1)/0.8,-1,1)*0.5;k++;parts.push('Global L/S '+fmt(g,2))}
   if(t!=null){v+=clamp((t-1)/0.5,-1,1)*0.5;k++;parts.push('Top L/S '+fmt(t,2))}
   if(k)add('Positioning',0.8,v/k,parts.join(' · '))}
  if(D.options){const o=D.options;let v=clamp((o.pcr-0.9)/0.6,-1,1)*0.4;if(o.maxPain)v+=clamp((pr-o.maxPain)/pr*-8,-0.3,0.3);add('Options (Deribit)',0.7,o.maxPain?v/2:v,`P/C ${fmt(o.pcr,2)} · MaxPain ${fp(o.maxPain)}`)}
  if(D.fng?.length){const f=N(D.fng[0].value);add('احساسات (معکوس)',0.5,(50-f)/50*0.7,`${D.fng[0].value_classification||''} (${f})`)}
  if(D.macro?.length){const sg={'DXY':-1,'S&P 500':1,'NASDAQ':1,'US10Y':-1,'VIX':-1};let v=0,k=0,parts=[];for(const m of D.macro){if(!(m.name in sg)||m.c1==null)continue;v+=sg[m.name]*clamp(m.c1/0.01,-1,1)*0.3;k++;parts.push(`${m.name} ${pc(m.c1*100)}`)}if(k)add('کلان (روزانه)',0.6,v/k*2,parts.join(' · '))}
  if(D.onchain?.length){const nt=D.onchain.find(o=>o.key==='n-transactions');if(nt&&nt.chg!=null)add('آن‌چین (تراکنش)',0.3,clamp(nt.chg*2,-0.5,0.5),`تراکنش ${pc(nt.chg*100)}`)}
  for(const [lab,bk] of [['عمق Spot',D.books?.spot],['عمق Futures',D.books?.fut]])if(bk&&bk.imb!=null)add(lab,0.4,bk.imb*0.8,`Bid/Ask ${pc(bk.imb*100)}`);
  {const ts=D.tfs.filter(t=>D.candles[t]?.length&&D.candles[t].at(-1).ema20!=null);let b=0,br=0;for(const t of ts){const y=D.candles[t].at(-1);if(y.ema20>y.ema50&&y.stDir===1)b++;else if(y.ema20<y.ema50&&y.stDir===-1)br++}
   if(ts.length)add('هم‌گرایی MTF',1.4,(b-br)/ts.length,`${b}↑ / ${br}↓ از ${ts.length} TF`)}
  {const dv=divergences(c);if(dv.length)add('واگرایی',0.6,mean(dv.map(d=>d.type==='bull'?0.6:-0.6)),dv.map(d=>d.text).join(' · '))}
  let W=0,T=0;for(const s of sig){W+=s.w;T+=s.w*s.v}
  const score=W?Math.round(T/W*100):0;const MAXW=16.2;
  const label=score>=50?'خرید قوی':score>=20?'خرید':score>-20?'خنثی':score>-50?'فروش':'فروش قوی';
  const bc=score>=50?'b-sb':score>=20?'b-b':score>-20?'b-n':score>-50?'b-s':'b-ss';
  return {score,label,bc,sig,conf:Math.round(clamp(W/MAXW,0,1)*100)};
}

// ---------- Fetch orchestration ----------
function parseLocal(s){if(!s)return null;const t=Date.parse(s.length===16?s+':00Z':s+'Z');return isNaN(t)?null:Math.floor(t/1000)}
function getTimeCfg(){
  const now=Math.floor(Date.now()/1000),mode=$('mode').value;
  if(mode==='count'){const n=clamp(+$('count').value||1000,50,5000);return {mode,count:n,startSec:null,endSec:now}}
  if(mode==='preset'){const d=+$('preset').value;return {mode,startSec:now-d*86400,endSec:now}}
  const s=parseLocal($('startDT').value),e=parseLocal($('endDT').value)||now;
  if(s==null)throw new Error('تاریخ شروع را وارد کن.');if(e<=s)throw new Error('پایان باید بعد از شروع باشد.');
  return {mode,startSec:s,endSec:e};
}
async function fetchAll(){
  S.abort=false;
  const base=$('symbol').value.trim().toUpperCase();
  if(!/^[A-Z0-9]{2,15}-USDT$/.test(base))throw new Error('نماد نامعتبر (مثلاً BTC-USDT).');
  const B=base.split('-')[0],bPair=B+'USDT';
  const kcFut=$('futSymbol').value.trim().toUpperCase()||(B==='BTC'?'XBTUSDTM':B+'USDTM');
  const tfs=[...document.querySelectorAll('.tf:checked')].map(x=>x.value).sort((a,b)=>TF_ORDER.indexOf(a)-TF_ORDER.indexOf(b));
  if(!tfs.length)throw new Error('حداقل یک تایم‌فریم انتخاب کن.');
  const cfg=getTimeCfg(),now=cfg.endSec;
  const mainTF=tfs.includes($('mainTF').value)?$('mainTF').value:tfs[0];
  const D={symbol:base,base:B,kcFut,bPair,mainTF,tfs,mode:cfg.mode,countUsed:cfg.count||null,startSec:cfg.startSec,endSec:cfg.endSec,
    candles:{},errors:{},funding:{},oi:{},oi24:{},positioning:{},books:{},macro:[],onchain:[],fng:[],news:[],events:[],ts:new Date().toISOString()};

  const all=[...new Set([...tfs,'1day'])];
  for(let i=0;i<all.length;i++){
    const tf=all[i];prog(5+50*i/all.length);status(`دریافت کندل ${tf} (${i+1}/${all.length})…`);
    try{
      const inList=tfs.includes(tf);
      const start=inList?(cfg.mode==='count'?now-cfg.count*TF_SEC[tf]:cfg.startSec):now-150*86400;
      const c=await fetchKc(B+'-USDT',tf,start,now);
      if(!c.length)throw new Error('بدون داده');
      D.candles[tf]=calc(c);
    }catch(e){D.errors['کندل '+tf]=e.message}
  }
  if(S.abort)throw new Error('متوقف شد');
  if($('incETH').checked&&B!=='ETH'){try{D.eth1d=await fetchKc('ETH-USDT','1day',now-150*86400,now)}catch(e){D.errors['ETH 1d']=e.message}}
  if($('incCVD').checked){
    for(let i=0;i<tfs.length;i++){const tf=tfs[i];prog(55+15*i/tfs.length);status(`CVD ${tf} (اسپات و فیوچرز)…`);
      if(!D.candles[tf])continue;
      try{const [sp,fu]=await Promise.all([binKlines('spot',bPair,tf),binKlines('fut',bPair,tf)]);attachCVD(D.candles[tf],sp,'cvdS');attachCVD(D.candles[tf],fu,'cvdF')}
      catch(e){D.errors['CVD '+tf]=e.message}}
  }
  prog(72);status('دریافت مشتقات، دفتر سفارش، ماکرو و اخبار…');
  const dOn=$('incDeriv').checked;
  const jobs={
    kcStats:kcData(`https://api.kucoin.com/api/v1/market/stats?symbol=${base}`),
    kcBook:kcData(`https://api.kucoin.com/api/v1/market/orderbook/level2_20?symbol=${base}`),
    kcFunding:kcData(`https://api-futures.kucoin.com/api/v1/funding-rate/${kcFut}/current`),
    kcContract:kcData(`https://api-futures.kucoin.com/api/v1/contracts/${kcFut}`),
    kcFutBook:kcData(`https://api-futures.kucoin.com/api/v1/level2/depth20?symbol=${kcFut}`),
    kcFutTicker:kcData(`https://api-futures.kucoin.com/api/v1/ticker?symbol=${kcFut}`),
    kcSpotTrades:kcData(`https://api.kucoin.com/api/v1/market/histories?symbol=${base}`),
    kcFutTrades:kcData(`https://api-futures.kucoin.com/api/v1/trade/history?symbol=${kcFut}`),
    bnSpotBook:pj(`https://api.binance.com/api/v3/depth?symbol=${bPair}&limit=500`),
    bnFutBook:pj(`https://fapi.binance.com/fapi/v1/depth?symbol=${bPair}&limit=500`),
    bnPremium:dOn?pj(`https://fapi.binance.com/fapi/v1/premiumIndex?symbol=${bPair}`):Promise.resolve(null),
    bnFundHist:dOn?pj(`https://fapi.binance.com/fapi/v1/fundingRate?symbol=${bPair}&limit=1000`):Promise.resolve([]),
    bnOI:dOn?pj(`https://fapi.binance.com/futures/data/openInterestHist?symbol=${bPair}&period=1h&limit=500`):Promise.resolve([]),
    bnGlobal:dOn?pj(`https://fapi.binance.com/futures/data/globalLongShortAccountRatio?symbol=${bPair}&period=1h&limit=500`):Promise.resolve([]),
    bnTop:dOn?pj(`https://fapi.binance.com/futures/data/topLongShortPositionRatio?symbol=${bPair}&period=1h&limit=500`):Promise.resolve([]),
    bnTaker:dOn?pj(`https://fapi.binance.com/futures/data/takerlongshortRatio?symbol=${bPair}&period=1h&limit=500`):Promise.resolve([]),
    byTicker:dOn?byData(`https://api.bybit.com/v5/market/tickers?category=linear&symbol=${bPair}`):Promise.resolve(null),
    byOI:dOn?byData(`https://api.bybit.com/v5/market/open-interest?category=linear&symbol=${bPair}&intervalTime=1h&limit=25`):Promise.resolve(null),
    okFund:dOn?okxData(`https://www.okx.com/api/v5/public/funding-rate?instId=${B}-USDT-SWAP`):Promise.resolve(null),
    okOI:dOn?okxData(`https://www.okx.com/api/v5/public/open-interest?instType=SWAP&instId=${B}-USDT-SWAP`):Promise.resolve(null),
    deribit:(B==='BTC'||B==='ETH')&&$('incOpt').checked?drData(`https://www.deribit.com/api/v2/public/get_book_summary_by_currency?currency=${B}&kind=option`):Promise.resolve(null),
    fng:pj('https://api.alternative.me/fng/?limit=30&format=json'),
    onchain:B==='BTC'&&$('incOnchain').checked?Promise.all(['n-transactions','n-unique-addresses','hash-rate','estimated-transaction-volume-usd'].map(k=>pj(`https://api.blockchain.info/charts/${k}?timespan=30days&format=json`).then(j=>({key:k,vals:j.values||[]})))):Promise.resolve([]),
    macro:$('incMacro').checked?Promise.all([['DXY','DX-Y.NYB'],['S&P 500','^GSPC'],['NASDAQ','^IXIC'],['US10Y','^TNX'],['VIX','^VIX'],['Gold','GC=F']].map(([n,s])=>pj(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(s)}?range=6mo&interval=1d`).then(j=>({name:n,j:j.chart.result[0]})).catch(e=>({name:n,err:e.message})))):Promise.resolve([]),
    news:$('incNews').checked?lj('/news?q='+B):Promise.resolve(null),
    events:lj('/events?symbol='+B).catch(e=>({events:[],errors:[e.message]})),
  };
  const keys=Object.keys(jobs);const res=await Promise.allSettled(Object.values(jobs));const R={};
  keys.forEach((k,i)=>{if(res[i].status==='fulfilled')R[k]=res[i].value;else D.errors[k]=String(res[i].reason?.message||res[i].reason)});
  prog(88);

  D.market=R.kcStats||null;
  D.spot=N(R.kcStats?.last)||D.candles[mainTF]?.at(-1)?.close||null;
  D.fut=N(R.kcFutTicker?.price)||null;
  D.basisPct=(D.spot&&D.fut)?(D.fut-D.spot)/D.spot*100:null;
  D.funding={kc:R.kcFunding||null,bin:R.bnPremium||null,byb:R.byTicker?.list?.[0]||null,okx:R.okFund?.[0]||null};
  const bnOIarr=Array.isArray(R.bnOI)?R.bnOI:[];
  const pctOf=arr=>{if(!arr||arr.length<25)return null;const a=N(arr.at(-1).sumOpenInterest),b=N(arr.at(-25).sumOpenInterest);return a&&b?(a-b)/b:null};
  D.oi={kc:N(R.kcContract?.openInterest),bin:N(bnOIarr.at(-1)?.sumOpenInterest),byb:N(R.byOI?.list?.[0]?.openInterest),okx:N(R.okOI?.[0]?.oi)};
  D.oi24={kc:null,bin:pctOf(bnOIarr),byb:(R.byOI?.list?.length>24)?(N(R.byOI.list[0].openInterest)-N(R.byOI.list[24].openInterest))/N(R.byOI.list[24].openInterest):null};
  D.positioning={gl:(R.bnGlobal||[]).at(-1)||null,top:(R.bnTop||[]).at(-1)||null,taker:(R.bnTaker||[]).at(-1)||null};
  D.books={spot:bookWalls(R.bnSpotBook),fut:bookWalls(R.bnFutBook),kcSpot:R.kcBook||null,kcFut:R.kcFutBook||null};
  D.options=parseOptions(R.deribit);
  D.fng=R.fng?.data||[];
  D.onchain=(R.onchain||[]).map(o=>{const v=o.vals;const last=v.at(-1)?.y,prev=v.at(-2)?.y;return {key:o.key,last,chg:(last!=null&&prev)?(last-prev)/prev:null}});
  D.macro=[];
  if(Array.isArray(R.macro)&&R.macro.length){
    const dayC=dailyReturns(D.candles['1day']||[]);
    for(const m of R.macro){
      if(!m.j){D.macro.push({name:m.name,err:m.err});continue}
      const ts=m.j.timestamp||[],cl=m.j.indicators?.quote?.[0]?.close||[];
      const mp=new Map();for(let i=0;i<ts.length;i++)if(cl[i]!=null)mp.set(Math.floor(ts[i]/86400),cl[i]);
      const days=[...mp.keys()].sort((a,b)=>a-b);const last=mp.get(days.at(-1)),prev=mp.get(days.at(-2)),p5=mp.get(days.at(-6));
      const ma=new Map();for(const [d,r] of mp){if(mp.has(d-1))ma.set(d,mp.get(d)/mp.get(d-1)-1)}
      const pr=corrMaps(dayC,ma);
      D.macro.push({name:m.name,last,c1:(last&&prev)?last/prev-1:null,c5:(last&&p5)?last/p5-1:null,corr:pr?.r??null,beta:pr?.beta??null,n:pr?.n??0});
    }
  }
  D.ethCorr=(D.eth1d&&D.candles['1day'])?corrMaps(dailyReturns(D.candles['1day']),dailyReturns(D.eth1d)):null;
  D.news=R.news?.items||[];D.newsErrors=R.news?.errors||[];
  D.events=R.events?.events||[];D.eventErrors=R.events?.errors||[];
  D.trades={spot:R.kcSpotTrades||[],fut:R.kcFutTrades?.items||R.kcFutTrades||[]};
  D.liq=liqModel(D.candles[tfs.includes('1hour')?'1hour':mainTF],D.spot||D.fut);
  D.ext={fundHist:Array.isArray(R.bnFundHist)?R.bnFundHist:[],oiHist:bnOIarr,taker:Array.isArray(R.bnTaker)?R.bnTaker:[]};
  D.raw={kcFunding:R.kcFunding,bnPremium:R.bnPremium,byTicker:R.byTicker,okFund:R.okFund,okOI:R.okOI};
  try{if(D.oi.kc)await fetch('/oi_snapshot',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({symbol:'KC:'+kcFut,oi:D.oi.kc,price:D.spot||0})});
      if(D.oi.bin)await fetch('/oi_snapshot',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({symbol:'BN:'+bPair,oi:D.oi.bin,price:D.spot||0})})}catch(e){}
  prog(100);
  return D;
}

// ---------- Render ----------
function renderAll(D){
  const tfsOK=D.tfs.filter(t=>D.candles[t]?.length);
  const mainC=D.candles[D.mainTF]||[];const x=mainC.at(-1)||{};const m=D.market||{};
  $('overview').innerHTML=[
    M('قیمت Spot',fp(D.spot),tone(N(m.changeRate))),M('تغییر ۲۴h',pc(N(m.changeRate)*100),tone(N(m.changeRate))),
    M('حجم ۲۴h (USDT)',fmt(m.volValue,0)),M('بالا/پایین ۲۴h',`${fp(m.high)} / ${fp(m.low)}`),
    M('قیمت Futures',fp(D.fut)),M('Basis',pc(D.basisPct,3),tone(D.basisPct)),
    M('بازه',D.mode==='count'?`${D.countUsed} کندل (هر TF)`:`${iso(D.startSec)} → ${iso(D.endSec)}`),
    M('TF موفق',tfsOK.length+' / '+D.tfs.length)].join('');

  const cf=confluence(D);
  if(cf){
    $('confValue').textContent=(cf.score>0?'+':'')+cf.score;$('confValue').className='v '+(cf.score>20?'good':cf.score<-20?'bad':'warn');
    $('confBadge').innerHTML=`<span class="badge ${cf.bc}">${cf.label}</span> <span class="muted">TF امتیاز: ${D.mainTF}</span>`;
    $('confConf').textContent=`اطمینان داده: ${cf.conf}% · سیگنال‌ها: ${cf.sig.length}`;
    $('confFill').style.width=clamp((cf.score+100)/2,0,100)+'%';
    $('sigGrid').innerHTML=cf.sig.map(s=>`<div class="sig"><div class="l">${esc(s.name)} <span class="muted">(w=${s.w})</span></div><div class="v ${s.v>0.15?'good':s.v<-0.15?'bad':''}">${s.v>0.15?'▲':s.v<-0.15?'▼':'●'} ${(s.v*100).toFixed(0)}</div><div class="muted" style="font-size:10px">${esc(s.det||'')}</div></div>`).join('');
    const bu=cf.sig.filter(s=>s.v>0.15).map(s=>s.name),be=cf.sig.filter(s=>s.v<-0.15).map(s=>s.name);
    $('confWhy').innerHTML=(bu.length?`<span class="good">صعودی: ${bu.map(esc).join('، ')}</span><br>`:'')+(be.length?`<span class="bad">نزولی: ${be.map(esc).join('، ')}</span>`:'');
  }else{$('confValue').textContent='—';$('confBadge').innerHTML='<span class="muted">داده کافی نیست (حداقل ۶۰ کندل در TF اصلی)</span>'}

  // Levels
  const vp=volProfile(mainC.slice(-300));const d1=D.candles['1day'];const lv=[];
  if(d1&&d1.length>1){const p=d1.at(-2);const P=(p.high+p.low+p.close)/3;lv.push(M('Pivot P',fp(P)),M('R1 / S1',`${fp(2*P-p.low)} / ${fp(2*P-p.high)}`),M('R2 / S2',`${fp(P+p.high-p.low)} / ${fp(P-(p.high-p.low))}`))}
  if(vp)lv.push(M('POC ('+D.mainTF+')',fp(vp.pocPrice)),M('VAH / VAL',`${fp(vp.vah)} / ${fp(vp.val)}`),M('HVN / LVN',`${vp.hvn.length} / ${vp.lvn.length}`));
  if(x.vwap)lv.push(M('VWAP روزانه',fp(x.vwap),tone(D.spot-x.vwap)));
  if(x.stLine)lv.push(M('Supertrend',fp(x.stLine),x.stDir===1?'good':'bad'));
  if(x.dcU)lv.push(M('Donchian 20 ↑/↓',`${fp(x.dcU)} / ${fp(x.dcL)}`));
  if(x.bbU)lv.push(M('BB ↑/↓',`${fp(x.bbU)} / ${fp(x.bbL)}`));
  if(x.atr)lv.push(M('ATR ('+D.mainTF+')',`${fp(x.atr)} (${fmt(x.atr/(D.spot||1)*100,2)}%)`));
  const bw=D.books?.spot;if(bw)lv.push(M('بزرگ‌ترین دیوار Bid',bw.bidWalls[0]?fp(bw.bidWalls[0].p):'—','good'),M('بزرگ‌ترین دیوار Ask',bw.askWalls[0]?fp(bw.askWalls[0].p):'—','bad'));
  $('levels').innerHTML=lv.join('')||'<span class="muted">داده ندارد</span>';

  // Structure / patterns / regime / fib
  const st=structure(mainC),pt=patterns(mainC),fb=fib(mainC);
  const regime=x.chop==null?'—':x.chop>61.8?'بی‌جهت / رنج':x.chop<38.2?'روند قوی':'گذار';
  const volZ=(()=>{const v=mainC.slice(-50).map(y=>y.volume||0);const s=sd(v);return s?((x.volume||0)-mean(v))/s:null})();
  const rvs=mainC.map(y=>y.rv).filter(v=>v!=null);const rvRank=(x.rv!=null&&rvs.length)?rvs.filter(v=>v<=x.rv).length/rvs.length*100:null;
  $('extra').innerHTML=[M('ساختار بازار',st.txt),M('Regime (Choppiness)',regime+' ('+fmt(x.chop,1)+')'),M('Aroon ↑/↓',`${fmt(x.aroonUp,0)} / ${fmt(x.aroonDn,0)}`),
    M('Hull MA21',fp(x.hma),tone(D.spot-x.hma)),M('Ulcer(14)',fmt(x.ulcer,2)),M('Z حجم (50 کندل)',fmt(volZ,2),volZ>2?'warn':''),
    M('رتبه نوسان تاریخی (RV)',rvRank==null?'—':fmt(rvRank,1)+'%'),M('ETH همبستگی روزانه',D.ethCorr?`ρ=${fmt(D.ethCorr.r,3)} β=${fmt(D.ethCorr.beta,3)}`:'—')].join('');
  $('patBox').innerHTML='الگوی آخرین کندل: '+(pt.length?pt.map(esc).join(' · '):'—');
  $('fibTbl').innerHTML=fb?`<thead><tr><th>سطح فیبوناچی</th><th>قیمت</th><th>جهت</th></tr></thead><tbody>${fb.levels.map(l=>`<tr><td>${l.r}</td><td>${fp(l.p)}</td><td>${fb.up?'اصلاح نزولی از سقف':'اصلاح صعودی از کف'}</td></tr>`).join('')}</tbody>`:'<tr><td>سوئینگ کافی پیدا نشد</td></tr>';

  // Derivatives
  const f=D.funding,o=D.oi,o24=D.oi24;
  const rowsD=[['KuCoin Futures',D.fut,f.kc?.value,f.kc?.predictedValue,o.kc,o24.kc],['Binance USDⓈ-M',N(f.bin?.markPrice),f.bin?.lastFundingRate,f.bin?.interestRate,o.bin,o24.bin],['Bybit Linear',N(f.byb?.markPrice),f.byb?.fundingRate,null,o.byb,o24.byb],['OKX SWAP',null,f.okx?.fundingRate,f.okx?.nextFundingRate,o.okx,null]];
  $('derivs').innerHTML='<thead><tr><th>صرافی</th><th>قیمت</th><th>فاندینگ</th><th>فاندینگ بعدی</th><th>OI</th><th>تغییر OI ۲۴h</th></tr></thead><tbody>'+
    rowsD.map(r=>`<tr><td>${r[0]}</td><td>${fp(r[1])}</td><td class="${tone(N(r[2]))}">${N(r[2])==null?'—':(N(r[2])*100).toFixed(4)+'%'}</td><td>${N(r[3])==null?'—':(N(r[3])*100).toFixed(4)+'%'}</td><td>${fmt(r[4],2)}</td><td class="${tone(r[5])}">${r[5]==null?'—':pc(r[5]*100)}</td></tr>`).join('')+'</tbody>';

  // Funding history
  let cum=0;const fh=(D.ext.fundHist||[]).slice(-60);
  $('fundTbl').innerHTML=fh.length?'<thead><tr><th>زمان (UTC)</th><th>نرخ</th><th>تجمعی</th></tr></thead><tbody>'+fh.map(r=>{const v=N(r.fundingRate)||0;cum+=v;return `<tr><td>${iso(Math.floor(+r.fundingTime/1000))}</td><td class="${tone(v)}">${(v*100).toFixed(4)}%</td><td>${(cum*100).toFixed(3)}%</td></tr>`}).join('')+'</tbody>':'<tr><td>تاریخچه نیست</td></tr>';

  // CVD table
  const cvdRows=tfsOK.map(t=>{const cs=D.candles[t];const sp=cvdScore(cs.map(y=>y.cvdS)),fu=cvdScore(cs.map(y=>y.cvdF));
    const l=cs.at(-1);let tag='—';if(sp!=null&&fu!=null){tag=sp>0&&fu<0?'تقویت اسپات (خرید واقعی)':sp<0&&fu>0?'اهرمی (فیوچرز)':sp>0&&fu>0?'هم‌جهت صعودی':sp<0&&fu<0?'هم‌جهت نزولی':'خنثی'}
    return `<tr><td>${t}</td><td class="${tone(sp)}">${sp==null?'—':sp.toFixed(2)}</td><td class="${tone(fu)}">${fu==null?'—':fu.toFixed(2)}</td><td>${fmt(l.cvdS,0)}</td><td>${fmt(l.cvdF,0)}</td><td>${tag}</td></tr>`}).join('');
  $('cvdTbl').innerHTML='<thead><tr><th>TF</th><th>Score Spot</th><th>Score Fut</th><th>CVD Spot</th><th>CVD Fut</th><th>تفسیر</th></tr></thead><tbody>'+(cvdRows||'<tr><td colspan=6>داده CVD نیست</td></tr>')+'</tbody>';

  // TF table
  let bull=0,bear=0;
  $('tfTbl').innerHTML='<thead><tr><th>TF</th><th>Close</th><th>RSI</th><th>ADX</th><th>+DI/-DI</th><th>ST</th><th>EMA stack</th><th>MFI</th><th>CMF</th><th>ATR%</th><th>RV%</th><th>StochK</th><th>CCI</th><th>W%R</th><th>Chop</th><th>Aroon↑</th><th>Hull</th></tr></thead><tbody>'+
   tfsOK.map(t=>{const y=D.candles[t].at(-1);
    const stk=(y.ema20!=null&&y.ema50!=null)?(y.ema20>y.ema50&&y.ema50>(y.ema200??-Infinity)?'↑↑':y.ema20<y.ema50&&y.ema50<(y.ema200??Infinity)?'↓↓':y.ema20>y.ema50?'↑':'↓'):'—';
    if(stk.startsWith('↑')&&y.stDir===1)bull++;else if(stk.startsWith('↓')&&y.stDir===-1)bear++;
    return `<tr><td>${t}</td><td>${fp(y.close)}</td><td class="${y.rsi>70?'bad':y.rsi<30?'good':''}">${fmt(y.rsi,1)}</td><td class="${y.adx>25?'good':''}">${fmt(y.adx,1)}</td><td>${fmt(y.pdi,0)}/${fmt(y.mdi,0)}</td><td class="${y.stDir===1?'good':'bad'}">${y.stDir===1?'UP':'DOWN'}</td><td>${stk}</td><td>${fmt(y.mfi,1)}</td><td class="${tone(y.cmf)}">${fmt(y.cmf,3)}</td><td>${y.atr?fmt(y.atr/y.close*100,2):'—'}</td><td>${fmt(y.rv,1)}</td><td>${fmt(y.stK,1)}</td><td>${fmt(y.cci,0)}</td><td>${fmt(y.wr,1)}</td><td>${fmt(y.chop,1)}</td><td>${fmt(y.aroonUp,0)}</td><td>${fp(y.hma)}</td></tr>`}).join('')+'</tbody>';
  $('mtfBox').innerHTML=`جمع‌بندی MTF: <span class="good">${bull} صعودی</span> · <span class="bad">${bear} نزولی</span> از ${tfsOK.length} تایم‌فریم`;

  // Divergence
  const dv=divergences(mainC);
  $('divBox').innerHTML=dv.length?dv.map(d=>`<div class="box"><b class="${d.type==='bull'?'good':'bad'}">${d.type==='bull'?'صعودی':'نزولی'}</b> · ${esc(d.text)}</div>`).join(''):'<span class="muted">واگرایی pivot-based در TF اصلی پیدا نشد.</span>';

  // VP
  if(vp){const mx=Math.max(...vp.v)||1;let h='';for(let i=vp.bins-1;i>=0;i--){const p=vp.mn+(i+0.5)*vp.step;const tag=i===vp.poc?'POC':(p>=vp.val&&p<=vp.vah?'VA':'');h+=`<div class="row" style="gap:4px;margin:1px 0"><span style="flex:0 0 100px;font-size:11px;direction:ltr">${fp(p)} ${tag}</span><div style="flex:1;height:8px;background:#182438;border-radius:4px"><div style="width:${vp.v[i]/mx*100}%;height:100%;background:linear-gradient(90deg,#79aaff,#35d6a0);border-radius:4px"></div></div></div>`}$('vpBox').innerHTML=h}

  // Books
  const bk=D.books;
  const wl=(arr,c)=>arr.map(w=>`<tr><td class="${c}">${fp(w.p)}</td><td>${fmt(w.q,3)}</td><td>${fmt(w.v,0)}</td></tr>`).join('')||'<tr><td colspan=3 class="muted">دیواری نیست</td></tr>';
  const tbl=(h,body)=>`<table><thead><tr><th>${h[0]}</th><th>${h[1]}</th><th>${h[2]}</th></tr></thead><tbody>${body}</tbody></table>`;
  $('books').innerHTML=`<div class="grid">${M('Spot Bid/Ask',bk.spot?pc(bk.spot.imb*100):'—',tone(bk.spot?.imb))}${M('Futures Bid/Ask',bk.fut?pc(bk.fut.imb*100):'—',tone(bk.fut?.imb))}${M('Spread Spot',bk.spot?fp(bk.spot.spread):'—')}</div>
   <div class="row" style="align-items:flex-start;margin-top:8px"><div style="flex:1 1 280px"><h3>Spot Bid</h3>${tbl(['قیمت','مقدار','ارزش'],bk.spot?wl(bk.spot.bidWalls,'good'):'')}</div><div style="flex:1 1 280px"><h3>Spot Ask</h3>${tbl(['قیمت','مقدار','ارزش'],bk.spot?wl(bk.spot.askWalls,'bad'):'')}</div></div>
   <div class="row" style="align-items:flex-start;margin-top:8px"><div style="flex:1 1 280px"><h3>Futures Bid</h3>${tbl(['قیمت','مقدار','ارزش'],bk.fut?wl(bk.fut.bidWalls,'good'):'')}</div><div style="flex:1 1 280px"><h3>Futures Ask</h3>${tbl(['قیمت','مقدار','ارزش'],bk.fut?wl(bk.fut.askWalls,'bad'):'')}</div></div>`;

  // Liquidation
  $('liqBox').innerHTML=`<div id="liveLiq" class="muted"></div><div class="scroll"><table><thead><tr><th>قیمت</th><th>فاصله</th><th>لانگ تخمینی</th><th>شورت تخمینی</th></tr></thead><tbody>${D.liq.map(b=>`<tr><td>${fp(b.p)}</td><td class="${b.p<D.spot?'bad':'good'}">${pc((b.p-D.spot)/D.spot*100)}</td><td>${fmt(b.long,0)}</td><td>${fmt(b.short,0)}</td></tr>`).join('')||'<tr><td colspan=4>داده کافی نیست</td></tr>'}</tbody></table></div>`;

  // Options
  const op=D.options;
  $('optBox').innerHTML=op?[M('Call OI',fmt(op.callOI,0)),M('Put OI',fmt(op.putOI,0)),M('Put/Call OI',fmt(op.pcr,3),op.pcr>1?'good':op.pcr<0.7?'bad':''),M('Max Pain',fp(op.maxPain)+' ('+(op.nearest||'—')+')'),M('IV میانگین',op.ivAvg==null?'—':fmt(op.ivAvg,1)+'%'),M('فاصله از Max Pain',op.maxPain?pc((D.spot-op.maxPain)/op.maxPain*100):'—'),M('سررسیدهای اصلی',op.topExp.map(e=>e.key).join(' · ')||'—')].join(''):'<span class="muted">فقط BTC/ETH یا گزینه Options خاموش است.</span>';

  // Return stats & seasonality
  const rs=retStats(D.candles['1day']||[]);
  $('retBox').innerHTML=rs?[M('تعداد بازده روزانه',rs.n),M('میانگین روزانه',pc(rs.mean*100,3),tone(rs.mean)),M('نوسان سالانه',pc(rs.ann*100,1)),M('VaR 95% روزانه',pc(rs.var95*100,2),'bad'),M('VaR 99% روزانه',pc(rs.var99*100,2),'bad'),M('Max Drawdown',pc(rs.mdd*100,2),'bad'),M('Sortino (سالانه)',fmt(rs.sortino,2)),M('چولگی / کشیدگی',fmt(rs.skew,2)+' / '+fmt(rs.kurt,2)),M('بهترین / بدترین روز',pc(rs.best*100)+' / '+pc(rs.worst*100)),M('درصد روزهای مثبت',fmt(rs.pos*100,1)+'%')].join(''):'<span class="muted">داده روزانه کافی نیست.</span>';
  const se=seasonality(D.candles['1hour']||mainC,D.candles['1day']||[]);
  $('hourTbl').innerHTML='<thead><tr><th>ساعت UTC</th><th>میانگین بازده</th><th>تعداد</th></tr></thead><tbody>'+se.hour.map((v,h)=>`<tr><td>${String(h).padStart(2,'0')}:00</td><td class="${tone(v)}">${v==null?'—':pc(v*100,3)}</td><td>${se.hourN[h]}</td></tr>`).join('')+'</tbody>';
  const WD=['یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه','شنبه'];
  $('wdayTbl').innerHTML='<thead><tr><th>روز</th><th>میانگین بازده</th><th>تعداد</th></tr></thead><tbody>'+se.wday.map((v,i)=>`<tr><td>${WD[i]}</td><td class="${tone(v)}">${v==null?'—':pc(v*100,3)}</td><td>${se.wdayN[i]}</td></tr>`).join('')+'</tbody>';
  const ss=sessionShare((D.candles['1hour']||[]).slice(-500));
  $('sessBox').innerHTML=ss?Object.entries({Asia:'آسیا (0-7)',Europe:'اروپا (7-13)',US:'آمریکا (13-21)',Late:'انتهای روز (21-24)'}).map(([k,l])=>M(l,fmt(ss[k]*100,1)+'%')).join(''):'<span class="muted">داده 1h کافی نیست</span>';

  // Macro
  $('macroTbl').innerHTML='<thead><tr><th>شاخص</th><th>آخرین</th><th>۱روزه</th><th>۵روزه</th><th>همبستگی با BTC</th><th>β BTC نسبت به شاخص</th></tr></thead><tbody>'+
    (D.macro.map(mm=>mm.err?`<tr><td>${mm.name}</td><td colspan=5 class="muted">${esc(mm.err)}</td></tr>`:`<tr><td>${mm.name}</td><td>${fmt(mm.last,2)}</td><td class="${tone(mm.c1)}">${pc(mm.c1*100)}</td><td class="${tone(mm.c5)}">${pc(mm.c5*100)}</td><td>${fmt(mm.corr,3)} <span class="muted">(n=${mm.n})</span></td><td>${fmt(mm.beta,3)}</td></tr>`).join('')||'<tr><td colspan=6>داده ماکرو نیست</td></tr>')+'</tbody>';

  // Sentiment & onchain
  const fg=D.fng?.[0];
  $('sentBox').innerHTML=fg?[M('Fear & Greed',fg.value,Number(fg.value)<25?'bad':Number(fg.value)>75?'good':'warn'),M('برچسب',esc(fg.value_classification)),M('میانگین ۳۰ روز',fmt(mean(D.fng.map(z=>Number(z.value))),1)),M('تغییر نسبت به دیروز',D.fng[1]?(Number(fg.value)-Number(D.fng[1].value)).toFixed(0):'—')].join(''):M('F&G','در دسترس نیست');
  $('onchainBox').innerHTML=D.onchain.length?D.onchain.map(o=>M(o.key,fmt(o.last,2)+' <span class="'+tone(o.chg)+'">'+pc(o.chg*100)+'</span>')).join(''):'<span class="muted">فقط برای BTC</span>';

  renderNews();renderEvents();
  $('newsErr').textContent=D.newsErrors.length?'خطای منابع: '+D.newsErrors.join(' | '):'';
  $('evErr').textContent=D.eventErrors.length?'خطای تقویم: '+D.eventErrors.join(' | '):'';

  $('chartTF').innerHTML=tfsOK.map(t=>`<option value="${t}" ${t===D.mainTF?'selected':''}>${t}</option>`).join('');
  drawChart();
  renderLive();
  $('oiHist').innerHTML=M('OI KuCoin',fmt(D.oi.kc,2))+M('OI Binance',fmt(D.oi.bin,2))+M('OI Bybit',fmt(D.oi.byb,2))+M('OI OKX',fmt(D.oi.okx,2));
  loadOIHist(D);
}
function renderNews(){
  const D=S.data;if(!D)return;const q=$('newsQ').value.trim().toLowerCase(),src=$('newsSrc').value;
  const srcs=[...new Set(D.news.map(n=>n.source))];
  if($('newsSrc').options.length<=1)$('newsSrc').innerHTML='<option value="">همه منابع</option>'+srcs.map(s=>`<option>${esc(s)}</option>`).join('');
  const list=D.news.filter(n=>(!q||(n.title+' '+n.summary).toLowerCase().includes(q))&&(!src||n.source===src));
  $('newsBox').innerHTML=list.length?list.map(n=>`<div class="box"><b>${esc(n.title)}</b><div class="muted">${esc(n.source)} · ${n.ts?iso(Math.floor(n.ts)):esc(n.date)} UTC</div><div class="muted">${esc(n.summary)}</div><a href="${/^https:\/\//.test(n.link)?esc(n.link):'#'}" target="_blank" rel="noopener noreferrer" style="color:#79aaff">باز کردن خبر</a></div>`).join(''):'<span class="muted">خبری پیدا نشد.</span>';
}
function renderEvents(){
  const D=S.data;if(!D)return;const f=$('evImpact').value;
  const list=D.events.filter(e=>!f||e.impact===f).sort((a,b)=>String(a.date).localeCompare(String(b.date)));
  $('evBox').innerHTML=list.length?'<table><thead><tr><th>زمان (UTC)</th><th>رویداد</th><th>کشور</th><th>اهمیت</th><th>پیش‌بینی</th><th>قبلی</th></tr></thead><tbody>'+list.map(e=>`<tr><td>${esc(String(e.date).replace('T',' ').slice(0,16))}</td><td style="white-space:normal">${esc(e.title)}</td><td>${esc(e.country)}</td><td class="${e.impact==='High'?'bad':e.impact==='Medium'?'warn':''}">${esc(e.impact)}</td><td>${esc(e.forecast)}</td><td>${esc(e.previous)}</td></tr>`).join('')+'</tbody></table>':'<span class="muted">رویدادی نیست.</span>';
}
async function loadOIHist(D){
  try{const j=await lj('/oi_history?symbol='+encodeURIComponent('KC:'+D.kcFut)+'&hours=72');const h=j.history||[];
    const cur=D.oi.kc;const old=h.find(x=>x.ts<=Date.now()/1000-23*3600)||h[0];
    $('oiHist').innerHTML+=M('نمونه‌های ذخیره‌شده',h.length)+M('تغییر OI از نمونه قدیمی',old&&cur?pc((cur-old.oi)/old.oi*100):'—')}catch(e){}
}

// ---------- Chart ----------
function drawChart(){
  const D=S.data;if(!D)return;const tf=$('chartTF').value;const all=D.candles[tf]||[];const n=+$('chartN').value;const c=n>0?all.slice(-n):all;if(!c.length)return;
  const cv=$('chart'),dpr=window.devicePixelRatio||1;cv.width=cv.clientWidth*dpr;cv.height=cv.clientHeight*dpr;
  const g=cv.getContext('2d');g.setTransform(dpr,0,0,dpr,0,0);const w=cv.clientWidth,h=cv.clientHeight;
  g.fillStyle='#091423';g.fillRect(0,0,w,h);
  const pL=6,pR=64,pT=8,pH=h*0.74,vT=pH+10,vH=h-vT-4;
  let mn=Infinity,mx=-Infinity;for(const x of c){if(x.low<mn)mn=x.low;if(x.high>mx)mx=x.high}
  const rng=(mx-mn)||1,cw=(w-pL-pR)/c.length,X=i=>pL+(i+0.5)*cw,Y=v=>pT+(mx-v)/rng*(pH-pT),bw=Math.max(1,cw*0.7);
  g.strokeStyle='#1e2d45';g.fillStyle='#8ea1bd';g.font='10px Tahoma';
  for(let k=0;k<=4;k++){const v=mn+rng*k/4,y=Y(v);g.beginPath();g.moveTo(pL,y);g.lineTo(w-pR,y);g.stroke();g.fillText(v.toPrecision(6),w-pR+3,y+3)}
  const vmax=Math.max(...c.map(x=>x.volume||0))||1;
  c.forEach((x,i)=>{g.fillStyle=x.close>=x.open?'rgba(53,214,160,.35)':'rgba(255,119,136,.35)';const hh=(x.volume||0)/vmax*vH;g.fillRect(X(i)-bw/2,h-4-hh,bw,hh)});
  const line=(key,col,lw=1,dash=[])=>{g.beginPath();g.strokeStyle=col;g.lineWidth=lw;g.setLineDash(dash);let st=false;c.forEach((x,i)=>{const v=x[key];if(v==null||!Number.isFinite(v)){st=false;return}if(!st){g.moveTo(X(i),Y(v));st=true}else g.lineTo(X(i),Y(v))});g.stroke();g.setLineDash([]);g.lineWidth=1};
  if($('ovBB').checked){line('bbU','#4a5a7a');line('bbL','#4a5a7a')}
  if($('ovKC').checked){line('kcU','#3c7a6a',1,[3,3]);line('kcL','#3c7a6a',1,[3,3])}
  if($('ovEMA').checked){line('ema20','#79aaff');line('ema50','#f2dca7');line('ema200','#ff9d4d',1.4)}
  if($('ovHMA').checked)line('hma','#ffd34d',1.4);
  if($('ovST').checked)line('stLine','#b18aff',1.6);
  if($('ovVWAP').checked)line('vwap','#ffffff',1,[4,3]);
  if($('ovICH').checked){line('ichA','rgba(53,214,160,.7)');line('ichB','rgba(255,119,136,.7)')}
  c.forEach((x,i)=>{const col=x.close>=x.open?'#35d6a0':'#ff7788';g.strokeStyle=col;g.fillStyle=col;const xi=X(i);g.beginPath();g.moveTo(xi,Y(x.high));g.lineTo(xi,Y(x.low));g.stroke();const t=Y(Math.max(x.open,x.close)),b=Y(Math.min(x.open,x.close));g.fillRect(xi-bw/2,t,bw,Math.max(1,b-t))});
  const vp=volProfile(c,40);if(vp){g.strokeStyle='rgba(242,220,167,.7)';g.setLineDash([6,4]);const y=Y(vp.pocPrice);g.beginPath();g.moveTo(pL,y);g.lineTo(w-pR,y);g.stroke();g.setLineDash([]);g.fillStyle='#f2dca7';g.fillText('POC',pL+2,y-3)}
  if($('ovFIB').checked&&D.fibTF===tf){}
  const fb=fib(c);if($('ovFIB').checked&&fb){g.setLineDash([2,3]);g.strokeStyle='rgba(177,138,255,.8)';for(const l of fb.levels){const y=Y(l.p);g.beginPath();g.moveTo(pL,y);g.lineTo(w-pR,y);g.stroke();g.fillStyle='#b18aff';g.fillText(l.r,w-pR+3,y-2)}g.setLineDash([])}
  const last=c.at(-1);g.fillStyle='#eaf1ff';g.fillText(fp(last.close),w-pR+3,Y(last.close)+3);
}

// ---------- Live ----------
function stopLive(){if(S.live.ws){try{S.live.ws.close()}catch(e){}S.live.ws=null}if(S.live.timer){clearInterval(S.live.timer);S.live.timer=null}}
function setLiveMsg(t){$('liveMsg').textContent=t}
function startLive(D){
  stopLive();S.live.trades=[];S.live.liq=[];S.live.last=null;S.live.prev=null;
  if(!$('incLive').checked){setLiveMsg('خاموش است.');return}
  const f=D.bPair.toLowerCase();
  try{
    const ws=new WebSocket(`wss://fstream.binance.com/stream?streams=${f}@aggTrade/${f}@forceOrder`);S.live.ws=ws;
    ws.onmessage=e=>{const m=JSON.parse(e.data),d=m.data||{};
      if(m.stream.endsWith('@aggTrade')){S.live.prev=S.live.last;S.live.last=+d.p;S.live.trades.push({t:Date.now(),v:(+d.p)*(+d.q),buy:!d.m});if(S.live.trades.length>4000)S.live.trades.splice(0,1000);checkAlerts()}
      else if(m.stream.endsWith('@forceOrder')){const o=d.o;S.live.liq.push({t:Date.now(),side:o.S,v:(+o.ap||+o.p)*(+o.q)});if(S.live.liq.length>800)S.live.liq.splice(0,200)}};
    ws.onopen=()=>setLiveMsg('اتصال زنده Binance USDⓈ-M برقرار شد.');
    ws.onerror=()=>setLiveMsg('WebSocket خطا داد (شبکه شما ممکن است مسدود باشد).');
    ws.onclose=()=>setLiveMsg('اتصال زنده بسته شد.');
  }catch(e){setLiveMsg('WebSocket در دسترس نیست: '+e.message)}
  S.live.timer=setInterval(renderLive,1000);
}
function checkAlerts(){
  const {last,prev}=S.live;if(prev==null||last==null)return;
  for(const lv of S.alerts){if((prev-lv)*(last-lv)<0){banner(`عبور قیمت از ${fp(lv)} (الان ${fp(last)})`)}}
}
function renderLive(){
  const now=Date.now(),t1=now-60000,t5=now-300000,h1=now-3600000;
  const d=from=>{let b=0,s=0;for(const x of S.live.trades){if(x.t<from)continue;if(x.buy)b+=x.v;else s+=x.v}return{b,s,delta:(b+s)?(b-s)/(b+s)*100:null}};
  const d1=d(t1),d5=d(t5);
  const lq=S.live.liq.filter(x=>x.t>=h1);const longL=lq.filter(x=>x.side==='SELL').reduce((a,b)=>a+b.v,0),shortL=lq.filter(x=>x.side==='BUY').reduce((a,b)=>a+b.v,0);
  $('liveBox').innerHTML=M('Delta 60s',d1.delta==null?'—':fmt(d1.delta,2)+'%',tone(d1.delta))+M('Delta 5m',d5.delta==null?'—':fmt(d5.delta,2)+'%',tone(d5.delta))+M('خرید تهاجمی 60s',fmt(d1.b,0))+M('فروش تهاجمی 60s',fmt(d1.s,0))+
    M('لیکوئید لانگ (۱h)',fmt(longL,0),longL?'bad':'')+M('لیکوئید شورت (۱h)',fmt(shortL,0),shortL?'good':'')+M('تعداد لیکوئید (۱h)',lq.length)+M('قیمت زنده',fp(S.live.last));
  const el=$('liveLiq');if(el)el.textContent=`لیکوئید زنده (۱ساعت): لانگ ${fmt(longL,0)} · شورت ${fmt(shortL,0)} USDT`;
}

// ---------- Export (فشرده، بدون حذف داده) ----------
function colCandles(c){const cols=c.length?Object.keys(c[0]):[];return {cols,rows:c.map(x=>cols.map(k=>x[k]===undefined?null:x[k]))}}
function buildBundle(D){
  const candles={};for(const t of D.tfs)if(D.candles[t]?.length)candles[t]=colCandles(D.candles[t]);
  const data={};for(const [k,v] of Object.entries(D)){if(k==='candles')continue;data[k]=v}
  data.summary={confluence:confluence(D),generated:new Date().toISOString()};
  return {v:VERSION_TAG,schema:'candles[tf] = {cols,rows}: rows[i][j] ↔ cols[j]',candles,data};
}
const VERSION_TAG='12.1';
S.ai={text:null,signal:null};
S.demoTimer=null;S.demoSettings={};
function csvEsc(v){const s=v==null?'':String(v);return /[",\n\r]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s}
function buildCandlesCSV(D){
  const keys=new Set();for(const t of D.tfs)for(const c of (D.candles[t]||[]).slice(0,1))Object.keys(c).forEach(k=>keys.add(k));
  const cols=['tf','utc',...[...keys]];const rows=[cols.join(',')];
  for(const t of D.tfs)for(const c of D.candles[t]||[])rows.push([t,new Date(c.time*1000).toISOString(),...cols.slice(2).map(k=>csvEsc(c[k]))].join(','));
  return '\ufeff'+rows.join('\n');
}
function buildSummaryCSV(D){
  const rows=[['section','key','value']];const cf=confluence(D);
  rows.push(['meta','symbol',D.symbol],['meta','futSymbol',D.kcFut],['meta','mode',D.mode],['meta','generated',D.ts]);
  if(cf){rows.push(['confluence','score',cf.score],['confluence','label',cf.label],['confluence','confidence',cf.conf]);for(const s of cf.sig)rows.push(['signal',s.name,s.v.toFixed(3)+' (w='+s.w+') '+(s.det||'')])}
  if(D.market)for(const [k,v] of Object.entries(D.market))if(typeof v!=='object')rows.push(['market',k,v]);
  rows.push(['basis','spot',D.spot],['basis','fut',D.fut],['basis','pct',D.basisPct]);
  for(const [k,v] of Object.entries(D.oi))rows.push(['oi',k,v]);
  for(const [k,v] of Object.entries(D.oi24))rows.push(['oi24h',k,v]);
  if(D.options)for(const [k,v] of Object.entries(D.options))if(typeof v!=='object')rows.push(['options',k,v]);
  for(const mm of D.macro)rows.push(['macro',mm.name,JSON.stringify(mm)]);
  for(const o of D.onchain)rows.push(['onchain',o.key,o.last]);
  for(const [k,v] of Object.entries(D.errors))rows.push(['errors',k,v]);
  return '\ufeff'+rows.map(r=>r.map(csvEsc).join(',')).join('\n');
}
async function gzipBlob(text){
  const r=await fetch('/gzip',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({content:text})});
  if(!r.ok)throw new Error('gzip HTTP '+r.status);return r.blob();
}
function download(name,blob){
  const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();
  setTimeout(()=>{a.remove();URL.revokeObjectURL(url)},4000);
}
async function saveServer(name,text,gz){
  const r=await fetch('/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({filename:name,content:text,gzip:gz})});
  const j=await r.json();if(!j.ok)throw new Error(j.error||'خطا');return j;
}
function need(){if(!S.data){banner('اول تحلیل بگیر.');throw new Error('no data')}}
function stamp(){return S.data.symbol.replace('-','_')+'_'+new Date().toISOString().replace(/[:.]/g,'-').slice(0,19)}
function kb(n){return (n/1024).toFixed(1)+' KB'}

$('runBtn').addEventListener('click',async()=>{
  const btn=$('runBtn');btn.disabled=true;prog(2);
  try{
    const D=await fetchAll();S.data=D;renderAll(D);
    const cnt=Object.entries(D.candles).map(([k,v])=>`${k}:${v.length}`).join(' | ');
    const errs=Object.entries(D.errors).map(([k,v])=>`• ${k}: ${v}`).join('\n');
    status(`✅ تحلیل کامل شد.\nکندل‌ها → ${cnt}\nTrades اسپات: ${D.trades.spot.length} | فیوچرز: ${D.trades.fut.length} | خوشه‌های لیکوئید: ${D.liq.length}\nاخبار: ${D.news.length} | رویداد: ${D.events.length}\n${errs?'\n⚠️ منابع با خطا:\n'+errs:'\nهمه منابع بدون خطا.'}`);
    S.alerts=($('alerts').value||'').split(/[,،\s]+/).map(Number).filter(v=>v>0);
    startLive(D);
    const jsonText=JSON.stringify(buildBundle(D));
    $('sizeInfo').textContent=`حجم JSON خام: ${kb(jsonText.length)} (قبل از gzip). فایل gzip معمولاً خیلی کوچک‌تر است.`;
    $('aiBtn').disabled=false;$('aiBtn2').disabled=false;
    $('aiStatus').textContent='آماده برای خوانش APEX. دکمه را بزن.';
  }catch(e){status('❌ خطا: '+e.message);prog(0)}
  finally{btn.disabled=false}
});
$('stopBtn').addEventListener('click',()=>{S.abort=true;stopLive();status('متوقف شد.')});
$('dlJsonGz').addEventListener('click',async()=>{try{need();const blob=await gzipBlob(JSON.stringify(buildBundle(S.data)));download(stamp()+'.json.gz',blob);$('sizeInfo').textContent=`JSON فشرده: ${kb(blob.size)}`;banner('ارسال شد')}catch(e){banner('خطا: '+e.message)}});
$('dlCsvGz').addEventListener('click',async()=>{try{need();const blob=await gzipBlob(buildCandlesCSV(S.data));download(stamp()+'_candles.csv.gz',blob);$('sizeInfo').textContent=`CSV فشرده: ${kb(blob.size)}`;banner('ارسال شد')}catch(e){banner('خطا: '+e.message)}});
$('dlSum').addEventListener('click',()=>{try{need();download(stamp()+'_summary.csv',new Blob([buildSummaryCSV(S.data)],{type:'text/csv;charset=utf-8'}));banner('CSV خلاصه ارسال شد')}catch(e){}});
$('saveJsonGz').addEventListener('click',async()=>{try{need();const j=await saveServer(stamp()+'.json',JSON.stringify(buildBundle(S.data)),true);status('✅ ذخیره شد:\n'+j.path+'\nاندازه: '+kb(j.size));banner('ذخیره شد ✓')}catch(e){status('❌ '+e.message);banner('خطا')}});
$('saveCsvGz').addEventListener('click',async()=>{try{need();const j=await saveServer(stamp()+'_candles.csv',buildCandlesCSV(S.data),true);status('✅ CSV فشرده ذخیره شد:\n'+j.path+'\nاندازه: '+kb(j.size));banner('ذخیره شد ✓')}catch(e){status('❌ '+e.message);banner('خطا')}});
$('copyBtn').addEventListener('click',async()=>{try{need();await navigator.clipboard.writeText(buildSummaryCSV(S.data));banner('کپی شد ✓')}catch(e){banner('کپی ناموفق')}});
$('rBtn').addEventListener('click',()=>{
  const cap=+$('rCap').value,risk=+$('rPct').value/100,en=+$('rEntry').value,sp=+$('rStop').value;
  if(!(cap>0&&risk>0&&en>0&&sp>0)||en===sp){$('riskBox').textContent='ورودی‌ها را درست پر کن.';return}
  const dist=Math.abs(en-sp),amt=cap*risk,qty=amt/dist;
  $('riskBox').innerHTML=`ریسک: ${fmt(amt,2)} USDT · فاصله تا حد ضرر: ${fp(dist)} (${fmt(dist/en*100,2)}%)<br>حجم پیشنهادی: ${fmt(qty,6)} واحد · ارزش موقعیت: ${fmt(qty*en,2)} USDT<br><span class="muted">این ماشین‌حساب آموزشی است و توصیه معاملاتی نیست.</span>`;
});
$('alertBtn').addEventListener('click',()=>{S.alerts=($('alerts').value||'').split(/[,،\s]+/).map(Number).filter(v=>v>0);$('alertBox').textContent=S.alerts.length?'هشدار فعال: '+S.alerts.map(v=>fp(v)).join(' · '):'سطحی ثبت نشد.'});
$('newsQ').addEventListener('input',renderNews);$('newsSrc').addEventListener('change',renderNews);
$('evImpact').addEventListener('change',renderEvents);
$('chartTF').addEventListener('change',drawChart);$('chartN').addEventListener('change',drawChart);
['ovEMA','ovHMA','ovBB','ovKC','ovST','ovVWAP','ovICH','ovFIB'].forEach(id=>$(id).addEventListener('change',drawChart));
window.addEventListener('resize',drawChart);

// ==================== Tabs + APEX AI + Demo Trading Pro ====================
function switchTab(name){
  document.querySelectorAll('.tab-panel').forEach(p=>p.classList.remove('active'));
  document.querySelectorAll('#bottomNav button').forEach(b=>b.classList.remove('active'));
  const panel=$('tab-'+name);if(panel)panel.classList.add('active');
  const btn=document.querySelector('#bottomNav button[data-tab="'+name+'"]');if(btn)btn.classList.add('active');
  window.scrollTo({top:0,behavior:'smooth'});
  if(name==='trade'){refreshDemo();startDemoMonitor()}
  if(name==='home'||name==='trade')drawChart&&S.data&&drawChart();
}
document.querySelectorAll('#bottomNav button').forEach(b=>b.addEventListener('click',()=>switchTab(b.dataset.tab)));

function updateTopbar(){
  const D=S.data;const px=S.live?.last||D?.spot;
  if($('topSym'))$('topSym').textContent=D?.symbol||'—';
  if($('topPrice')&&px!=null){$('topPrice').textContent=fp(px);$('topPrice').className='price-live '+(S.live?.prev&&px>S.live.prev?'good':S.live?.prev&&px<S.live.prev?'bad':'')}
  if($('topChg')&&D?.market){const c=N(D.market.changeRate);$('topChg').textContent=c==null?'—':pc(c*100);$('topChg').style.color=c>0?'var(--green)':c<0?'var(--red)':''}
  if($('xSym'))$('xSym').textContent=D?.symbol||'—';
  if($('xPrice')&&px!=null)$('xPrice').textContent=fp(px);
  if($('xChg')&&D?.market)$('xChg').textContent='۲۴h '+pc(N(D.market.changeRate)*100);
  if($('xFund')&&D?.funding){const f=N(D.funding.bin?.lastFundingRate??D.funding.kc?.value);$('xFund').textContent=f==null?'Fund —':'Fund '+(f*100).toFixed(4)+'%'}
  if($('xOi')&&D?.oi)$('xOi').textContent='OI '+fmt(D.oi.bin||D.oi.kc,0);
  if($('xTick'))$('xTick').textContent='⏱ '+new Date().toISOString().slice(11,19);
}


function buildAiPayload(D){
  const mainTF=D.mainTF, c=D.candles[mainTF]||[];
  const last=c.at(-1)||{};
  const cf=confluence(D);
  const st=structure(c), pt=patterns(c), fb=fib(c);
  const recent=c.slice(-40).map(x=>+x.close.toFixed(6));
  const cvd={};
  for(const t of D.tfs){const cs=D.candles[t];if(!cs)continue;cvd[t]={spot:cvdScore(cs.map(y=>y.cvdS)),fut:cvdScore(cs.map(y=>y.cvdF))};}
  let b=0,br=0;
  for(const t of D.tfs){const y=D.candles[t]?.at(-1);if(!y||y.ema20==null)continue;if(y.ema20>y.ema50&&y.stDir===1)b++;else if(y.ema20<y.ema50&&y.stDir===-1)br++;}
  const mtfTxt=b+' صعودی / '+br+' نزولی از '+D.tfs.length;
  const levels={};
  if(last.vwap)levels.vwap=last.vwap;if(last.stLine)levels.st=last.stLine;if(last.bbU){levels.bbU=last.bbU;levels.bbL=last.bbL;}
  if(last.dcU){levels.dcU=last.dcU;levels.dcL=last.dcL;}
  const vp=volProfile(c.slice(-300));if(vp){levels.poc=vp.pocPrice;levels.vah=vp.vah;levels.val=vp.val;}
  const funding={};
  if(D.funding){funding.kc=D.funding.kc?.value;funding.bin=D.funding.bin?.lastFundingRate;funding.byb=D.funding.byb?.fundingRate;funding.okx=D.funding.okx?.fundingRate;}
  return {
    symbol:D.symbol,kcFut:D.kcFut,mainTF,tradeTF:mainTF,spot:D.spot,fut:D.fut,basisPct:D.basisPct,
    market:D.market,confluence:cf,mainCandle:last,structure:st.txt,patterns:pt.join(' · '),
    levels,fib:fb,funding,oi:D.oi,oi24:D.oi24,positioning:D.positioning,options:D.options,
    cvd,mtf:mtfTxt,divergences:(divergences(c)||[]).map(d=>d.text).join(' · '),
    books:{spotImb:D.books?.spot?.imb,futImb:D.books?.fut?.imb,spread:D.books?.spot?.spread,
      bidWall:D.books?.spot?.bidWalls?.[0],askWall:D.books?.spot?.askWalls?.[0]},
    liq:(D.liq||[]).slice(0,10),macro:D.macro,fng:D.fng?.[0],onchain:D.onchain,
    recentCloses:recent,newsHeadlines:(D.news||[]).slice(0,8).map(n=>n.title)
  };
}

async function runApex(){
  need();
  const btns=[$('aiBtn'),$('aiBtn2')];btns.forEach(b=>{if(b)b.disabled=true});
  $('aiStatus').textContent='در حال ارسال داده به APEX (Gemini)… ۳۰–۹۰ ثانیه.';
  $('aiOut').style.display='none';$('aiSig').style.display='none';
  try{
    const payload=buildAiPayload(S.data);
    const r=await fetch('/ai_signal',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const j=await r.json();
    if(!j.ok)throw new Error(j.error||'خطای AI');
    S.ai={text:j.text,signal:j.signal};
    if($('aiOut')){$('aiOut').style.display='block';$('aiOut').textContent=j.text}
    if($('aiArchive'))$('aiArchive').textContent=j.text;
    if($('aiSig'))$('aiSig').style.display='block';
    const s=j.signal||{};
    const sigTxt='══════════════════════════════════\n SIGNAL — '+(S.data&&S.data.symbol||'')+'\n══════════════════════════════════\n Side: '+(s.side||'—')+'\n Entry: '+(s.entry||'—')+'\n TP1: '+(s.tp1||'—')+'   TP2: '+(s.tp2||'—')+'   TP3: '+(s.tp3||'—')+'\n SL: '+(s.sl||'—')+'\n Leverage: '+(s.leverage||'—')+'x   Size: '+(s.size_pct||'—')+'%\n Conviction: '+(s.conviction||'—')+'/10   R:R: '+(s.rr||'—')+'\n Style: '+(s.style||'—')+'\n Horizon: '+(s.horizon||'—')+'\n══════════════════════════════════';
    if($('aiSig'))$('aiSig').textContent=sigTxt;
    $('aiStatus').textContent='خوانش کامل شد · '+new Date().toLocaleTimeString('fa-IR');
    if($('aiOpenDemo'))$('aiOpenDemo').disabled=!(s.side&&s.entry);
    if($('aiCopy'))$('aiCopy').disabled=false;
    switchTab('home');
    banner('APEX آماده است');
    const auto=($('ds_auto_trade')&&$('ds_auto_trade').value||S.demoSettings&&S.demoSettings.auto_trade||'1')==='1';
    if(auto&&s.side&&(s.entry||S.data&&S.data.spot)){
      $('aiStatus').textContent='خوانش کامل · باز کردن خودکار معامله…';
      await openDemoFromSignal(true);
      switchTab('trade');
    }
  }catch(e){
    $('aiStatus').textContent='❌ خطا: '+e.message;
    banner('خطای AI');
  }finally{btns.forEach(b=>{if(b)b.disabled=false})}
}
if($('aiBtn'))$('aiBtn').addEventListener('click',runApex);
if($('aiBtn2'))$('aiBtn2').addEventListener('click',runApex);
if($('aiCopy'))$('aiCopy').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(S.ai?.text||'');banner('کپی شد')}catch(e){banner('کپی ناموفق')}});

async function openDemoFromSignal(isAuto){
  const s=S.ai&&S.ai.signal;if(!s||!s.side){banner('سیگنال ناقص است');return}
  if(!S.data){banner('اول تحلیل بازار را اجرا کن');return}
  const live=S.live&&S.live.last||S.data.spot||s.entry||s.fill;
  if(!live&&!s.entry){banner('قیمت ورود در دسترس نیست');return}
  const settings=S.demoSettings||{};
  const sizeMode=settings.size_mode||($('ds_size_mode')&&$('ds_size_mode').value)||'signal';
  // Prefer live market price for fill accuracy; keep signal entry as reference in notes
  let entry=live||s.entry||s.fill;
  let tp1=s.tp1,tp2=s.tp2,tp3=s.tp3,sl=s.sl;
  // If SL/TP missing, synthesize reasonable levels from ATR-ish 1% steps
  const side=s.side;
  if(!sl){
    sl=side==='LONG'?entry*0.985:entry*1.015;
  }
  if(!tp1){tp1=side==='LONG'?entry*1.01:entry*0.99}
  if(!tp2){tp2=side==='LONG'?entry*1.02:entry*0.98}
  if(!tp3){tp3=side==='LONG'?entry*1.035:entry*0.965}
  const lev=Math.min(+(s.leverage||settings.default_leverage||5), +(settings.max_leverage||20));
  const body={
    symbol:S.data.symbol,side:side,entry:entry,
    leverage:lev,
    size_pct:s.size_pct||5,
    tp1:tp1,tp2:tp2,tp3:tp3,sl:sl,
    conviction:s.conviction||5,horizon:s.horizon||'',
    notes:(isAuto?'[AUTO] ':'')+'signalEntry='+(s.entry||'—')+' | '+(S.ai.text||'').slice(0,280),
    source:isAuto?'apex_auto':'apex_manual',
    trail_dist: settings.trail_after_tp1==='1' ? Math.abs((tp1||entry)-entry)*0.5 : 0
  };
  if(sizeMode==='risk'|| (settings.size_mode==='risk')){
    body.risk_pct=+(settings.max_risk_pct||5);
  } else if(sizeMode==='fixed'){
    body.size_pct=+(settings.max_risk_pct||5);
  }

    try{
    const r=await fetch('/demo/open',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    const j=await r.json();
    if(!j.ok)throw new Error(j.error||'باز نشد');
    banner((isAuto?'خودکار · ':'')+s.side+' @ '+fp(j.entry)+' · مارجین '+fmt(j.margin,2)+'$ · Liq '+fp(j.liq_price));
    logDemoEvent('OPEN '+s.side+' id='+j.id+' entry='+fp(j.entry)+' lev='+body.leverage+' fee='+fmt(j.fee,4));
    await refreshDemo();
    startDemoMonitor();
  }catch(e){banner('خطا: '+e.message);logDemoEvent('OPEN FAIL: '+e.message)}
}
if($('aiOpenDemo'))$('aiOpenDemo').addEventListener('click',()=>openDemoFromSignal(false));

function logDemoEvent(msg){
  const el=$('demoEvents');if(!el)return;
  const t=new Date().toISOString().slice(11,19);
  el.textContent='['+t+'] '+msg+'\n'+(el.textContent||'');
}

function applySettingsToForm(st){
  if(!st)return;
  S.demoSettings=st;
  const map={auto_trade:'ds_auto_trade',default_leverage:'ds_default_leverage',max_leverage:'ds_max_leverage',
    max_risk_pct:'ds_max_risk_pct',max_margin_pct:'ds_max_margin_pct',max_positions:'ds_max_positions',
    fee_rate:'ds_fee_rate',slippage_bps:'ds_slippage_bps',tp1_pct:'ds_tp1_pct',tp2_pct:'ds_tp2_pct',tp3_pct:'ds_tp3_pct',
    move_be_after_tp1:'ds_move_be_after_tp1',trail_after_tp1:'ds_trail_after_tp1',tick_ms:'ds_tick_ms',size_mode:'ds_size_mode',
    min_conviction:'ds_min_conviction',daily_loss_limit_pct:'ds_daily_loss_limit_pct',max_dd_halt_pct:'ds_max_dd_halt_pct',
    ai_require_sl:'ds_ai_require_sl'};
  for(const [k,id] of Object.entries(map)){const el=$(id);if(el&&st[k]!=null)el.value=st[k]}
}

function collectSettingsFromForm(){
  const ids=['auto_trade','default_leverage','max_leverage','max_risk_pct','max_margin_pct','max_positions',
    'fee_rate','slippage_bps','tp1_pct','tp2_pct','tp3_pct','move_be_after_tp1','trail_after_tp1','tick_ms','size_mode',
    'min_conviction','daily_loss_limit_pct','max_dd_halt_pct','ai_require_sl'];
  const o={};
  for(const k of ids){const el=$('ds_'+k);if(el)o[k]=el.value}
  return o;
}

function livePrice(){
  return S.live?.last||S.data?.spot||null;
}

function renderDemoState(st){
  if(!st)return;
  if(st.settings)applySettingsToForm(st.settings);
  const w=st.wallet||{};
  const eqTone=w.equity>=(w.total_deposited||100)?'good':'bad';
  const dd=w.peak_equity?((w.peak_equity-w.equity)/w.peak_equity*100):0;
  $('demoWallet').innerHTML=[
    M('موجودی آزاد',fmt(w.balance,4)+' $'),
    M('اکوئیتی','<span class="'+eqTone+'">'+fmt(w.equity,4)+' $</span>'),
    M('PnL تحقق‌یافته','<span class="'+(w.realized_pnl>=0?'pnl-pos':'pnl-neg')+'">'+fmt(w.realized_pnl,4)+' $</span>'),
    M('واریز کل',fmt(w.total_deposited,2)+' $'),
    M('قله اکوئیتی',fmt(w.peak_equity,4)+' $'),
    M('Drawdown','<span class="'+(dd>10?'bad':'')+'">'+fmt(dd,2)+'%</span>'),
    M('کارمزد پرداختی',fmt(w.fees_paid,4)+' $'),
    M('ROI','<span class="'+((w.equity-(w.total_deposited||100))>=0?'pnl-pos':'pnl-neg')+'">'+pc(((w.equity-(w.total_deposited||100))/(w.total_deposited||100))*100)+'</span>')
  ].join('');
  if($('xBal'))$('xBal').textContent=fmt(w.balance,2);
  if($('xEq')){$('xEq').textContent=fmt(w.equity,2);$('xEq').style.color=w.equity>=(w.total_deposited||100)?'var(--green)':'var(--red)'}
  if($('xRpnl')){$('xRpnl').textContent=fmt(w.realized_pnl,2);$('xRpnl').style.color=w.realized_pnl>=0?'var(--green)':'var(--red)'}
  if($('topEq'))$('topEq').textContent='Equity: $'+fmt(w.equity,2);
  // sum unrealized from open positions (use server live_price per symbol)
  let upnl=0;
  for(const p of (st.positions||[])){
    if(p.unrealized_pnl!=null){upnl+=p.unrealized_pnl}
    else if(p.live_price&&p.qty_open){
      const ret=p.side==='LONG'?(p.live_price-p.entry)/p.entry:(p.entry-p.live_price)/p.entry;
      upnl+=ret*(p.entry*p.qty_open)
    }
  }
  if($('xUpnl')){$('xUpnl').textContent=fmt(upnl,2);$('xUpnl').style.color=upnl>=0?'var(--green)':'var(--red)'}

  const halted=st.trading_ok===false;
  if($('haltBanner')){if(halted){$('haltBanner').classList.add('show');$('haltBanner').innerHTML='⛔ '+(st.halt_reason||'معاملات متوقف')+' <button id="demoResume" class="sec" style="flex:0;width:auto;display:inline-block;margin-right:8px">از سرگیری</button>';const rb=$('demoResume');if(rb)rb.onclick=async()=>{await fetch('/demo/resume',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});refreshDemo()}}else $('haltBanner').classList.remove('show')}
  if($('eqBars')&&st.equity_curve){const cur=st.equity_curve.slice(-40);const mx=Math.max(...cur.map(x=>x.equity),1);$('eqBars').innerHTML=cur.map(x=>'<i style="height:'+Math.max(4,(x.equity/mx*100))+'%"></i>').join('')}
  if($('alertList')){const al=st.alerts||[];$('alertList').innerHTML=al.length?al.map(a=>'<div class="alert-item"><div class="t">'+(a.ts?iso(a.ts):'')+' · '+esc(a.kind)+'</div>'+esc(a.message)+'</div>').join(''):'<span class="muted">هشداری نیست</span>'}

  const s=st.stats||{};
  $('demoStats').innerHTML=[
    M('معاملات',s.trades||0),M('برد/باخت',(s.wins||0)+'/'+(s.losses||0)),
    M('WinRate',fmt(s.winrate,1)+'%'),M('Profit Factor',fmt(s.profit_factor,2)),
    M('Expectancy',fmt(s.expectancy,4)+'$'),M('Avg Win',fmt(s.avg_win,4)+'$'),
    M('Avg Loss',fmt(s.avg_loss,4)+'$'),M('PnL امروز',fmt(s.pnl_day,4)+'$'),
    M('PnL هفته',fmt(s.pnl_week,4)+'$'),M('Max DD',fmt(s.max_drawdown_pct,2)+'%'),
    M('برد متوالی',s.max_consec_wins||0),M('باخت متوالی',s.max_consec_loss||0)
  ].join('');
  const pos=st.positions||[];
  const price=livePrice();
  if(!pos.length)$('demoPos').innerHTML='<span class="muted">پوزیشن باز نیست.</span>';
  else{
    $('demoPos').innerHTML=pos.map(p=>{
      let uPnl=null,uPct=null,roe=null;
      // Prefer server-calculated live values (works for ALL open symbols)
      if(p.unrealized_pnl!=null){
        uPnl=p.unrealized_pnl; uPct=p.unrealized_pnl_pct; roe=uPct;
      } else {
        const px = p.live_price || (p.symbol&&price&&String(p.symbol).includes(String(currentSym||''))?price:null);
        if(px&&p.qty_open){
          const ret=p.side==='LONG'?(px-p.entry)/p.entry:(p.entry-px)/p.entry;
          uPnl=ret*(p.entry*p.qty_open);
          uPct=p.margin_open?uPnl/p.margin_open*100:0;
          roe=uPct;
        }
      }
      const age=p.opened_ts?Math.max(0,Math.floor(Date.now()/1000-p.opened_ts)):0;
      const ageStr=age>=3600?Math.floor(age/3600)+'h '+Math.floor((age%3600)/60)+'m':Math.floor(age/60)+'m '+age%60+'s';
      return '<div class="demo-pos '+(p.side==='LONG'?'long':'short')+'">'+
        '<div class="row"><b>#'+p.id+' '+esc(p.symbol)+'</b> <span class="badge '+(p.side==='LONG'?'b-b':'b-s')+'">'+p.side+'</span>'+
        '<span class="muted">'+esc(p.source||'')+' · Lev '+fmt(p.leverage,1)+'× · '+ageStr+' · Conv '+(p.ai_conviction||'—')+'/10</span></div>'+
        '<div class="grid" style="margin-top:6px">'+
          M('ورود',fp(p.entry))+M('قیمت',fp(price))+M('Qty باز',fmt(p.qty_open,6))+M('مارجین',fmt(p.margin_open,3)+'$')+
          M('Notional',fmt((p.entry*p.qty_open),2)+'$')+M('Liq',fp(p.liq_price))+
          M('TP1'+(p.tp1_done?' ✓':''),fp(p.tp1))+M('TP2'+(p.tp2_done?' ✓':''),fp(p.tp2))+M('TP3',fp(p.tp3))+M('SL',fp(p.sl))+
          M('Unrealized',uPnl==null?'—':'<span class="'+(uPnl>=0?'pnl-pos':'pnl-neg')+'">'+fmt(uPnl,4)+'$ ('+fmt(roe,2)+'% ROE)</span>')+
          M('MFE / MAE',fmt(p.mfe,3)+' / '+fmt(p.mae,3))+M('Fees',fmt(p.fees,4))+M('BE',p.be_moved?'بله':'خیر')+M('Trail',p.trail_active?'ON '+fmt(p.trail_dist,4):'OFF')+
        '</div>'+
        '<div class="row" style="margin-top:6px">'+
          '<button class="sec demo-close-btn" data-id="'+p.id+'" data-pct="100" style="flex:0 0 auto">بستن ۱۰۰٪</button>'+
          '<button class="sec demo-close-btn" data-id="'+p.id+'" data-pct="50" style="flex:0 0 auto">بستن ۵۰٪</button>'+
          '<button class="sec demo-close-btn" data-id="'+p.id+'" data-pct="25" style="flex:0 0 auto">بستن ۲۵٪</button>'+
          '<button class="pur demo-be-btn" data-id="'+p.id+'" style="flex:0 0 auto">SL → BE</button>'+
          '<button class="blue demo-rev-btn" data-id="'+p.id+'" style="flex:0 0 auto">معکوس</button>'+
          '<button class="sec demo-scale-btn" data-id="'+p.id+'" style="flex:0 0 auto">Scale-In</button>'+
        '</div>'+
        '<div class="row" style="margin-top:4px">'+
          '<input class="demo-mod-sl" data-id="'+p.id+'" placeholder="SL جدید" type="number" step="any" style="flex:1">'+
          '<input class="demo-mod-tp" data-id="'+p.id+'" placeholder="TP1 جدید" type="number" step="any" style="flex:1">'+
          '<button class="sec demo-mod-btn" data-id="'+p.id+'" style="flex:0 0 90px">اعمال</button>'+
        '</div></div>';
    }).join('');
    document.querySelectorAll('.demo-close-btn').forEach(btn=>btn.addEventListener('click',async()=>{
      const id=+btn.dataset.id,pct=+btn.dataset.pct;const px=livePrice();if(!px){banner('قیمت نداریم');return}
      try{
        const r=await fetch('/demo/close',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,price:px,qty_pct:pct})});
        const j=await r.json();if(!j.ok)throw new Error(j.error);
        banner('بسته '+pct+'٪ · PnL '+fmt(j.pnl,4)+'$');logDemoEvent('CLOSE #'+id+' '+pct+'% pnl='+fmt(j.pnl,4));
        renderDemoState(j);
      }catch(e){banner(e.message)}
    }));
    document.querySelectorAll('.demo-be-btn').forEach(btn=>btn.addEventListener('click',async()=>{
      const id=+btn.dataset.id;const p=pos.find(x=>x.id===id);if(!p)return;
      const be=p.side==='LONG'?p.entry*1.0005:p.entry*0.9995;
      try{
        const r=await fetch('/demo/modify',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,sl:be})});
        const j=await r.json();if(!j.ok)throw new Error(j.error);
        banner('SL → BE '+fp(be));renderDemoState(j);
      }catch(e){banner(e.message)}
    }));
    
    document.querySelectorAll('.demo-rev-btn').forEach(btn=>btn.addEventListener('click',async()=>{
      const id=+btn.dataset.id;const px=livePrice();if(!px){banner('قیمت نداریم');return}
      if(!confirm('پوزیشن معکوس شود؟'))return;
      try{const r=await fetch('/demo/reverse',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,price:px})});const j=await r.json();
        if(!j.ok)throw new Error(j.error);banner('معکوس شد');renderDemoState(j);logDemoEvent('REVERSE #'+id)}catch(e){banner(e.message)}
    }));
    document.querySelectorAll('.demo-scale-btn').forEach(btn=>btn.addEventListener('click',async()=>{
      const id=+btn.dataset.id;const px=livePrice();if(!px){banner('قیمت نداریم');return}
      const m=prompt('مارجین اضافه (USDT):','5');if(!m)return;
      try{const r=await fetch('/demo/scale_in',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,price:px,margin:+m})});const j=await r.json();
        if(!j.ok)throw new Error(j.error);banner('Scale-In انجام شد');renderDemoState(j);logDemoEvent('SCALE #'+id)}catch(e){banner(e.message)}
    }));
document.querySelectorAll('.demo-mod-btn').forEach(btn=>btn.addEventListener('click',async()=>{
      const id=+btn.dataset.id;
      const slEl=document.querySelector('.demo-mod-sl[data-id="'+id+'"]');
      const tpEl=document.querySelector('.demo-mod-tp[data-id="'+id+'"]');
      const body={id};if(slEl&&slEl.value)body.sl=+slEl.value;if(tpEl&&tpEl.value)body.tp1=+tpEl.value;
      try{
        const r=await fetch('/demo/modify',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
        const j=await r.json();if(!j.ok)throw new Error(j.error);
        banner('ویرایش شد');renderDemoState(j);
      }catch(e){banner(e.message)}
    }));
  }
  const hist=st.history||[];
  $('demoHist').innerHTML='<thead><tr><th>زمان</th><th>نماد</th><th>سمت</th><th>ورود</th><th>خروج</th><th>Qty</th><th>Lev</th><th>PnL</th><th>%</th><th>Fee</th><th>دلیل</th></tr></thead><tbody>'+
    (hist.map(h=>'<tr><td>'+(h.ts?iso(h.ts):'—')+'</td><td>'+esc(h.symbol)+'</td><td class="'+(h.side==='LONG'?'good':'bad')+'">'+h.side+'</td><td>'+fp(h.entry)+'</td><td>'+fp(h.exit)+'</td><td>'+fmt(h.qty,5)+'</td><td>'+fmt(h.leverage,1)+'</td>'+
    '<td class="'+(h.pnl>=0?'good':'bad')+'">'+fmt(h.pnl,4)+'</td><td class="'+(h.pnl_pct>=0?'good':'bad')+'">'+fmt(h.pnl_pct,2)+'%</td><td>'+fmt(h.fee,4)+'</td><td>'+esc(h.reason)+'</td></tr>').join('')||'<tr><td colspan=11 class="muted">هنوز معامله‌ای نیست</td></tr>')+'</tbody>';
}

async function refreshDemo(){
  try{const r=await fetch('/demo/state');const j=await r.json();renderDemoState(j);return j}catch(e){logDemoEvent('state error: '+e.message)}
}

async function tickDemo(){
  updateTopbar();
  const px=livePrice();
  if($('demoTickInfo'))$('demoTickInfo').textContent=px?('· قیمت زنده '+fp(px)+' · '+new Date().toISOString().slice(11,19)+' UTC'):'';
  if(!S.data)return;
  const prices={};
  if(px){prices[S.data.symbol]=px;if(S.data.bPair)prices[S.data.bPair]=px;if(S.data.base)prices[S.data.base+'USDT']=px;}
  if(!Object.keys(prices).length)return;
  try{
    const r=await fetch('/demo/update',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prices})});
    const j=await r.json();
    if(j.events&&j.events.length){
      for(const e of j.events){
        logDemoEvent('#'+e.id+' '+e.symbol+' '+e.side+' → '+e.reason+' @ '+fp(e.price)+' PnL '+fmt(e.pnl,4)+'$');
        banner(e.reason+' · '+fmt(e.pnl,2)+'$');
      }
    }
    renderDemoState(j);
  }catch(e){}
}

function startDemoMonitor(){
  if(S.demoTimer)clearInterval(S.demoTimer);
  const ms=Math.max(500,Math.min(5000,+(S.demoSettings?.tick_ms||$('ds_tick_ms')?.value||1000)));
  S.demoTimer=setInterval(tickDemo,ms);
  tickDemo();
}

if($('demoRefresh'))$('demoRefresh').addEventListener('click',()=>refreshDemo());
if($('demoDeposit'))$('demoDeposit').addEventListener('click',async()=>{
  const amt=prompt('مبلغ واریز (USDT):','100');
  if(!amt||isNaN(+amt)||+amt<=0)return;
  try{const r=await fetch('/demo/deposit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({amount:+amt,note:'واریز دستی'})});const j=await r.json();
    if(!j.ok)throw new Error(j.error);banner('واریز '+amt+'$ انجام شد');renderDemoState(j);logDemoEvent('DEPOSIT +'+amt)}catch(e){banner(e.message)}
});
if($('demoWithdraw'))$('demoWithdraw').addEventListener('click',async()=>{
  const amt=prompt('مبلغ برداشت (USDT):','20');
  if(!amt||isNaN(+amt)||+amt<=0)return;
  try{const r=await fetch('/demo/withdraw',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({amount:+amt,note:'برداشت دستی'})});const j=await r.json();
    if(!j.ok)throw new Error(j.error);banner('برداشت '+amt+'$ انجام شد');renderDemoState(j);logDemoEvent('WITHDRAW -'+amt)}catch(e){banner(e.message)}
});
if($('demoResume2'))$('demoResume2').addEventListener('click',async()=>{
  try{await fetch('/demo/resume',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});refreshDemo();banner('معاملات از سر گرفته شد')}catch(e){banner(e.message)}
});

if($('demoExport'))$('demoExport').addEventListener('click',async()=>{
  try{
    banner('در حال آماده‌سازی پرتفوی...');
    const r=await fetch('/demo/export',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({format:'csv'})});
    const j=await r.json();
    if(!j.ok)throw new Error(j.error||'خطا');
    const blob=new Blob([j.content||''],{type:'text/csv;charset=utf-8'});
    const a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download='APEX_Portfolio_'+new Date().toISOString().slice(0,19).replace(/[:T]/g,'-')+'.csv';
    document.body.appendChild(a);a.click();a.remove();
    banner('پرتفوی کامل دانلود شد');
    logDemoEvent('EXPORT PORTFOLIO');
  }catch(e){banner(e.message)}
});
if($('demoAutoTrade'))$('demoAutoTrade').addEventListener('click',async()=>{
  if(!confirm('معامله خودکار روی حدود ۲۰ ارز شروع شود؟\nسیستم خودش تحلیل می‌کند و پوزیشن باز می‌کند.'))return;
  try{
    banner('شروع معامله خودکار...');
    const r=await fetch('/demo/auto_trade/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({max_pos:20})});
    const j=await r.json();
    if(!j.ok)throw new Error(j.error||'خطا');
    banner(j.message||'معامله خودکار شروع شد');
    logDemoEvent('AUTO-TRADE START');
    refreshDemo();
    // poll status
    const iv=setInterval(async()=>{
      try{
        const s=await fetch('/demo/auto_trade/status',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
        const sj=await s.json();
        if(sj.settings_flag==='0'||!sj.running){clearInterval(iv);banner('معامله خودکار تمام شد');refreshDemo()}
        else refreshDemo();
      }catch(e){clearInterval(iv)}
    },8000);
  }catch(e){banner(e.message)}
});
if($('demoAutoStop'))$('demoAutoStop').addEventListener('click',async()=>{
  try{
    const r=await fetch('/demo/auto_trade/stop',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
    const j=await r.json();
    banner(j.message||'توقف ارسال شد');
    refreshDemo();
  }catch(e){banner(e.message)}
});
if($('btnSaveApiKey'))$('btnSaveApiKey').addEventListener('click',async()=>{
  const key=($('ds_gemini_key')&&$('ds_gemini_key').value||'').trim();
  if(!key||key.length<10){banner('کلید معتبر وارد کنید');return}
  try{
    const r=await fetch('/demo/set_api_key',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key})});
    const j=await r.json();
    if(!j.ok)throw new Error(j.error);
    banner('کلید API ذخیره شد');
    if($('ds_gemini_key'))$('ds_gemini_key').value='';
  }catch(e){banner(e.message)}
});
if($('demoReset'))$('demoReset').addEventListener('click',async()=>{
  if(!confirm('ریست کامل کیف پول و تاریخچه؟'))return;
  try{const r=await fetch('/demo/reset',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});const j=await r.json();
    banner('ریست شد');renderDemoState(j);logDemoEvent('RESET')}catch(e){banner(e.message)}
});
if($('demoCloseAll'))$('demoCloseAll').addEventListener('click',async()=>{
  const px=livePrice();if(!px||!S.data){banner('قیمت نداریم');return}
  if(!confirm('همه پوزیشن‌ها بسته شوند؟'))return;
  const prices={};prices[S.data.symbol]=px;
  try{const r=await fetch('/demo/close_all',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prices})});const j=await r.json();
    banner('همه بسته شد');renderDemoState(j);logDemoEvent('CLOSE ALL')}catch(e){banner(e.message)}
});
if($('demoSaveSettings'))$('demoSaveSettings').addEventListener('click',async()=>{
  const body=collectSettingsFromForm();
  try{const r=await fetch('/demo/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const j=await r.json();
    if(!j.ok)throw new Error(j.error);S.demoSettings=j.settings;banner('تنظیمات ذخیره شد');startDemoMonitor()}catch(e){banner(e.message)}
});
if($('manFillPrice'))$('manFillPrice').addEventListener('click',()=>{const px=livePrice();if(px)$('manEntry').value=px});
if($('manOpen'))$('manOpen').addEventListener('click',async()=>{
  const sym = (S.data && S.data.symbol) || ($('sym') && $('sym').value) || ($('q') && $('q').value) || '';
  if(!sym){banner('ابتدا نماد را انتخاب یا سرچ کنید');return}
  const sizeMode = ($('manSizeMode') && $('manSizeMode').value) || 'usd';
  const body={
    symbol:sym,side:$('manSide').value,entry:+$('manEntry').value,
    leverage:+$('manLev').value,
    tp1:$('manTp1').value?+$('manTp1').value:null,
    tp2:$('manTp2').value?+$('manTp2').value:null,
    tp3:$('manTp3').value?+$('manTp3').value:null,
    sl:$('manSl').value?+$('manSl').value:null,source:'manual'
  };
  if(sizeMode==='usd'){ body.margin_usd = +$('manSize').value; }
  else { body.size_pct = +$('manSize').value; }
  if($('manRisk')&&$('manRisk').value)body.risk_pct=+$('manRisk').value;

  try{const r=await fetch('/demo/open',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const j=await r.json();
    if(!j.ok)throw new Error(j.error);banner('پوزیشن دستی باز شد');logDemoEvent('MANUAL OPEN');await refreshDemo();startDemoMonitor()}catch(e){banner(e.message)}
});
if($('manSizeMode'))$('manSizeMode').addEventListener('change',()=>{
  const mode=$('manSizeMode').value;
  if($('manSizeLabel'))$('manSizeLabel').textContent = mode==='usd' ? 'مبلغ مارجین (USDT)' : 'درصد مارجین از موجودی';
  if($('manSize')){$('manSize').value = mode==='usd' ? 10 : 5; $('manSize').step = mode==='usd' ? 1 : 0.5;}
});


// Side toggle
if($('manLongBtn'))$('manLongBtn').addEventListener('click',()=>{
  $('manSide').value='LONG';$('manLongBtn').classList.add('on-long');$('manShortBtn').classList.remove('on-short');
  $('manOpen').className='long';$('manOpen').textContent='باز کردن LONG';
});
if($('manShortBtn'))$('manShortBtn').addEventListener('click',()=>{
  $('manSide').value='SHORT';$('manShortBtn').classList.add('on-short');$('manLongBtn').classList.remove('on-long');
  $('manOpen').className='short';$('manOpen').textContent='باز کردن SHORT';
});
function updateOrderPreview(){
  const el=$('manPreview');if(!el)return;
  const entry=+$('manEntry').value,sl=+$('manSl').value,lev=+$('manLev').value||5,size=+$('manSize').value||5;
  const side=$('manSide').value;const px=livePrice();
  if(!entry){el.textContent='قیمت ورود را وارد کنید یا «قیمت بازار» را بزنید.';return}
  const risk=sl?Math.abs(entry-sl)/entry*100:null;
  const notionalApprox=(S.demoSettings&&0)||null;
  el.innerHTML='سمت <b>'+side+'</b> · ورود '+fp(entry)+(px?' · بازار '+fp(px):'')+
    (sl?' · SL '+fp(sl)+' ('+fmt(risk,2)+'%)':' · بدون SL')+
    ' · اهرم '+lev+'× · مارجین حدود '+size+'٪ موجودی';
}
['manEntry','manSl','manLev','manSize'].forEach(id=>{const el=$(id);if(el)el.addEventListener('input',updateOrderPreview)});


if($('alertsRead'))$('alertsRead').addEventListener('click',async()=>{
  await fetch('/demo/alerts_read',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
  refreshDemo();
});
if($('demoResume'))$('demoResume').addEventListener('click',async()=>{
  await fetch('/demo/resume',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
  refreshDemo();banner('معاملات فعال شد');
});

// ===== App shell: drawer + settings sheet =====
function openDrawer(v){
  if(v){$('drawerBg').classList.add('show');$('drawer').classList.add('show')}
  else{$('drawerBg').classList.remove('show');$('drawer').classList.remove('show')}
}
function openSheet(v){
  if(v){$('sheetBg').classList.add('show');$('settingsSheet').classList.add('show');syncQuickSettings()}
  else{$('sheetBg').classList.remove('show');$('settingsSheet').classList.remove('show')}
}
function syncQuickSettings(){
  const st=S.demoSettings||{};
  const pairs=[['auto_trade','qs_auto_trade'],['min_conviction','qs_min_conviction'],['default_leverage','qs_default_leverage'],
    ['max_risk_pct','qs_max_risk_pct'],['daily_loss_limit_pct','qs_daily_loss_limit_pct'],['tick_ms','qs_tick_ms'],
    ['size_mode','qs_size_mode'],['ai_require_sl','qs_ai_require_sl']];
  pairs.forEach(([k,id])=>{const el=$(id);if(el&&st[k]!=null)el.value=st[k]});
}
if($('btnMenu'))$('btnMenu').addEventListener('click',()=>openDrawer(true));
if($('drawerBg'))$('drawerBg').addEventListener('click',()=>openDrawer(false));
if($('btnGear'))$('btnGear').addEventListener('click',()=>openSheet(true));
if($('sheetBg'))$('sheetBg').addEventListener('click',()=>openSheet(false));
if($('qsClose'))$('qsClose').addEventListener('click',()=>openSheet(false));
document.querySelectorAll('.drawer .nav-item[data-go]').forEach(b=>b.addEventListener('click',()=>{
  openDrawer(false);switchTab(b.getAttribute('data-go'));
}));
if($('drawerRunAi'))$('drawerRunAi').addEventListener('click',()=>{openDrawer(false);switchTab('home');runApex()});
if($('drawerTrade'))$('drawerTrade').addEventListener('click',()=>{openDrawer(false);openDemoFromSignal(false);switchTab('trade')});
if($('qsSave'))$('qsSave').addEventListener('click',async()=>{
  const body={
    auto_trade:$('qs_auto_trade').value,min_conviction:$('qs_min_conviction').value,
    default_leverage:$('qs_default_leverage').value,max_risk_pct:$('qs_max_risk_pct').value,
    daily_loss_limit_pct:$('qs_daily_loss_limit_pct').value,tick_ms:$('qs_tick_ms').value,
    size_mode:$('qs_size_mode').value,ai_require_sl:$('qs_ai_require_sl').value
  };
  try{
    const r=await fetch('/demo/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    const j=await r.json();if(!j.ok)throw new Error(j.error||'خطا');
    S.demoSettings=Object.assign(S.demoSettings||{},j.settings||body);
    // mirror to full settings form if present
    applySettingsToForm(S.demoSettings);
    startDemoMonitor();openSheet(false);banner('تنظیمات ذخیره شد');
  }catch(e){banner(e.message)}
});


// ===== Coin switcher (live prices) =====
const POP_COINS=['BTC','ETH','SOL','BNB','XRP','DOGE','ADA','AVAX','LINK','DOT','MATIC','NEAR','APT','ARB','OP','SUI','PEPE','WIF','TON','TRX','LTC','BCH','UNI','ATOM','FIL'];
S.coinPrices={};
S.activeCoin=null;

function pairOf(base){return (base||'BTC').toUpperCase().replace(/-USDT$/,'').replace(/USDT$/,'')+'-USDT'}

async function fetchCoinPrice(base){
  const b=(base||'BTC').toUpperCase().replace(/-USDT$/,'').replace(/USDT$/,'');
  const pair=b+'USDT';
  try{
    const j=await pj('https://api.binance.com/api/v3/ticker/price?symbol='+pair);
    const px=parseFloat(j.price);
    if(Number.isFinite(px)){S.coinPrices[b]=px;return px}
  }catch(e){}
  try{
    const j=await pj('https://api.kucoin.com/api/v1/market/orderbook/level1?symbol='+b+'-USDT');
    const px=parseFloat(j.data&&j.data.price);
    if(Number.isFinite(px)){S.coinPrices[b]=px;return px}
  }catch(e){}
  return null;
}

async function refreshCoinStrip(){
  const el=$('coinStrip');if(!el)return;
  const active=(S.activeCoin||(S.data&&S.data.base)||'BTC').toUpperCase();
  el.innerHTML=POP_COINS.map(c=>{
    const px=S.coinPrices[c];
    return '<button type="button" class="coin-chip '+(c===active?'active':'')+'" data-coin="'+c+'">'+c+
      '<span class="p">'+(px!=null?fp(px):'…')+'</span></button>';
  }).join('');
  el.querySelectorAll('.coin-chip').forEach(btn=>btn.addEventListener('click',()=>selectCoin(btn.dataset.coin)));
}

async function selectCoin(base){
  base=(base||'BTC').toUpperCase().replace(/[^A-Z0-9]/g,'');
  if(!base)return;
  S.activeCoin=base;
  const sym=pairOf(base);
  if($('symbol'))$('symbol').value=sym;
  if($('topSym'))$('topSym').textContent=sym;
  if($('xSym'))$('xSym').textContent=sym;
  banner('ارز: '+sym);
  const px=await fetchCoinPrice(base);
  if(px!=null){
    if($('topPrice'))$('topPrice').textContent=fp(px);
    if($('xPrice'))$('xPrice').textContent=fp(px);
    if($('manEntry'))$('manEntry').value=px;
    if(S.data){S.data.symbol=sym;S.data.base=base;S.data.bPair=base+'USDT';S.data.spot=px}
    // keep live feed aligned
    S.live=S.live||{};S.live.last=px;
  }
  await refreshCoinStrip();
  // restart live if we have analysis context
  if(S.data){try{startLive(S.data)}catch(e){}}
  startDemoMonitor();
  switchTab('trade');
}

async function tickCoinPrices(){
  // refresh a rotating subset for speed
  const batch=POP_COINS.slice(0,12);
  await Promise.all(batch.map(c=>fetchCoinPrice(c).catch(()=>null)));
  refreshCoinStrip();
  // update active price every tick
  const a=S.activeCoin||(S.data&&S.data.base);
  if(a){
    const px=S.coinPrices[a]||await fetchCoinPrice(a);
    if(px!=null){
      if($('xPrice'))$('xPrice').textContent=fp(px);
      if($('topPrice'))$('topPrice').textContent=fp(px);
      S.live=S.live||{};S.live.prev=S.live.last;S.live.last=px;
      if(S.data)S.data.spot=px;
    }
  }
}

if($('coinGo'))$('coinGo').addEventListener('click',()=>{
  const q=($('coinSearch').value||'').trim().toUpperCase();
  if(q)selectCoin(q);
});
if($('coinSearch'))$('coinSearch').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('coinGo').click()}});
if($('coinRefresh'))$('coinRefresh').addEventListener('click',()=>tickCoinPrices());
setInterval(tickCoinPrices,3000);
refreshCoinStrip();tickCoinPrices();

refreshDemo().then(()=>startDemoMonitor());
</script></body></html>'''


if __name__ == '__main__':
    db_init()
    print('=' * 60)
    print('KuCoin Analytics v%s' % VERSION)
    print('Open: http://%s:%s' % (HOST, PORT))
    print('Downloads: %s' % find_download_dir())
    print('DB: %s' % DB_PATH)
    print('=' * 60)
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print('\nStopped.')
    finally:
        srv.server_close()

