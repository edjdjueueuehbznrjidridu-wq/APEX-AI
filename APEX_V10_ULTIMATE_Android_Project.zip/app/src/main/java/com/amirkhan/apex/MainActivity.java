package com.amirkhan.apex;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;
import android.os.SystemClock;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {
    private WebView webView;
    private long splashStartedAt;
    private final int bg = Color.rgb(5, 9, 20);
    private final int gold = Color.rgb(244, 195, 80);
    private final int cyan = Color.rgb(35, 211, 235);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        splashStartedAt = SystemClock.elapsedRealtime();
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        showSplash();
        new Thread(() -> {
            try {
                if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
                Python.getInstance().getModule("apex_launcher").callAttr("start_server");
                boolean ready = waitForBackend(15000);
                long elapsed = SystemClock.elapsedRealtime() - splashStartedAt;
                long remaining = Math.max(0, 2000 - elapsed);
                if (remaining > 0) Thread.sleep(remaining);
                if (ready) runOnUiThread(this::showApp);
                else runOnUiThread(() -> showError("موتور داخلی شروع شد، اما پاسخ سرور محلی دریافت نشد. اتصال و لاگ ساخت APK را بررسی کن."));
            } catch (Exception e) {
                runOnUiThread(() -> showError("خطا در راه‌اندازی بک‌اند: " + e.getClass().getSimpleName() + ": " + e.getMessage()));
            }
        }, "APEX-startup").start();
    }

    private boolean waitForBackend(long timeoutMs) {
        long end = SystemClock.elapsedRealtime() + timeoutMs;
        while (SystemClock.elapsedRealtime() < end) {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL("http://127.0.0.1:8765/").openConnection();
                c.setConnectTimeout(700); c.setReadTimeout(700); c.setUseCaches(false);
                int code = c.getResponseCode();
                if (code >= 200 && code < 500) return true;
            } catch (Exception ignored) {
            } finally { if (c != null) c.disconnect(); }
            SystemClock.sleep(180);
        }
        return false;
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private GradientDrawable outline(int fill, int stroke, int radius) {
        GradientDrawable d = rounded(fill, radius); d.setStroke(2, stroke); return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextColor(color); t.setTextSize(size);
        t.setGravity(Gravity.CENTER); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private void showSplash() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        GradientDrawable background = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(4, 8, 20), Color.rgb(8, 18, 38), Color.rgb(4, 8, 18)});
        root.setBackground(background);
        ImageView logo = new ImageView(this);
        try (InputStream in = getAssets().open("trading_ai_icon.png")) {
            logo.setImageBitmap(BitmapFactory.decodeStream(in));
        } catch (Exception ignored) { logo.setImageResource(com.amirkhan.apex.R.mipmap.ic_launcher); }
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(250), dp(250)); lp.bottomMargin = dp(12); root.addView(logo, lp);
        logo.setScaleX(0.94f); logo.setScaleY(0.94f); logo.animate().scaleX(1f).scaleY(1f).setDuration(650).start();
        TextView title = text("TRADING AI", 27, Color.WHITE, true); title.setLetterSpacing(0.09f); root.addView(title);
        TextView subtitle = text("APEX  •  AI CRYPTO ANALYTICS", 11, cyan, true); subtitle.setPadding(0, dp(5), 0, dp(18)); root.addView(subtitle);

        LinearLayout loadingRow = new LinearLayout(this); loadingRow.setGravity(Gravity.CENTER); loadingRow.setOrientation(LinearLayout.HORIZONTAL);
        ProgressBar spinner = new ProgressBar(this); spinner.setIndeterminate(true);
        spinner.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(gold));
        loadingRow.addView(spinner, new LinearLayout.LayoutParams(dp(22), dp(22)));
        TextView loading = text("  در حال آماده‌سازی موتور تحلیل...", 12, Color.rgb(205, 218, 235), false);
        loadingRow.addView(loading); root.addView(loadingRow);

        View line = new View(this); line.setBackground(rounded(Color.rgb(29, 68, 94), dp(3)));
        LinearLayout.LayoutParams lineLp = new LinearLayout.LayoutParams(dp(180), dp(3)); lineLp.topMargin = dp(20); lineLp.bottomMargin = dp(18); root.addView(line, lineLp);
        TextView info = text("این ابزار با هدف آموزشی و تحلیل بازار ساخته شده است.\nخروجی‌ها تضمین سود نیستند؛ پیش از هر تصمیم، بررسی مستقل انجام بده.", 12, Color.rgb(199, 207, 221), false);
        info.setPadding(dp(8), 0, dp(8), dp(14)); root.addView(info);
        TextView author = text("ساخته‌شده توسط AMiR KHAN", 14, Color.WHITE, true); root.addView(author);
        TextView contact = text("پشتیبانی تلگرام: @OloveOyouO", 13, gold, true); contact.setPadding(0, dp(8), 0, 0);
        contact.setOnClickListener(v -> { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/OloveOyouO"))); } catch (Exception ignored) {} }); root.addView(contact);
        setContentView(root);
    }

    private void showApp() {
        webView = new WebView(this); webView.setBackgroundColor(bg);
        WebSettings settings = webView.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true); settings.setAllowFileAccess(true); settings.setLoadsImagesAutomatically(true);
        settings.setSupportZoom(false); settings.setBuiltInZoomControls(false); settings.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView); webView.loadUrl("http://127.0.0.1:8765/");
    }
    private void showError(String error) {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24),dp(24),dp(24),dp(24)); root.setBackgroundColor(bg);
        root.addView(text("APEX نتوانست راه‌اندازی شود", 20, Color.WHITE, true));
        TextView details = text(error, 12, Color.LTGRAY, false); details.setPadding(0,dp(18),0,dp(18)); root.addView(details);
        TextView retry = text("تلاش دوباره", 16, gold, true); retry.setPadding(dp(22),dp(16),dp(22),dp(16));
        retry.setBackground(outline(Color.rgb(20,29,45), cyan, dp(18)));
        retry.setOnClickListener(v -> { recreate(); }); root.addView(retry); setContentView(root);
    }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (webView != null) webView.destroy(); super.onDestroy(); }
}
